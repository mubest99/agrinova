// ===== AGRICULTURE ARTICLES — JAVASCRIPT =====

(function() {

    // ----- 1. ARTICLE DATA (50 articles from your custom sources) -----
    const articles = [

        // ---- CROP PRODUCTION (5) ----
        {
            id: 1,
            title: "Best Practices for Commercial Banana Cultivation and Canopy Management",
            category: "crop-production",
            categoryLabel: "Crop Production",
            excerpt: "Explore best practices for commercial banana cultivation including canopy management, soil preparation, and pest control strategies for optimal yields.",
            image: "https://images.unsplash.com/photo-1528825871115-3581a5387919?w=600&q=80",
            readTime: "6 min",
            link: "https://docs.google.com/document/d/1cWDKIPtESGo-1FfkbvgYjPW3sMQ-m8Jt9Aw9kA92h6U/edit?usp=drive_web",
            source: "Global Agronomy Insights"
        },
        {
            id: 2,
            title: "Maximizing Maize Yields in Sub-Saharan Conditions",
            category: "crop-production",
            categoryLabel: "Crop Production",
            excerpt: "Learn proven strategies for maximizing maize yields in sub-Saharan Africa including variety selection, planting techniques, and crop management.",
            image: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=600&q=80",
            readTime: "7 min",
            link: "https://www.cgiar.org/research/crop/maize/",
            source: "CGIAR Research Hub"
        },
        {
            id: 3,
            title: "Post-Harvest Processing and Grain Storage Systems",
            category: "crop-production",
            categoryLabel: "Crop Production",
            excerpt: "Discover effective post-harvest processing and grain storage systems to reduce losses and maintain crop quality.",
            image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=600&q=80",
            readTime: "8 min",
            link: "https://www.fao.org/post-harvest-mitigation/en/",
            source: "FAO Post-Harvest Knowledge Sharing Platform"
        },
        {
            id: 4,
            title: "Intercropping Strategies for Tropical Smallholder Farming",
            category: "crop-production",
            categoryLabel: "Crop Production",
            excerpt: "Explore effective intercropping strategies for tropical smallholder farming systems to improve yields and sustainability.",
            image: "https://images.unsplash.com/photo-1592417817098-8f3d6eb231fc?w=600&q=80",
            readTime: "5 min",
            link: "https://www.fao.org/agroecology/knowledge-hub/en/",
            source: "FAO Agroecology Knowledge Hub"
        },
        {
            id: 5,
            title: "Wheat Crop Management and Planting Schedules",
            category: "crop-production",
            categoryLabel: "Crop Production",
            excerpt: "Learn optimal wheat crop management practices and planting schedules for improved yields and quality.",
            image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=600&q=80",
            readTime: "6 min",
            link: "https://cimmyt.org/news/wheat-production-guide/",
            source: "CIMMYT International"
        },

        // ---- SOIL & LAND (5) ----
        {
            id: 6,
            title: "Soil Health Restoration through Organic Matter Management",
            category: "soil-land",
            categoryLabel: "Soil & Land",
            excerpt: "Discover how organic matter management restores soil health, improves fertility, and supports sustainable agriculture.",
            image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/global-soil-partnership/en/",
            source: "Global Soil Partnership"
        },
        {
            id: 7,
            title: "Combatting Soil Erosion in Hilly Agricultural Terrains",
            category: "soil-land",
            categoryLabel: "Soil & Land",
            excerpt: "Learn effective strategies to combat soil erosion in hilly agricultural terrains and protect farmland.",
            image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&q=80",
            readTime: "8 min",
            link: "https://www.fao.org/soils-portal/soil-degradation-restoration/en/",
            source: "FAO Soils Portal"
        },
        {
            id: 8,
            title: "Managing Soil pH for Optimal Crop Nutrient Availability",
            category: "soil-land",
            categoryLabel: "Soil & Land",
            excerpt: "Learn how to manage soil pH for optimal nutrient availability and crop production in agricultural systems.",
            image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=600&q=80",
            readTime: "5 min",
            link: "https://www.fao.org/soils-portal/soil-biodiversity/en/",
            source: "FAO Soil Health Knowledge Hub"
        },
        {
            id: 9,
            title: "Cover Crops and Their Role in Soil Conservation",
            category: "soil-land",
            categoryLabel: "Soil & Land",
            excerpt: "Discover how cover crops contribute to soil conservation, erosion control, and improved soil health.",
            image: "https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?w=600&q=80",
            readTime: "6 min",
            link: "https://www.unccd.int/land-and-life/land-degradation-neutrality/overview",
            source: "UNCCD Land Conservation Portal"
        },
        {
            id: 10,
            title: "Salinity Management in Arid Zone Agriculture",
            category: "soil-land",
            categoryLabel: "Soil & Land",
            excerpt: "Explore salinity management strategies for sustainable agriculture in arid and semi-arid zones.",
            image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=600&q=80",
            readTime: "9 min",
            link: "https://www.fao.org/soils-portal/soil-management/management-of-salt-affected-soils/en/",
            source: "FAO Arid Lands Division"
        },

        // ---- IRRIGATION (5) ----
        {
            id: 11,
            title: "Smart Drip Irrigation Systems for Water Efficiency",
            category: "irrigation",
            categoryLabel: "Irrigation",
            excerpt: "Learn about smart drip irrigation systems and how they improve water efficiency in agricultural production.",
            image: "https://images.unsplash.com/photo-1563514227147-6d2ff665a6a0?w=600&q=80",
            readTime: "6 min",
            link: "https://www.fao.org/land-water/water/water-management/en/",
            source: "FAO Land & Water Division"
        },
        {
            id: 12,
            title: "Rainwater Harvesting Techniques for Small Farms",
            category: "irrigation",
            categoryLabel: "Irrigation",
            excerpt: "Discover effective rainwater harvesting techniques suitable for small farms and water-scarce regions.",
            image: "https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=600&q=80",
            readTime: "5 min",
            link: "https://www.fao.org/land-water/water/water-governance/en/",
            source: "International Water Management Institute"
        },
        {
            id: 13,
            title: "Solar-Powered Irrigation Solutions for Remote Regions",
            category: "irrigation",
            categoryLabel: "Irrigation",
            excerpt: "Explore solar-powered irrigation solutions that provide sustainable water access for remote agricultural regions.",
            image: "https://images.unsplash.com/photo-1509391365360-2e959784a276?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/land-water/water/spis/en/",
            source: "FAO SPIS Knowledge Platform"
        },
        {
            id: 14,
            title: "Sub-Surface Irrigation in Clay and Dense Soils",
            category: "irrigation",
            categoryLabel: "Irrigation",
            excerpt: "Learn about sub-surface irrigation techniques and their effectiveness in clay and dense soil conditions.",
            image: "https://images.unsplash.com/photo-1515150144380-bca9f1650ed9?w=600&q=80",
            readTime: "8 min",
            link: "https://www.iwmi.cgiar.org/issues/irrigation/",
            source: "IWMI Research Network"
        },
        {
            id: 15,
            title: "Irrigation Scheduling Based on Soil Moisture Sensors",
            category: "irrigation",
            categoryLabel: "Irrigation",
            excerpt: "Discover how soil moisture sensors can optimize irrigation scheduling for improved water efficiency.",
            image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&q=80",
            readTime: "6 min",
            link: "https://www.iwmi.cgiar.org/resources/publications/",
            source: "Precision Ag Water Journal"
        },

        // ---- FERTILIZERS (5) ----
        {
            id: 16,
            title: "Integrated Plant Nutrient Management Systems",
            category: "fertilizers",
            categoryLabel: "Fertilizers",
            excerpt: "Explore integrated plant nutrient management systems for sustainable and efficient crop production.",
            image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/agriculture/crops/thematic-sitemap/theme/spi/plantnutrition/en/",
            source: "FAO Plant Nutrition Series"
        },
        {
            id: 17,
            title: "The Role of Nitrogen, Phosphorus, and Potassium in Plant Growth",
            category: "fertilizers",
            categoryLabel: "Fertilizers",
            excerpt: "Learn about the essential roles of nitrogen, phosphorus, and potassium in plant growth and development.",
            image: "https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?w=600&q=80",
            readTime: "6 min",
            link: "https://www.ifa.org/fertilizer-use/agronomy",
            source: "International Fertilizer Association"
        },
        {
            id: 18,
            title: "Biofertilizers: Utilizing Microorganisms for Soil Fertility",
            category: "fertilizers",
            categoryLabel: "Fertilizers",
            excerpt: "Discover how biofertilizers utilize beneficial microorganisms to improve soil fertility and crop productivity.",
            image: "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=600&q=80",
            readTime: "8 min",
            link: "https://www.cgiar.org/news-events/news/biofertilizers/",
            source: "CGIAR Plant Health"
        },
        {
            id: 19,
            title: "Foliar Feeding: When and How to Apply Liquid Nutrients",
            category: "fertilizers",
            categoryLabel: "Fertilizers",
            excerpt: "Learn when and how to apply liquid nutrients through foliar feeding for optimal crop nutrition.",
            image: "https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?w=600&q=80",
            readTime: "5 min",
            link: "https://www.fao.org/3/x2002e/x2002e00.htm",
            source: "Practical Horticulture Today"
        },
        {
            id: 20,
            title: "Efficient Fertilizer Application to Prevent Nutrient Runoff",
            category: "fertilizers",
            categoryLabel: "Fertilizers",
            excerpt: "Learn strategies for efficient fertilizer application that minimize nutrient runoff and environmental impact.",
            image: "https://images.unsplash.com/photo-1584473457406-6240486418e9?w=600&q=80",
            readTime: "6 min",
            link: "https://www.fao.org/organicag/oa-portal/en/",
            source: "Environmental Farming Review"
        },

        // ---- PEST & DISEASE (5) ----
        {
            id: 21,
            title: "Integrated Pest Management (IPM) for Tropical Fruit Crops",
            category: "pest-disease",
            categoryLabel: "Pest & Disease",
            excerpt: "Explore integrated pest management strategies for tropical fruit crops to reduce pest damage sustainably.",
            image: "https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?w=600&q=80",
            readTime: "8 min",
            link: "https://www.fao.org/pest-and-pesticide-management/en/",
            source: "FAO Pest Management Secretariat"
        },
        {
            id: 22,
            title: "Identifying and Managing Fusarium Wilt in Banana Plants",
            category: "pest-disease",
            categoryLabel: "Pest & Disease",
            excerpt: "Learn to identify and manage Fusarium wilt disease in banana plants for healthier crop production.",
            image: "https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/food-chain-crisis/how-we-work/plant-protection/en/",
            source: "FAO Crop Protection Division"
        },
        {
            id: 23,
            title: "Biological Control Agents: Using Beneficial Insects against Pests",
            category: "pest-disease",
            categoryLabel: "Pest & Disease",
            excerpt: "Discover biological control agents and how beneficial insects can help manage agricultural pests.",
            image: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=600&q=80",
            readTime: "6 min",
            link: "https://www.cabi.org/topics/biocontrol/",
            source: "CABI Plantwise Initiative"
        },
        {
            id: 24,
            title: "Fall Armyworm Monitoring and Integrated Management",
            category: "pest-disease",
            categoryLabel: "Pest & Disease",
            excerpt: "Learn monitoring and integrated management strategies for Fall Armyworm in agricultural crops.",
            image: "https://images.unsplash.com/photo-1508873696983-2df515122519?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/fall-armyworm/en/",
            source: "FAO Fall Armyworm Action Portal"
        },
        {
            id: 25,
            title: "Desert Locust Early Warning and Surveillance Techniques",
            category: "pest-disease",
            categoryLabel: "Pest & Disease",
            excerpt: "Explore early warning and surveillance techniques for desert locust management in agriculture.",
            image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600&q=80",
            readTime: "5 min",
            link: "https://www.fao.org/locusts/en/",
            source: "FAO Locust Watch"
        },

        // ---- CLIMATE & WEATHER (5) ----
        {
            id: 26,
            title: "Climate-Smart Agriculture Practices for Drought-Prone Regions",
            category: "climate-weather",
            categoryLabel: "Climate & Weather",
            excerpt: "Discover climate-smart agriculture practices for drought-prone regions to build resilience and productivity.",
            image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/climate-smart-agriculture-sourcebook/en/",
            source: "FAO Climate-Smart Agriculture Hub"
        },
        {
            id: 27,
            title: "Agrometeorological Information Services for Farm Planning",
            category: "climate-weather",
            categoryLabel: "Climate & Weather",
            excerpt: "Learn how agrometeorological information services support farm planning and decision-making.",
            image: "https://images.unsplash.com/photo-1513002749550-c59d786b8e6c?w=600&q=80",
            readTime: "8 min",
            link: "https://public.wmo.int/en/our-mandate/climate/agrometeorology",
            source: "World Meteorological Organization"
        },
        {
            id: 28,
            title: "Microclimate Modification Strategies for Sensitive Crops",
            category: "climate-weather",
            categoryLabel: "Climate & Weather",
            excerpt: "Explore microclimate modification strategies to protect sensitive crops from extreme weather conditions.",
            image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=600&q=80",
            readTime: "6 min",
            link: "https://www.fao.org/land-water/water/drought/en/",
            source: "FAO Drought Management Portal"
        },
        {
            id: 29,
            title: "Weather Forecasting Tools Tailored for Smallholder Farmers",
            category: "climate-weather",
            categoryLabel: "Climate & Weather",
            excerpt: "Discover weather forecasting tools and services tailored for smallholder farmers.",
            image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&q=80",
            readTime: "5 min",
            link: "https://www.worldcoffee-research.org/work/climate-change",
            source: "Climate & Agriculture Network"
        },
        {
            id: 30,
            title: "Carbon Sequestration Practices in Modern Cropping Systems",
            category: "climate-weather",
            categoryLabel: "Climate & Weather",
            excerpt: "Learn about carbon sequestration practices in modern cropping systems for climate change mitigation.",
            image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=600&q=80",
            readTime: "9 min",
            link: "https://www.fao.org/soils-portal/soil-management/soil-carbon-sequestration/en/",
            source: "Global Carbon & Farming Journal"
        },

        // ---- AGRICULTURAL TECHNOLOGY (5) ----
        {
            id: 31,
            title: "Drones in Modern Farming: Crop Monitoring and Spraying",
            category: "agtech",
            categoryLabel: "Agricultural Technology",
            excerpt: "Explore how drones are transforming modern farming through crop monitoring and precision spraying.",
            image: "https://images.unsplash.com/photo-1527977966376-1c8408f9f108?w=600&q=80",
            readTime: "6 min",
            link: "https://www.fao.org/digital-agriculture/en/",
            source: "FAO Digital Agriculture Division"
        },
        {
            id: 32,
            title: "IoT Sensors for Real-Time Soil and Crop Analytics",
            category: "agtech",
            categoryLabel: "Agricultural Technology",
            excerpt: "Learn how IoT sensors provide real-time soil and crop analytics for precision farming.",
            image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&q=80",
            readTime: "7 min",
            link: "https://www.cgiar.org/initiative/digital-innovation/",
            source: "CGIAR Digital Innovation Initiative"
        },
        {
            id: 33,
            title: "AI-Driven Crop Disease Diagnosis via Mobile Applications",
            category: "agtech",
            categoryLabel: "Agricultural Technology",
            excerpt: "Discover AI-driven mobile applications for rapid crop disease diagnosis and management.",
            image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=600&q=80",
            readTime: "5 min",
            link: "https://www.plantvillage.psu.edu/",
            source: "PlantVillage AI Project"
        },
        {
            id: 34,
            title: "Sustainable Agricultural Mechanization for Smallholders",
            category: "agtech",
            categoryLabel: "Agricultural Technology",
            excerpt: "Explore sustainable agricultural mechanization solutions tailored for smallholder farmers.",
            image: "https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=600&q=80",
            readTime: "8 min",
            link: "https://www.fao.org/sustainable-agricultural-mechanization/en/",
            source: "FAO Mechanization Center"
        },
        {
            id: 35,
            title: "Solar Cold Storage Units for Off-Grid Value Chains",
            category: "agtech",
            categoryLabel: "Agricultural Technology",
            excerpt: "Learn about solar cold storage units and their role in off-grid agricultural value chains.",
            image: "https://images.unsplash.com/photo-1509391365360-2e959784a276?w=600&q=80",
            readTime: "6 min",
            link: "https://www.fao.org/sustainable-food-value-chains/en/",
            source: "FAO Food Value Chains"
        },

        // ---- ETHIOPIAN AGRICULTURE (5) ----
        {
            id: 36,
            title: "How Climate Resilience Practices Support Ethiopian Farmers",
            category: "ethiopian-agriculture",
            categoryLabel: "Ethiopian Agriculture",
            excerpt: "Explore how climate resilience practices are helping Ethiopian farmers adapt to changing conditions.",
            image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&q=80",
            readTime: "6 min",
            link: "https://moa.gov.et/",
            source: "Ministry of Agriculture Ethiopia"
        },
        {
            id: 37,
            title: "Teff Farming Innovations: Boosting Yields of Ethiopia's Staple Grain",
            category: "ethiopian-agriculture",
            categoryLabel: "Ethiopian Agriculture",
            excerpt: "Discover teff farming innovations that are boosting yields of Ethiopia's staple grain.",
            image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=600&q=80",
            readTime: "7 min",
            link: "https://eiar.gov.et/",
            source: "Ethiopian Institute of Agricultural Research"
        },
        {
            id: 38,
            title: "Modernizing Ethiopian Coffee Sector Production Strategies",
            category: "ethiopian-agriculture",
            categoryLabel: "Ethiopian Agriculture",
            excerpt: "Learn about strategies to modernize production in Ethiopia's coffee sector.",
            image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=600&q=80",
            readTime: "8 min",
            link: "https://www.eata.gov.et/",
            source: "Agricultural Transformation Institute Ethiopia"
        },
        {
            id: 39,
            title: "Sustainable Land Management in the Ethiopian Highlands",
            category: "ethiopian-agriculture",
            categoryLabel: "Ethiopian Agriculture",
            excerpt: "Explore sustainable land management practices in the Ethiopian highlands.",
            image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&q=80",
            readTime: "7 min",
            link: "https://www.worldbank.org/en/results/2021/04/15/restoring-land-and-livelihoods-in-ethiopia",
            source: "World Bank Ethiopia Projects"
        },
        {
            id: 40,
            title: "Wheat Self-Sufficiency Initiatives in Ethiopian Lowlands",
            category: "ethiopian-agriculture",
            categoryLabel: "Ethiopian Agriculture",
            excerpt: "Learn about wheat self-sufficiency initiatives and programs in Ethiopian lowland regions.",
            image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=600&q=80",
            readTime: "6 min",
            link: "https://moa.gov.et/programs",
            source: "Ministry of Agriculture Ethiopia"
        },

        // ---- LIVESTOCK (5) ----
        {
            id: 41,
            title: "Sustainable Dairy Cattle Feeding Strategies for Smallholders",
            category: "livestock",
            categoryLabel: "Livestock",
            excerpt: "Discover sustainable dairy cattle feeding strategies for smallholder farmers.",
            image: "https://images.unsplash.com/photo-1546445317-29f4545f9d52?w=600&q=80",
            readTime: "7 min",
            link: "https://www.ilri.org/research",
            source: "International Livestock Research Institute"
        },
        {
            id: 42,
            title: "Poultry Health Management and Biosecurity Practices",
            category: "livestock",
            categoryLabel: "Livestock",
            excerpt: "Learn about poultry health management and biosecurity practices for disease prevention.",
            image: "https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=600&q=80",
            readTime: "6 min",
            link: "https://www.fao.org/animal-health/en/",
            source: "FAO Animal Health Division"
        },
        {
            id: 43,
            title: "Small Ruminant Production: Goats and Sheep Management",
            category: "livestock",
            categoryLabel: "Livestock",
            excerpt: "Explore small ruminant production and management practices for goats and sheep.",
            image: "https://images.unsplash.com/photo-1484557985045-edf25e08da73?w=600&q=80",
            readTime: "8 min",
            link: "https://www.fao.org/ag/againfo/themes/en/meat/home.html",
            source: "FAO Livestock Knowledge Base"
        },
        {
            id: 44,
            title: "Silage Preparation and Preservation for Dry Season Forage",
            category: "livestock",
            categoryLabel: "Livestock",
            excerpt: "Learn about silage preparation and preservation techniques for dry season forage availability.",
            image: "https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=600&q=80",
            readTime: "6 min",
            link: "https://www.ilri.org/forage-and-feed",
            source: "ILRI Feed & Forage Knowledge Base"
        },
        {
            id: 45,
            title: "Vector-Borne Disease Control in Tropical Livestock Systems",
            category: "livestock",
            categoryLabel: "Livestock",
            excerpt: "Discover strategies for vector-borne disease control in tropical livestock production systems.",
            image: "https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/paat/en/",
            source: "FAO Trypanosomiasis Program"
        },

        // ---- SUSTAINABLE AGRICULTURE (5) ----
        {
            id: 46,
            title: "Agroecology Principles and Sustainable Food Systems",
            category: "sustainable",
            categoryLabel: "Sustainable Agriculture",
            excerpt: "Explore agroecology principles and their role in building sustainable food systems.",
            image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=600&q=80",
            readTime: "7 min",
            link: "https://www.fao.org/agroecology/overview/en/",
            source: "FAO Agroecology Hub"
        },
        {
            id: 47,
            title: "Agroforestry Systems: Integrating Trees with Food Crops",
            category: "sustainable",
            categoryLabel: "Sustainable Agriculture",
            excerpt: "Learn about agroforestry systems and how integrating trees with food crops benefits agriculture.",
            image: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=600&q=80",
            readTime: "8 min",
            link: "https://www.cifor-icraf.org/",
            source: "World Agroforestry Center"
        },
        {
            id: 48,
            title: "Conservation Agriculture: Principles and Implementation",
            category: "sustainable",
            categoryLabel: "Sustainable Agriculture",
            excerpt: "Discover conservation agriculture principles and practical implementation strategies.",
            image: "https://images.unsplash.com/photo-1592417817098-8f3d6eb231fc?w=600&q=80",
            readTime: "6 min",
            link: "https://www.fao.org/conservation-agriculture/en/",
            source: "FAO Conservation Agriculture"
        },
        {
            id: 49,
            title: "Water Footprint Reduction in Commercial Farming",
            category: "sustainable",
            categoryLabel: "Sustainable Agriculture",
            excerpt: "Learn strategies to reduce water footprints in commercial farming operations.",
            image: "https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=600&q=80",
            readTime: "6 min",
            link: "https://www.waterfootprint.org/",
            source: "Water Footprint Network"
        },
        {
            id: 50,
            title: "Organic Farming Standards and Certification Guidelines",
            category: "sustainable",
            categoryLabel: "Sustainable Agriculture",
            excerpt: "Explore organic farming standards and certification guidelines for sustainable production.",
            image: "https://images.unsplash.com/photo-1584473457406-6240486418e9?w=600&q=80",
            readTime: "8 min",
            link: "https://www.ifoam.bio/",
            source: "IFOAM Organics International"
        }
    ];

    // ----- 2. STATE -----
    let currentCategory = 'all';
    let searchQuery = '';
    const articlesPerPage = 9;
    let currentPage = 1;

    // ----- 3. DOM REFS -----
    const grid = document.getElementById('articlesGrid');
    const emptyState = document.getElementById('emptyState');
    const articleCount = document.getElementById('articleCount');
    const filterPanel = document.getElementById('filterPanel');
    const filterToggle = document.getElementById('filterToggle');
    const filterClose = document.getElementById('filterClose');
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const filterOptions = document.querySelectorAll('.filter-option');

    // ----- 4. RENDER ARTICLES -----
    function renderArticles() {
        let filtered = articles;

        if (currentCategory !== 'all') {
            filtered = filtered.filter(a => a.category === currentCategory);
        }

        if (searchQuery.trim() !== '') {
            const query = searchQuery.toLowerCase().trim();
            filtered = filtered.filter(a =>
                a.title.toLowerCase().includes(query) ||
                a.excerpt.toLowerCase().includes(query) ||
                a.categoryLabel.toLowerCase().includes(query)
            );
        }

        articleCount.textContent = `${filtered.length} articles`;

        if (filtered.length === 0) {
            grid.innerHTML = '';
            emptyState.style.display = 'block';
            return;
        }
        emptyState.style.display = 'none';

        const totalPages = Math.ceil(filtered.length / articlesPerPage);
        if (currentPage > totalPages) currentPage = totalPages || 1;
        if (currentPage < 1) currentPage = 1;

        const start = (currentPage - 1) * articlesPerPage;
        const end = start + articlesPerPage;
        const pageArticles = filtered.slice(start, end);

        grid.innerHTML = '';
        pageArticles.forEach(article => {
            const card = document.createElement('div');
            card.className = 'article-card';
            card.innerHTML = `
                <div class="article-image" style="background-image: url('${article.image}');"></div>
                <div class="article-content">
                    <span class="article-category">${article.categoryLabel}</span>
                    <h3 class="article-title">${article.title}</h3>
                    <p class="article-excerpt">${article.excerpt}</p>
                    <div class="article-footer">
                        <span class="article-read-time">📖 ${article.readTime}</span>
                        <button class="btn-read" data-id="${article.id}">Read Article →</button>
                    </div>
                </div>
            `;
            grid.appendChild(card);

            const readBtn = card.querySelector('.btn-read');
            readBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                const id = parseInt(this.dataset.id);
                const article = articles.find(a => a.id === id);
                window.open(article.link, '_blank');
            });

            card.addEventListener('click', function() {
                const id = parseInt(this.querySelector('.btn-read').dataset.id);
                const article = articles.find(a => a.id === id);
                window.open(article.link, '_blank');
            });
        });

        updatePagination(totalPages);
    }

    // ----- 5. PAGINATION -----
    function updatePagination(totalPages) {
        const existingPagination = document.querySelector('.pagination');
        if (existingPagination) existingPagination.remove();

        if (totalPages <= 1) return;

        const pagination = document.createElement('div');
        pagination.className = 'pagination';
        pagination.innerHTML = `
            <button class="page-btn" data-page="prev" ${currentPage === 1 ? 'disabled' : ''}>← Previous</button>
            <span>Page ${currentPage} of ${totalPages}</span>
            <button class="page-btn" data-page="next" ${currentPage === totalPages ? 'disabled' : ''}>Next →</button>
        `;
        grid.parentNode.insertBefore(pagination, grid.nextSibling);

        pagination.querySelectorAll('.page-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const direction = this.dataset.page;
                if (direction === 'prev' && currentPage > 1) {
                    currentPage--;
                } else if (direction === 'next' && currentPage < totalPages) {
                    currentPage++;
                }
                renderArticles();
                grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
        });
    }

    // ----- 6. FILTER TOGGLE -----
    filterToggle.addEventListener('click', function() {
        filterPanel.classList.toggle('open');
    });

    filterClose.addEventListener('click', function() {
        filterPanel.classList.remove('open');
    });

    document.addEventListener('click', function(e) {
        if (filterPanel.classList.contains('open')) {
            const isClickInside = filterPanel.contains(e.target) || filterToggle.contains(e.target);
            if (!isClickInside) {
                filterPanel.classList.remove('open');
            }
        }
    });

    // ----- 7. FILTER OPTIONS -----
    filterOptions.forEach(option => {
        option.addEventListener('click', function() {
            filterOptions.forEach(o => o.classList.remove('active'));
            this.classList.add('active');
            currentCategory = this.dataset.category;
            currentPage = 1;
            renderArticles();
            filterPanel.classList.remove('open');
        });
    });

    // ----- 8. SEARCH -----
    function performSearch() {
        searchQuery = searchInput.value;
        currentPage = 1;
        renderArticles();
    }

    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });

    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            this.value = '';
            searchQuery = '';
            currentPage = 1;
            renderArticles();
            this.blur();
        }
    });

    // ----- 9. INITIALIZE -----
    renderArticles();

    console.log('📚 Agri Articles loaded successfully!');
    console.log(`📄 Total articles: ${articles.length}`);
    console.log(`📂 Categories: ${new Set(articles.map(a => a.categoryLabel)).size}`);

})();