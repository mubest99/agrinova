(function() {
    "use strict";

    // ============================================================
    // DATA HELPERS
    // ============================================================

    function getFarmer() {
        let raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getCrops() {
        let raw = localStorage.getItem('agrinova_crops_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getDailyRecords() {
        let raw = localStorage.getItem('agrinova_daily_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getTasks() {
        let raw = localStorage.getItem('agrinova_tasks_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getFarmRecords() {
        let raw = localStorage.getItem('agrinova_farm_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getTransactions() {
        let raw = localStorage.getItem('agrinova_finance_transactions');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveTransactions(transactions) {
        localStorage.setItem('agrinova_finance_transactions', JSON.stringify(transactions));
    }

    function getGoals() {
        let raw = localStorage.getItem('agrinova_finance_goals');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveGoals(goals) {
        localStorage.setItem('agrinova_finance_goals', JSON.stringify(goals));
    }

    function getBudgets() {
        let raw = localStorage.getItem('agrinova_finance_budgets');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveBudgets(budgets) {
        localStorage.setItem('agrinova_finance_budgets', JSON.stringify(budgets));
    }

    // ============================================================
    // STATE
    // ============================================================

    let state = {
        transactions: [],
        goals: [],
        budgets: [],
        dateRange: 'month',
        timelinePeriod: 'monthly',
        selectedTransaction: null,
        customStartDate: null,
        customEndDate: null
    };

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova Farm Finance Initializing...');
        
        state.transactions = getTransactions();
        state.goals = getGoals();
        state.budgets = getBudgets();
        
        updateDate();
        updateProfile();
        setupProfileImage();
        setupDropdown();
        fetchWeather();
        populateCropDropdown();
        
        // Set default date for forms
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('transDate').value = today;
        document.getElementById('transferDate').value = today;
        document.getElementById('goalDate').value = today;
        
        // Set default budget dates
        const firstDay = new Date();
        firstDay.setDate(1);
        document.getElementById('budgetStart').value = firstDay.toISOString().split('T')[0];
        
        const lastDay = new Date(firstDay);
        lastDay.setMonth(lastDay.getMonth() + 1);
        lastDay.setDate(0);
        document.getElementById('budgetEnd').value = lastDay.toISOString().split('T')[0];
        
        // Setup form submissions
        document.getElementById('transactionForm').addEventListener('submit', saveTransaction);
        document.getElementById('goalForm').addEventListener('submit', saveGoal);
        document.getElementById('transferForm').addEventListener('submit', saveTransfer);
        document.getElementById('budgetForm').addEventListener('submit', saveBudget);
        
        // Setup transaction type change
        document.getElementById('transTypeSelect').addEventListener('change', updateTransactionType);
        
        renderAll();
        
        console.log('AgriNova Farm Finance Ready.');
    }

    // ============================================================
    // DATE & GREETING
    // ============================================================

    function updateDate() {
        const now = new Date();
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        
        document.getElementById('dateDay').textContent = days[now.getDay()];
        document.getElementById('dateFull').textContent = `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    }

    function updateProfile() {
        const farmer = getFarmer();
        if (!farmer) return;

        const name = farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('navName').textContent = name;
        document.getElementById('pdName').textContent = name;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || '—';
        
        const city = farmer.city || '—';
        const region = farmer.region || '—';
        document.getElementById('pdLocation').textContent = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdFarmland').textContent = farmer.hectares ? `${farmer.hectares} ha` : '—';
    }

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }
        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // WEATHER
    // ============================================================

    async function fetchWeather() {
        try {
            const farmer = getFarmer();
            const city = farmer?.city || 'Addis Ababa';
            
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        await getWeatherData(latitude, longitude);
                    },
                    async () => {
                        await getWeatherByCity(city);
                    }
                );
            } else {
                await getWeatherByCity(city);
            }
        } catch (e) {
            console.warn('Weather error:', e);
            document.getElementById('navTemp').textContent = '--°C';
        }
    }

    async function getWeatherData(lat, lon) {
        try {
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`;
            const resp = await fetch(url);
            if (!resp.ok) throw new Error('Weather API error');
            const data = await resp.json();
            if (data.current_weather) {
                const temp = data.current_weather.temperature !== undefined ? `${Math.round(data.current_weather.temperature)}°C` : '--°C';
                document.getElementById('navTemp').textContent = temp;
            }
        } catch (e) {
            console.warn('Weather fetch error:', e);
        }
    }

    async function getWeatherByCity(city) {
        try {
            const geoResp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
            const geoData = await geoResp.json();
            if (geoData && geoData.length > 0) {
                const { lat, lon } = geoData[0];
                await getWeatherData(parseFloat(lat), parseFloat(lon));
            }
        } catch (e) {
            console.warn('City geocode error:', e);
        }
    }

    // ============================================================
    // POPULATE CROP DROPDOWN
    // ============================================================

    function populateCropDropdown() {
        const crops = getCrops();
        const select = document.getElementById('transCrop');
        select.innerHTML = '<option value="">None</option>';
        crops.forEach(crop => {
            select.innerHTML += `<option value="${crop.name}">${crop.name}</option>`;
        });
        if (crops.length === 0) {
            select.innerHTML += '<option value="" disabled>No crops added yet</option>';
        }
    }

    // ============================================================
    // TRANSACTION FUNCTIONS
    // ============================================================

    window.openTransactionModal = function(type) {
        document.getElementById('editTransactionId').value = '';
        document.getElementById('transactionModalTitle').textContent = type === 'income' ? 'Add Income' : 'Add Expense';
        document.getElementById('transactionType').value = type;
        document.getElementById('transTypeSelect').value = type;
        document.getElementById('transAmount').value = '';
        document.getElementById('transDescription').value = '';
        document.getElementById('transNotes').value = '';
        document.getElementById('transDate').value = new Date().toISOString().split('T')[0];
        
        // Set category based on type
        const categorySelect = document.getElementById('transCategory');
        if (type === 'income') {
            categorySelect.innerHTML = `
                <option value="Crop Sales">Crop Sales</option>
                <option value="Livestock Sales">Livestock Sales</option>
                <option value="Product Sales">Product Sales</option>
                <option value="Other Income">Other Income</option>
            `;
        } else {
            categorySelect.innerHTML = `
                <option value="Seeds">Seeds</option>
                <option value="Fertilizer">Fertilizer</option>
                <option value="Labor">Labor</option>
                <option value="Irrigation">Irrigation</option>
                <option value="Pest Management">Pest Management</option>
                <option value="Disease Management">Disease Management</option>
                <option value="Equipment">Equipment</option>
                <option value="Transport">Transport</option>
                <option value="Land">Land</option>
                <option value="Other">Other</option>
            `;
        }
        
        populateCropDropdown();
        openModal('transactionModal');
    };

    function updateTransactionType() {
        const type = document.getElementById('transTypeSelect').value;
        document.getElementById('transactionType').value = type;
        document.getElementById('transactionModalTitle').textContent = 
            type === 'income' ? 'Add Income' : type === 'expense' ? 'Add Expense' : 'Add Transfer';
    }

    function saveTransaction(event) {
        event.preventDefault();
        
        const editId = document.getElementById('editTransactionId').value;
        const type = document.getElementById('transactionType').value;
        const category = document.getElementById('transCategory').value;
        const description = document.getElementById('transDescription').value.trim();
        const crop = document.getElementById('transCrop').value;
        const payment = document.getElementById('transPayment').value;
        const amount = parseFloat(document.getElementById('transAmount').value);
        const date = document.getElementById('transDate').value;
        const notes = document.getElementById('transNotes').value.trim();

        if (!amount || amount <= 0) {
            showToast('Please enter a valid amount.', 'error');
            return;
        }

        if (!date) {
            showToast('Please select a date.', 'error');
            return;
        }

        let transactions = getTransactions();

        if (editId) {
            // Edit existing
            const index = transactions.findIndex(t => t.id === editId);
            if (index !== -1) {
                transactions[index] = {
                    ...transactions[index],
                    type,
                    category,
                    description: description || `${type} transaction`,
                    crop: crop || null,
                    payment,
                    amount,
                    date,
                    notes,
                    updatedAt: new Date().toISOString()
                };
                showToast('Transaction updated successfully!', 'success');
            }
        } else {
            // Create new
            const newTransaction = {
                id: 'trans_' + Date.now(),
                type,
                category,
                description: description || `${type} transaction`,
                crop: crop || null,
                payment,
                amount,
                date,
                notes,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            transactions.push(newTransaction);
            showToast('Transaction added successfully!', 'success');
        }

        saveTransactions(transactions);
        state.transactions = transactions;
        closeModal('transactionModal');
        renderAll();
    }

    window.editTransaction = function(id) {
        const transactions = getTransactions();
        const transaction = transactions.find(t => t.id === id);
        if (!transaction) return;

        document.getElementById('editTransactionId').value = id;
        document.getElementById('transactionModalTitle').textContent = 'Edit Transaction';
        document.getElementById('transactionType').value = transaction.type;
        document.getElementById('transTypeSelect').value = transaction.type;
        document.getElementById('transCategory').value = transaction.category;
        document.getElementById('transDescription').value = transaction.description || '';
        document.getElementById('transCrop').value = transaction.crop || '';
        document.getElementById('transPayment').value = transaction.payment || 'Cash';
        document.getElementById('transAmount').value = transaction.amount;
        document.getElementById('transDate').value = transaction.date;
        document.getElementById('transNotes').value = transaction.notes || '';
        
        // Update category options based on type
        const categorySelect = document.getElementById('transCategory');
        if (transaction.type === 'income') {
            categorySelect.innerHTML = `
                <option value="Crop Sales">Crop Sales</option>
                <option value="Livestock Sales">Livestock Sales</option>
                <option value="Product Sales">Product Sales</option>
                <option value="Other Income">Other Income</option>
            `;
        } else {
            categorySelect.innerHTML = `
                <option value="Seeds">Seeds</option>
                <option value="Fertilizer">Fertilizer</option>
                <option value="Labor">Labor</option>
                <option value="Irrigation">Irrigation</option>
                <option value="Pest Management">Pest Management</option>
                <option value="Disease Management">Disease Management</option>
                <option value="Equipment">Equipment</option>
                <option value="Transport">Transport</option>
                <option value="Land">Land</option>
                <option value="Other">Other</option>
            `;
        }
        categorySelect.value = transaction.category;
        
        populateCropDropdown();
        openModal('transactionModal');
    };

    window.deleteTransaction = function(id) {
        if (!confirm('Are you sure you want to delete this transaction?')) return;
        
        let transactions = getTransactions();
        transactions = transactions.filter(t => t.id !== id);
        saveTransactions(transactions);
        state.transactions = transactions;
        renderAll();
        showToast('Transaction deleted.', 'warning');
    };

    // ============================================================
    // TRANSFER FUNCTIONS
    // ============================================================

    window.openTransferModal = function() {
        document.getElementById('transferForm').reset();
        document.getElementById('transferDate').value = new Date().toISOString().split('T')[0];
        openModal('transferModal');
    };

    function saveTransfer(event) {
        event.preventDefault();
        
        const from = document.getElementById('transferFrom').value;
        const to = document.getElementById('transferTo').value;
        const amount = parseFloat(document.getElementById('transferAmount').value);
        const date = document.getElementById('transferDate').value;
        const notes = document.getElementById('transferNotes').value.trim();

        if (!amount || amount <= 0) {
            showToast('Please enter a valid amount.', 'error');
            return;
        }

        if (from === to) {
            showToast('From and To cannot be the same.', 'error');
            return;
        }

        const transfer = {
            id: 'transfer_' + Date.now(),
            type: 'transfer',
            category: 'Transfer',
            description: `${from} → ${to}`,
            crop: null,
            payment: 'Transfer',
            amount: amount,
            date: date,
            notes: notes || '',
            from: from,
            to: to,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        let transactions = getTransactions();
        transactions.push(transfer);
        saveTransactions(transactions);
        state.transactions = transactions;
        closeModal('transferModal');
        renderAll();
        showToast('Transfer recorded successfully!', 'success');
    }

    // ============================================================
    // GOAL FUNCTIONS
    // ============================================================

    window.openGoalModal = function(goalId) {
        document.getElementById('editGoalId').value = '';
        document.getElementById('goalModalTitle').textContent = 'Create Financial Goal';
        document.getElementById('goalForm').reset();
        document.getElementById('goalDate').value = new Date().toISOString().split('T')[0];
        
        if (goalId) {
            const goals = getGoals();
            const goal = goals.find(g => g.id === goalId);
            if (goal) {
                document.getElementById('editGoalId').value = goalId;
                document.getElementById('goalModalTitle').textContent = 'Edit Goal';
                document.getElementById('goalType').value = goal.type || 'savings';
                document.getElementById('goalName').value = goal.name || '';
                document.getElementById('goalTarget').value = goal.target || '';
                document.getElementById('goalCurrent').value = goal.current || 0;
                document.getElementById('goalDate').value = goal.targetDate || '';
                document.getElementById('goalNotes').value = goal.notes || '';
            }
        }
        
        openModal('goalModal');
    };

    function saveGoal(event) {
        event.preventDefault();
        
        const editId = document.getElementById('editGoalId').value;
        const type = document.getElementById('goalType').value;
        const name = document.getElementById('goalName').value.trim();
        const target = parseFloat(document.getElementById('goalTarget').value);
        const current = parseFloat(document.getElementById('goalCurrent').value) || 0;
        const targetDate = document.getElementById('goalDate').value;
        const notes = document.getElementById('goalNotes').value.trim();

        if (!name || !target || target <= 0) {
            showToast('Please fill in all required fields.', 'error');
            return;
        }

        let goals = getGoals();

        if (editId) {
            const index = goals.findIndex(g => g.id === editId);
            if (index !== -1) {
                goals[index] = {
                    ...goals[index],
                    type,
                    name,
                    target,
                    current,
                    targetDate,
                    notes,
                    updatedAt: new Date().toISOString()
                };
                showToast('Goal updated successfully!', 'success');
            }
        } else {
            const newGoal = {
                id: 'goal_' + Date.now(),
                type,
                name,
                target,
                current,
                targetDate,
                notes,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            goals.push(newGoal);
            showToast('Goal created successfully!', 'success');
        }

        saveGoals(goals);
        state.goals = goals;
        closeModal('goalModal');
        renderAll();
    }

    window.deleteGoal = function(id) {
        if (!confirm('Delete this goal?')) return;
        let goals = getGoals();
        goals = goals.filter(g => g.id !== id);
        saveGoals(goals);
        state.goals = goals;
        renderAll();
        showToast('Goal deleted.', 'warning');
    };

    window.addGoalProgress = function(goalId) {
        const amount = prompt('Enter amount to add:');
        if (!amount) return;
        const numAmount = parseFloat(amount);
        if (isNaN(numAmount) || numAmount <= 0) {
            showToast('Invalid amount.', 'error');
            return;
        }
        
        let goals = getGoals();
        const goal = goals.find(g => g.id === goalId);
        if (goal) {
            goal.current = (goal.current || 0) + numAmount;
            goal.updatedAt = new Date().toISOString();
            saveGoals(goals);
            state.goals = goals;
            renderAll();
            showToast(`Added ${numAmount} ETB to ${goal.name}!`, 'success');
        }
    };

    // ============================================================
    // BUDGET FUNCTIONS
    // ============================================================

    window.openBudgetModal = function(budgetId) {
        document.getElementById('editBudgetId').value = '';
        document.getElementById('budgetModalTitle').textContent = 'Create Budget';
        document.getElementById('budgetForm').reset();
        
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        document.getElementById('budgetStart').value = firstDay.toISOString().split('T')[0];
        document.getElementById('budgetEnd').value = lastDay.toISOString().split('T')[0];
        
        if (budgetId) {
            const budgets = getBudgets();
            const budget = budgets.find(b => b.id === budgetId);
            if (budget) {
                document.getElementById('editBudgetId').value = budgetId;
                document.getElementById('budgetModalTitle').textContent = 'Edit Budget';
                document.getElementById('budgetName').value = budget.name || '';
                document.getElementById('budgetStart').value = budget.startDate || '';
                document.getElementById('budgetEnd').value = budget.endDate || '';
                document.getElementById('budgetAmount').value = budget.amount || '';
            }
        }
        
        openModal('budgetModal');
    };

    function saveBudget(event) {
        event.preventDefault();
        
        const editId = document.getElementById('editBudgetId').value;
        const name = document.getElementById('budgetName').value.trim();
        const startDate = document.getElementById('budgetStart').value;
        const endDate = document.getElementById('budgetEnd').value;
        const amount = parseFloat(document.getElementById('budgetAmount').value);

        if (!name || !amount || amount <= 0 || !startDate || !endDate) {
            showToast('Please fill in all required fields.', 'error');
            return;
        }

        if (new Date(startDate) > new Date(endDate)) {
            showToast('Start date must be before end date.', 'error');
            return;
        }

        let budgets = getBudgets();

        if (editId) {
            const index = budgets.findIndex(b => b.id === editId);
            if (index !== -1) {
                budgets[index] = {
                    ...budgets[index],
                    name,
                    startDate,
                    endDate,
                    amount,
                    updatedAt: new Date().toISOString()
                };
                showToast('Budget updated successfully!', 'success');
            }
        } else {
            const newBudget = {
                id: 'budget_' + Date.now(),
                name,
                startDate,
                endDate,
                amount,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            budgets.push(newBudget);
            showToast('Budget created successfully!', 'success');
        }

        saveBudgets(budgets);
        state.budgets = budgets;
        closeModal('budgetModal');
        renderAll();
    }

    window.deleteBudget = function(id) {
        if (!confirm('Delete this budget?')) return;
        let budgets = getBudgets();
        budgets = budgets.filter(b => b.id !== id);
        saveBudgets(budgets);
        state.budgets = budgets;
        renderAll();
        showToast('Budget deleted.', 'warning');
    };

    // ============================================================
    // DATE RANGE
    // ============================================================

    window.updateFinance = function() {
        const range = document.getElementById('dateRange').value;
        state.dateRange = range;
        renderAll();
    };

    function getFilteredTransactions() {
        const range = state.dateRange;
        let transactions = state.transactions;
        const now = new Date();
        let startDate = new Date(0);
        let endDate = new Date();

        if (range === 'week') {
            startDate = new Date(now);
            startDate.setDate(now.getDate() - 7);
        } else if (range === 'month') {
            startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        } else if (range === 'year') {
            startDate = new Date(now.getFullYear(), 0, 1);
        } else if (range === 'custom') {
            // For custom range, use all
            return transactions;
        }

        return transactions.filter(t => {
            const tDate = new Date(t.date);
            return tDate >= startDate && tDate <= endDate;
        });
    }

    // ============================================================
    // TIMELINE
    // ============================================================

    window.setTimelinePeriod = function(period) {
        state.timelinePeriod = period;
        document.querySelectorAll('.timeline-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.period === period);
        });
        renderTimeline();
    };

    function renderTimeline() {
        const container = document.getElementById('timelineContainer');
        const transactions = getFilteredTransactions();
        const period = state.timelinePeriod;

        if (transactions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-chart-line"></i>
                    <p>Your financial timeline will appear as you record farm income and expenses.</p>
                    <button class="btn-primary btn-sm" onclick="openTransactionModal('income')">
                        <i class="fas fa-plus"></i> Add First Transaction
                    </button>
                </div>
            `;
            return;
        }

        // Group transactions by period
        const grouped = {};
        transactions.forEach(t => {
            const date = new Date(t.date);
            let key;
            if (period === 'daily') {
                key = date.toISOString().split('T')[0];
            } else if (period === 'weekly') {
                const weekStart = new Date(date);
                weekStart.setDate(date.getDate() - date.getDay());
                key = weekStart.toISOString().split('T')[0];
            } else if (period === 'monthly') {
                key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            } else { // yearly
                key = `${date.getFullYear()}`;
            }
            
            if (!grouped[key]) grouped[key] = { income: 0, expense: 0 };
            if (t.type === 'income') {
                grouped[key].income += t.amount;
            } else if (t.type === 'expense') {
                grouped[key].expense += t.amount;
            }
        });

        // Sort keys
        const sortedKeys = Object.keys(grouped).sort();

        let html = `
            <div style="height:250px; position:relative; padding:0.5rem 0; overflow-x:auto;">
                <div style="display:flex; gap:1rem; align-items:flex-end; height:220px; min-width:${Math.max(sortedKeys.length * 60, 300)}px;">
        `;

        const maxValue = Math.max(...Object.values(grouped).map(v => Math.max(v.income, v.expense)), 1);

        sortedKeys.forEach(key => {
            const data = grouped[key];
            const incomeHeight = (data.income / maxValue) * 180;
            const expenseHeight = (data.expense / maxValue) * 180;
            const netHeight = ((data.income - data.expense) / maxValue) * 180;
            
            let label = key;
            if (period === 'daily') {
                const d = new Date(key);
                label = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            } else if (period === 'weekly') {
                const d = new Date(key);
                label = `W${Math.ceil(d.getDate() / 7)}`;
            } else if (period === 'monthly') {
                const [year, month] = key.split('-');
                label = `${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][parseInt(month)-1]} ${year}`;
            }

            html += `
                <div style="display:flex; flex-direction:column; align-items:center; gap:0.2rem; flex:1; min-width:40px;">
                    <div style="display:flex; align-items:flex-end; gap:3px; height:200px;">
                        <div style="width:16px; height:${Math.max(incomeHeight, 2)}px; background:#2F6B46; border-radius:3px 3px 0 0; transition:height 0.5s ease;"></div>
                        <div style="width:16px; height:${Math.max(expenseHeight, 2)}px; background:#B94A48; border-radius:3px 3px 0 0; transition:height 0.5s ease;"></div>
                        <div style="width:16px; height:${netHeight >= 0 ? Math.max(netHeight, 2) : 2}px; background:${netHeight >= 0 ? '#123D2B' : '#B94A48'}; border-radius:3px 3px 0 0; transition:height 0.5s ease; border-top:${netHeight < 0 ? '2px solid #B94A48' : 'none'};"></div>
                    </div>
                    <div style="font-size:0.65rem; color:#6F766F; text-align:center; max-width:50px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${label}</div>
                </div>
            `;
        });

        html += `
                </div>
            </div>
            <div style="display:flex; gap:1.5rem; margin-top:0.5rem; justify-content:center; font-size:0.75rem; color:#6F766F;">
                <span><span style="display:inline-block; width:12px; height:12px; background:#2F6B46; border-radius:3px;"></span> Income</span>
                <span><span style="display:inline-block; width:12px; height:12px; background:#B94A48; border-radius:3px;"></span> Expenses</span>
                <span><span style="display:inline-block; width:12px; height:12px; background:#123D2B; border-radius:3px;"></span> Net</span>
            </div>
        `;

        container.innerHTML = html;
    }

    // ============================================================
    // RENDER ALL FUNCTIONS
    // ============================================================

    function renderAll() {
        renderOverview();
        renderTimeline();
        renderGoals();
        renderExpenseDistribution();
        renderIncomeExpenseAnalysis();
        renderCropPerformance();
        renderBudget();
        renderTransactions();
        renderConnectedRecords();
    }

    function renderOverview() {
        const transactions = getFilteredTransactions();
        
        let totalIncome = 0;
        let totalExpenses = 0;
        let incomeCount = 0;
        let expenseCount = 0;

        transactions.forEach(t => {
            if (t.type === 'income') {
                totalIncome += t.amount;
                incomeCount++;
            } else if (t.type === 'expense') {
                totalExpenses += t.amount;
                expenseCount++;
            }
        });

        const netProfit = totalIncome - totalExpenses;

        document.getElementById('totalIncome').textContent = `ETB ${totalIncome.toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: 0})}`;
        document.getElementById('totalExpenses').textContent = `ETB ${totalExpenses.toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: 0})}`;
        document.getElementById('netProfit').textContent = `ETB ${netProfit.toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: 0})}`;
        document.getElementById('netProfit').style.color = netProfit >= 0 ? '#123D2B' : '#B94A48';
        document.getElementById('totalTransactions').textContent = transactions.length;
        document.getElementById('transactionDetail').textContent = `${incomeCount} income · ${expenseCount} expense`;
    }

    function renderGoals() {
        const container = document.getElementById('goalsContainer');
        const goals = state.goals;

        if (goals.length === 0) {
            container.innerHTML = `
                <div class="empty-state" style="padding:1.5rem;">
                    <i class="fas fa-bullseye"></i>
                    <p>Set a financial goal for your farm.</p>
                    <button class="btn-primary btn-sm" onclick="openGoalModal()">
                        <i class="fas fa-plus"></i> Create Goal
                    </button>
                </div>
            `;
            return;
        }

        let html = '';
        goals.forEach(goal => {
            const progress = goal.target > 0 ? (goal.current / goal.target * 100) : 0;
            const typeLabel = goal.type === 'savings' ? '💰 Savings' : '🚜 Equipment';
            
            html += `
                <div class="goal-item">
                    <div class="goal-header">
                        <span class="goal-name">${goal.name}</span>
                        <span class="goal-type">${typeLabel}</span>
                    </div>
                    <div class="goal-progress">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${Math.min(progress, 100)}%;"></div>
                        </div>
                        <div class="progress-text">
                            <span>${goal.current.toLocaleString()} ETB / ${goal.target.toLocaleString()} ETB</span>
                            <span>${progress.toFixed(0)}%</span>
                        </div>
                    </div>
                    ${goal.targetDate ? `<div style="font-size:0.75rem; color:#6F766F; margin-top:0.2rem;">Target: ${new Date(goal.targetDate).toLocaleDateString()}</div>` : ''}
                    <div class="goal-actions">
                        <button class="btn-secondary btn-sm" onclick="addGoalProgress('${goal.id}')">
                            <i class="fas fa-plus"></i> Add
                        </button>
                        <button class="btn-secondary btn-sm" onclick="openGoalModal('${goal.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-danger" style="font-size:0.7rem; padding:0.2rem 0.6rem; border-radius:4px; color:#B94A48;" onclick="deleteGoal('${goal.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    function renderExpenseDistribution() {
        const container = document.getElementById('expenseDistributionContainer');
        const transactions = getFilteredTransactions().filter(t => t.type === 'expense');

        if (transactions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-chart-pie"></i>
                    <p>No expense distribution available yet.</p>
                </div>
            `;
            return;
        }

        const categories = {};
        let total = 0;
        transactions.forEach(t => {
            const cat = t.category || 'Other';
            categories[cat] = (categories[cat] || 0) + t.amount;
            total += t.amount;
        });

        // Get top 5 categories
        const sorted = Object.entries(categories).sort((a, b) => b[1] - a[1]).slice(0, 6);
        const colors = ['#2F6B46', '#4A8A5E', '#9AAF8A', '#B78A3C', '#B94A48', '#6F766F'];

        let html = '';
        sorted.forEach(([category, amount], index) => {
            const percent = (amount / total * 100);
            html += `
                <div class="expense-item">
                    <span class="expense-label">${category}</span>
                    <div class="expense-bar">
                        <div class="bar-fill" style="width: ${Math.min(percent, 100)}%; background: ${colors[index % colors.length]};"></div>
                    </div>
                    <span class="expense-amount">${amount.toLocaleString()} ETB</span>
                    <span class="expense-percent">${percent.toFixed(0)}%</span>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    function renderIncomeExpenseAnalysis() {
        const container = document.getElementById('incomeExpenseContainer');
        const transactions = getFilteredTransactions();

        let totalIncome = 0;
        let totalExpenses = 0;
        transactions.forEach(t => {
            if (t.type === 'income') totalIncome += t.amount;
            else if (t.type === 'expense') totalExpenses += t.amount;
        });

        const maxValue = Math.max(totalIncome, totalExpenses, 1);

        container.innerHTML = `
            <div class="income-expense-visual">
                <div class="ie-item">
                    <span class="ie-label">Income</span>
                    <div class="ie-bar">
                        <div class="ie-fill income-fill" style="width: ${(totalIncome / maxValue) * 100}%;"></div>
                    </div>
                    <span class="ie-value">${totalIncome.toLocaleString()} ETB</span>
                </div>
                <div class="ie-item">
                    <span class="ie-label">Expenses</span>
                    <div class="ie-bar">
                        <div class="ie-fill expense-fill" style="width: ${(totalExpenses / maxValue) * 100}%;"></div>
                    </div>
                    <span class="ie-value">${totalExpenses.toLocaleString()} ETB</span>
                </div>
                <div style="margin-top:0.5rem; padding:0.5rem; background:#F6F4EE; border-radius:8px; text-align:center;">
                    <strong>Net Result:</strong> 
                    <span style="color:${totalIncome >= totalExpenses ? '#2F6B46' : '#B94A48'}; font-weight:600;">
                        ${(totalIncome - totalExpenses).toLocaleString()} ETB
                        ${totalIncome >= totalExpenses ? ' ✅ Profit' : ' ⚠️ Loss'}
                    </span>
                </div>
            </div>
        `;
    }

    function renderCropPerformance() {
        const container = document.getElementById('cropPerformanceContainer');
        const transactions = getFilteredTransactions().filter(t => t.crop);

        if (transactions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-seedling"></i>
                    <p>Link transactions to your crops to view crop-specific financial performance.</p>
                    <button class="btn-primary btn-sm" onclick="window.location.href='my-crops.html'">
                        <i class="fas fa-arrow-right"></i> Go to My Crops
                    </button>
                </div>
            `;
            return;
        }

        const cropData = {};
        transactions.forEach(t => {
            if (!cropData[t.crop]) cropData[t.crop] = { income: 0, expense: 0 };
            if (t.type === 'income') cropData[t.crop].income += t.amount;
            else if (t.type === 'expense') cropData[t.crop].expense += t.amount;
        });

        let html = `
            <table class="crop-table">
                <thead>
                    <tr>
                        <th>Crop</th>
                        <th>Income (ETB)</th>
                        <th>Expenses (ETB)</th>
                        <th>Net (ETB)</th>
                    </tr>
                </thead>
                <tbody>
        `;

        Object.entries(cropData).forEach(([crop, data]) => {
            const net = data.income - data.expense;
            html += `
                <tr>
                    <td class="crop-name">${crop}</td>
                    <td class="positive">${data.income.toLocaleString()}</td>
                    <td class="negative">${data.expense.toLocaleString()}</td>
                    <td class="${net >= 0 ? 'positive' : 'negative'}">${net.toLocaleString()}</td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
            <div style="margin-top:0.5rem; font-size:0.75rem; color:#6F766F;">
                Based on transactions linked to crops.
            </div>
        `;

        container.innerHTML = html;
    }

    function renderBudget() {
        const container = document.getElementById('budgetContainer');
        const budgets = state.budgets;

        if (budgets.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-wallet"></i>
                    <p>Create a budget to track your farm spending.</p>
                    <button class="btn-primary btn-sm" onclick="openBudgetModal()">
                        <i class="fas fa-plus"></i> Create Budget
                    </button>
                </div>
            `;
            return;
        }

        let html = '';
        budgets.forEach(budget => {
            // Calculate spending within budget period
            const spending = state.transactions
                .filter(t => t.type === 'expense' && t.date >= budget.startDate && t.date <= budget.endDate)
                .reduce((sum, t) => sum + t.amount, 0);
            
            const remaining = budget.amount - spending;
            const progress = budget.amount > 0 ? (spending / budget.amount * 100) : 0;
            const isOver = remaining < 0;

            html += `
                <div class="budget-item">
                    <div class="budget-info">
                        <div class="budget-name">${budget.name}</div>
                        <div class="budget-period">${new Date(budget.startDate).toLocaleDateString()} - ${new Date(budget.endDate).toLocaleDateString()}</div>
                    </div>
                    <div class="budget-progress">
                        <div class="progress-bar">
                            <div class="progress-fill ${isOver ? 'over' : 'under'}" style="width: ${Math.min(progress, 100)}%;"></div>
                        </div>
                    </div>
                    <div class="budget-amounts">
                        <div class="budget-spent">${spending.toLocaleString()} ETB</div>
                        <div class="budget-total">of ${budget.amount.toLocaleString()} ETB</div>
                        ${isOver ? `<div style="color:#B94A48; font-size:0.75rem;">⚠️ Over by ${Math.abs(remaining).toLocaleString()}</div>` : 
                                   `<div style="color:#2F6B46; font-size:0.75rem;">${remaining.toLocaleString()} left</div>`}
                    </div>
                    <div style="display:flex; gap:0.3rem;">
                        <button class="btn-secondary btn-sm" onclick="openBudgetModal('${budget.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-danger" style="font-size:0.7rem; padding:0.2rem 0.6rem; border-radius:4px; color:#B94A48;" onclick="deleteBudget('${budget.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    function renderTransactions() {
        const container = document.getElementById('transactionContainer');
        let transactions = getFilteredTransactions();
        
        // Search filter
        const search = document.getElementById('transactionSearch')?.value.toLowerCase() || '';
        if (search) {
            transactions = transactions.filter(t => 
                t.description?.toLowerCase().includes(search) ||
                t.category?.toLowerCase().includes(search) ||
                t.crop?.toLowerCase().includes(search) ||
                t.notes?.toLowerCase().includes(search)
            );
        }

        // Type filter
        const typeFilter = document.getElementById('transactionTypeFilter')?.value || 'all';
        if (typeFilter !== 'all') {
            transactions = transactions.filter(t => t.type === typeFilter);
        }

        // Sort by date descending
        transactions.sort((a, b) => new Date(b.date) - new Date(a.date));

        if (transactions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-list-ul"></i>
                    <p>No transactions found.</p>
                    <button class="btn-primary btn-sm" onclick="openTransactionModal('income')">
                        <i class="fas fa-plus"></i> Add First Transaction
                    </button>
                </div>
            `;
            return;
        }

        let html = `
            <table class="transaction-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Crop</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        `;

        transactions.slice(0, 20).forEach(t => {
            const isIncome = t.type === 'income';
            const isExpense = t.type === 'expense';
            
            html += `
                <tr>
                    <td>${new Date(t.date).toLocaleDateString()}</td>
                    <td>
                        <span class="type-badge ${t.type}">
                            ${isIncome ? '💰' : isExpense ? '💸' : '🔄'} ${t.type.charAt(0).toUpperCase() + t.type.slice(1)}
                        </span>
                    </td>
                    <td>${t.category || '—'}</td>
                    <td>${t.description || '—'}</td>
                    <td>${t.crop || '—'}</td>
                    <td class="${isIncome ? 'positive' : isExpense ? 'negative' : ''}">
                        ${isIncome ? '+' : isExpense ? '-' : ''}${t.amount.toLocaleString()}
                    </td>
                    <td>${t.payment || '—'}</td>
                    <td>
                        <div class="action-btns">
                            <button class="edit-btn" onclick="editTransaction('${t.id}')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="delete-btn" onclick="deleteTransaction('${t.id}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
            ${transactions.length > 20 ? `<div style="margin-top:0.5rem; font-size:0.85rem; color:#6F766F;">Showing 20 of ${transactions.length} transactions</div>` : ''}
        `;

        container.innerHTML = html;
    }

    function renderConnectedRecords() {
        const crops = getCrops();
        const records = getFarmRecords();
        const tasks = getTasks();
        const daily = getDailyRecords();

        document.getElementById('connectedCrops').textContent = crops.length;
        document.getElementById('connectedRecords').textContent = records.length;
        document.getElementById('connectedTasks').textContent = tasks.length;
        document.getElementById('connectedMarket').textContent = daily.length;
    }

    // ============================================================
    // EXPORT
    // ============================================================

    window.exportTransactions = function() {
        const transactions = getFilteredTransactions();
        
        if (transactions.length === 0) {
            showToast('No transactions to export.', 'warning');
            return;
        }

        let csv = 'Date,Type,Category,Description,Crop,Amount,Payment,Notes\n';
        transactions.forEach(t => {
            csv += `${t.date},${t.type},${t.category || ''},${t.description || ''},${t.crop || ''},${t.amount},${t.payment || ''},${t.notes || ''}\n`;
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `agrinova_transactions_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
        showToast('Transactions exported successfully!', 'success');
    };

    // ============================================================
    // MODAL HELPERS
    // ============================================================

    window.openModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    };

    window.closeModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    };

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
                document.body.style.overflow = 'auto';
            }
        });
    });

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast show ${type || ''}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    window.showToast = showToast;

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim().toLowerCase();
                    if (query) {
                        const transactions = getFilteredTransactions();
                        const results = transactions.filter(t => 
                            t.description?.toLowerCase().includes(query) ||
                            t.category?.toLowerCase().includes(query) ||
                            t.crop?.toLowerCase().includes(query)
                        );
                        if (results.length > 0) {
                            showToast(`Found ${results.length} transaction${results.length > 1 ? 's' : ''} matching "${query}"`, 'success');
                        } else {
                            showToast(`No transactions found matching "${query}"`, 'warning');
                        }
                    }
                }
            });
        }
    }

    // ============================================================
    // EXPOSE FUNCTIONS
    // ============================================================

    window.openTransactionModal = openTransactionModal;
    window.editTransaction = editTransaction;
    window.deleteTransaction = deleteTransaction;
    window.openTransferModal = openTransferModal;
    window.openGoalModal = openGoalModal;
    window.deleteGoal = deleteGoal;
    window.addGoalProgress = addGoalProgress;
    window.openBudgetModal = openBudgetModal;
    window.deleteBudget = deleteBudget;
    window.updateFinance = updateFinance;
    window.setTimelinePeriod = setTimelinePeriod;
    window.exportTransactions = exportTransactions;
    window.closeModal = closeModal;
    window.showToast = showToast;

    // ============================================================
    // INIT
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();