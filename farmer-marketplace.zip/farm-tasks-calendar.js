(function() {
    "use strict";

    // ============================================================
    // CROP GROWTH DATA (For AI Recommendations)
    // ============================================================
    
    const CROP_GROWTH_DATA = {
        'maize': { totalDays: 120, stages: [
            { name: 'Germination', startDay: 0, endDay: 7 },
            { name: 'Seedling', startDay: 8, endDay: 21 },
            { name: 'Vegetative', startDay: 22, endDay: 50 },
            { name: 'Flowering', startDay: 51, endDay: 70 },
            { name: 'Grain Fill', startDay: 71, endDay: 100 },
            { name: 'Maturity', startDay: 101, endDay: 120 }
        ]},
        'teff': { totalDays: 80, stages: [
            { name: 'Germination', startDay: 0, endDay: 6 },
            { name: 'Seedling', startDay: 7, endDay: 25 },
            { name: 'Tillering', startDay: 26, endDay: 45 },
            { name: 'Stem Elongation', startDay: 46, endDay: 60 },
            { name: 'Heading/Flowering', startDay: 61, endDay: 70 },
            { name: 'Grain Fill/Maturity', startDay: 71, endDay: 80 }
        ]},
        'wheat': { totalDays: 120, stages: [
            { name: 'Germination', startDay: 0, endDay: 5 },
            { name: 'Seedling', startDay: 6, endDay: 20 },
            { name: 'Tillering', startDay: 21, endDay: 45 },
            { name: 'Stem Elongation', startDay: 46, endDay: 65 },
            { name: 'Heading/Flowering', startDay: 66, endDay: 80 },
            { name: 'Grain Fill', startDay: 81, endDay: 100 },
            { name: 'Maturity', startDay: 101, endDay: 120 }
        ]},
        'potato': { totalDays: 110, stages: [
            { name: 'Germination/Emergence', startDay: 0, endDay: 20 },
            { name: 'Vegetative Growth', startDay: 21, endDay: 45 },
            { name: 'Tuber Initiation', startDay: 46, endDay: 60 },
            { name: 'Tuber Bulking', startDay: 61, endDay: 90 },
            { name: 'Maturation/Skin Set', startDay: 91, endDay: 110 }
        ]},
        'coffee': { totalDays: 240, stages: [
            { name: 'Flowering', startDay: 0, endDay: 14 },
            { name: 'Pinhead Stage', startDay: 15, endDay: 45 },
            { name: 'Fast Growth', startDay: 46, endDay: 105 },
            { name: 'Slow Growth', startDay: 106, endDay: 165 },
            { name: 'Maturation', startDay: 166, endDay: 225 },
            { name: 'Harvest', startDay: 226, endDay: 240 }
        ]}
    };

    // ============================================================
    // DATA HELPERS
    // ============================================================

    function getFarmer() {
        let raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getCrops() {
        let raw = localStorage.getItem('agrinova_crops_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getFarmData() {
        let raw = localStorage.getItem('agrinova_farm_data');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    function getTasks() {
        let raw = localStorage.getItem('agrinova_tasks_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveTasks(tasks) {
        localStorage.setItem('agrinova_tasks_data', JSON.stringify(tasks));
    }

    function getDailyRecords() {
        let raw = localStorage.getItem('agrinova_daily_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getLandSections() {
        const farmData = getFarmData();
        return farmData.landSections || [];
    }

    // ============================================================
    // STATE
    // ============================================================

    let state = {
        currentView: 'month',
        currentDate: new Date(),
        selectedDate: new Date(),
        tasks: [],
        filterStatus: 'all',
        filterCategory: 'all',
        filterPriority: 'all'
    };

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova Farm Tasks & Calendar Initializing...');
        
        state.tasks = getTasks();
        updateDate();
        updateGreeting();
        updateProfile();
        setupProfileImage();
        setupDropdown();
        setupSearch();
        fetchWeather();
        populateCropDropdown();
        populateAreaDropdown();
        populateFilterCategories();
        
        renderCalendar();
        renderTodayTasks();
        renderUpcomingTasks();
        updateStats();
        generateAIRecommendations();
        generateMonthlyPlanning();
        updateNotificationBadge();
        
        // Setup recurrence toggle
        document.getElementById('taskRecurrence').addEventListener('change', function() {
            document.getElementById('customRecurrenceGroup').style.display = 
                this.value === 'custom' ? 'block' : 'none';
        });

        // Setup task form
        document.getElementById('taskForm').addEventListener('submit', saveTask);

        console.log('AgriNova Farm Tasks & Calendar Ready.');
    }

    // ============================================================
    // DATE & GREETING
    // ============================================================

    function updateDate() {
        const now = new Date();
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        
        document.getElementById('dateDay').textContent = days[now.getDay()];
        document.getElementById('dateFull').textContent = `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    }

    function updateGreeting() {
        const farmer = getFarmer();
        const h1 = document.getElementById('greetingText');
        const hour = new Date().getHours();
        let greet = 'Good Morning';
        if (hour >= 12 && hour < 17) greet = 'Good Afternoon';
        else if (hour >= 17) greet = 'Good Evening';

        const name = farmer?.name || farmer?.firstName || 'Farmer';
        h1.textContent = `${greet}, ${name}`;
        document.getElementById('navName').textContent = name;
    }

    // ============================================================
    // PROFILE
    // ============================================================

    function updateProfile() {
        const farmer = getFarmer();
        if (!farmer) return;

        const name = farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('pdName').textContent = name;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || '—';
        
        const city = farmer.city || '—';
        const region = farmer.region || '—';
        document.getElementById('pdLocation').textContent = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdFarmland').textContent = farmer.hectares ? `${farmer.hectares} ha` : '—';
    }

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }
        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim().toLowerCase();
                    if (query) {
                        const tasks = getTasks();
                        const results = tasks.filter(t => 
                            t.title.toLowerCase().includes(query) ||
                            t.category.toLowerCase().includes(query) ||
                            (t.crop && t.crop.toLowerCase().includes(query)) ||
                            (t.notes && t.notes.toLowerCase().includes(query))
                        );
                        if (results.length > 0) {
                            showToast(`Found ${results.length} task${results.length > 1 ? 's' : ''} matching "${query}"`);
                        } else {
                            showToast(`No tasks found matching "${query}"`);
                        }
                    }
                }
            });
        }
    }

    // ============================================================
    // DROPDOWNS
    // ============================================================

    function populateCropDropdown() {
        const crops = getCrops();
        const select = document.getElementById('taskCrop');
        select.innerHTML = '<option value="">None</option>';
        crops.forEach(crop => {
            select.innerHTML += `<option value="${crop.name}">${crop.name}</option>`;
        });
        if (crops.length === 0) {
            select.innerHTML += '<option value="" disabled>No crops added yet</option>';
        }
    }

    function populateAreaDropdown() {
        const sections = getLandSections();
        const select = document.getElementById('taskArea');
        select.innerHTML = '<option value="">None</option>';
        sections.forEach(section => {
            select.innerHTML += `<option value="${section.name}">${section.name}</option>`;
        });
        if (sections.length === 0) {
            select.innerHTML += '<option value="" disabled>No areas added yet</option>';
        }
    }

    function populateFilterCategories() {
        const select = document.getElementById('filterCategory');
        const categories = [
            'Crop Management', 'Irrigation', 'Fertilizer', 'Pest Management',
            'Weed Management', 'Equipment', 'Harvest', 'Inspection',
            'Land Preparation', 'Planting', 'Pruning', 'Soil Management',
            'Irrigation Maintenance', 'Storage', 'Market Preparation',
            'Farm Administration', 'Other'
        ];
        categories.forEach(cat => {
            select.innerHTML += `<option value="${cat}">${cat}</option>`;
        });
    }

    // ============================================================
    // CALENDAR
    // ============================================================

    function renderCalendar() {
        const container = document.getElementById('calendarContainer');
        const year = state.currentDate.getFullYear();
        const month = state.currentDate.getMonth();
        const today = new Date();

        document.getElementById('calendarMonthYear').textContent = 
            `${['January','February','March','April','May','June','July','August','September','October','November','December'][month]} ${year}`;

        if (state.currentView === 'month') {
            renderMonthView(container, year, month, today);
        } else if (state.currentView === 'week') {
            renderWeekView(container, year, month, today);
        } else {
            renderAgendaView(container);
        }
    }

    function renderMonthView(container, year, month, today) {
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const daysInPrevMonth = new Date(year, month, 0).getDate();

        const tasks = getTasks();
        const todayStr = today.toDateString();

        let html = '<div class="calendar-grid">';
        
        // Day headers
        ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].forEach(day => {
            html += `<div class="day-header">${day}</div>`;
        });

        // Previous month days
        for (let i = firstDay - 1; i >= 0; i--) {
            const day = daysInPrevMonth - i;
            html += `<div class="day-cell"><span class="day-number other-month">${day}</span></div>`;
        }

        // Current month days
        for (let day = 1; day <= daysInMonth; day++) {
            const dateObj = new Date(year, month, day);
            const dateStr = dateObj.toDateString();
            const isToday = dateStr === todayStr;
            const dayTasks = tasks.filter(t => {
                const taskDate = new Date(t.dueDate);
                return taskDate.toDateString() === dateStr && t.status !== 'completed';
            });

            let taskDots = '';
            if (dayTasks.length > 0) {
                const displayTasks = dayTasks.slice(0, 3);
                displayTasks.forEach(t => {
                    const priority = t.priority || 'low';
                    taskDots += `<span class="task-dot ${priority}"></span>`;
                });
                if (dayTasks.length > 3) {
                    taskDots += `<span class="more-indicator">+${dayTasks.length - 3}</span>`;
                }
            }

            html += `
                <div class="day-cell" onclick="selectDay('${dateObj.toISOString()}')">
                    <span class="day-number ${isToday ? 'today' : ''}">${day}</span>
                    <div class="task-dots">${taskDots}</div>
                </div>
            `;
        }

        // Next month days
        const totalCells = firstDay + daysInMonth;
        const remainingCells = (7 - totalCells % 7) % 7;
        for (let day = 1; day <= remainingCells; day++) {
            html += `<div class="day-cell"><span class="day-number other-month">${day}</span></div>`;
        }

        html += '</div>';
        container.innerHTML = html;
    }

    function renderWeekView(container, year, month, today) {
        const startOfWeek = new Date(year, month, 1);
        const dayOfWeek = startOfWeek.getDay();
        startOfWeek.setDate(startOfWeek.getDate() - dayOfWeek);

        const tasks = getTasks();
        const todayStr = today.toDateString();

        let html = '<div class="week-grid">';
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        for (let i = 0; i < 7; i++) {
            const dateObj = new Date(startOfWeek);
            dateObj.setDate(startOfWeek.getDate() + i);
            const dateStr = dateObj.toDateString();
            const isToday = dateStr === todayStr;
            const dayTasks = tasks.filter(t => {
                const taskDate = new Date(t.dueDate);
                return taskDate.toDateString() === dateStr && t.status !== 'completed';
            });

            html += `
                <div class="week-day">
                    <div class="week-date ${isToday ? 'today' : ''}">${days[i]} ${dateObj.getDate()}</div>
            `;

            dayTasks.slice(0, 4).forEach(t => {
                const priority = t.priority || 'low';
                html += `
                    <div class="week-task ${priority}" onclick="showTaskDetail('${t.id}')">
                        ${t.title}
                    </div>
                `;
            });

            if (dayTasks.length > 4) {
                html += `<div style="font-size:0.65rem; color:#6F786F; margin-top:0.2rem;">+${dayTasks.length - 4} more</div>`;
            }

            html += '</div>';
        }

        html += '</div>';
        container.innerHTML = html;
    }

    function renderAgendaView(container) {
        const tasks = getTasks();
        const sorted = [...tasks].sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
        const today = new Date().toDateString();

        if (sorted.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-calendar-alt"></i>
                    <p>No tasks scheduled yet.</p>
                </div>
            `;
            return;
        }

        let html = '';
        let currentDate = '';

        sorted.forEach(task => {
            const taskDate = new Date(task.dueDate);
            const dateStr = taskDate.toDateString();
            const displayDate = dateStr === today ? 'Today' : 
                taskDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

            if (dateStr !== currentDate) {
                currentDate = dateStr;
                html += `
                    <div class="agenda-item">
                        <div class="agenda-date">${displayDate}</div>
                `;
            }

            const isCompleted = task.status === 'completed';
            html += `
                <div class="agenda-task" onclick="showTaskDetail('${task.id}')">
                    <div class="task-check ${isCompleted ? 'completed' : ''}" onclick="event.stopPropagation(); toggleTask('${task.id}')">
                        ${isCompleted ? '<i class="fas fa-check" style="font-size:0.6rem;"></i>' : ''}
                    </div>
                    <div class="task-title ${isCompleted ? 'completed' : ''}">${task.title}</div>
                    <div class="task-meta">${task.category}</div>
                </div>
            `;

            // Close agenda item after last task of that date
            const nextTask = sorted[sorted.indexOf(task) + 1];
            if (!nextTask || new Date(nextTask.dueDate).toDateString() !== dateStr) {
                html += '</div>';
            }
        });

        container.innerHTML = html;
    }

    // ============================================================
    // CALENDAR NAVIGATION
    // ============================================================

    window.changeMonth = function(delta) {
        state.currentDate.setMonth(state.currentDate.getMonth() + delta);
        renderCalendar();
    };

    window.goToToday = function() {
        state.currentDate = new Date();
        renderCalendar();
    };

    window.setView = function(view) {
        state.currentView = view;
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === view);
        });
        renderCalendar();
    };

    window.selectDay = function(dateStr) {
        const date = new Date(dateStr);
        state.selectedDate = date;
        // Could show tasks for that day
        showToast(`Selected: ${date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}`);
    };

    // ============================================================
    // TODAY'S TASKS
    // ============================================================

    function renderTodayTasks() {
        const container = document.getElementById('todayTasksContainer');
        const tasks = getTasks();
        const today = new Date().toDateString();
        const todayTasks = tasks.filter(t => {
            const taskDate = new Date(t.dueDate);
            return taskDate.toDateString() === today;
        });

        if (todayTasks.length === 0) {
            container.innerHTML = `
                <div class="empty-state" style="padding:1rem;">
                    <p>No tasks scheduled for today.</p>
                    <button class="btn-primary btn-sm" onclick="openTaskModal()" style="margin-top:0.5rem;">
                        <i class="fas fa-plus"></i> Add Task
                    </button>
                </div>
            `;
            return;
        }

        let html = '';
        todayTasks.forEach(task => {
            const isCompleted = task.status === 'completed';
            const priority = task.priority || 'low';
            html += `
                <div class="today-task-item" onclick="showTaskDetail('${task.id}')">
                    <div class="task-check ${isCompleted ? 'completed' : ''}" onclick="event.stopPropagation(); toggleTask('${task.id}')">
                        ${isCompleted ? '<i class="fas fa-check" style="font-size:0.6rem;"></i>' : ''}
                    </div>
                    <div class="task-info">
                        <div class="task-name ${isCompleted ? 'completed' : ''}">${task.title}</div>
                        <div class="task-sub">${task.category} ${task.crop ? `· ${task.crop}` : ''}</div>
                    </div>
                    <div class="task-priority ${priority}"></div>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    // ============================================================
    // UPCOMING TASKS
    // ============================================================

    function renderUpcomingTasks() {
        const container = document.getElementById('upcomingTasksContainer');
        let tasks = getTasks();

        // Apply filters
        if (state.filterStatus !== 'all') {
            if (state.filterStatus === 'pending') {
                tasks = tasks.filter(t => t.status !== 'completed');
            } else if (state.filterStatus === 'completed') {
                tasks = tasks.filter(t => t.status === 'completed');
            } else if (state.filterStatus === 'overdue') {
                const today = new Date();
                tasks = tasks.filter(t => {
                    const dueDate = new Date(t.dueDate);
                    return dueDate < today && t.status !== 'completed';
                });
            }
        }

        if (state.filterCategory !== 'all') {
            tasks = tasks.filter(t => t.category === state.filterCategory);
        }

        if (state.filterPriority !== 'all') {
            tasks = tasks.filter(t => t.priority === state.filterPriority);
        }

        // Sort by due date
        tasks.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));

        if (tasks.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clipboard-list"></i>
                    <p>No tasks found matching your filters.</p>
                </div>
            `;
            return;
        }

        let html = '';
        tasks.forEach(task => {
            const isCompleted = task.status === 'completed';
            const isOverdue = !isCompleted && new Date(task.dueDate) < new Date();
            const priority = task.priority || 'low';
            const statusClass = isCompleted ? 'completed' : isOverdue ? 'overdue' : 'pending';

            html += `
                <div class="task-list-item" onclick="showTaskDetail('${task.id}')">
                    <div class="task-check ${isCompleted ? 'completed' : ''}" onclick="event.stopPropagation(); toggleTask('${task.id}')">
                        ${isCompleted ? '<i class="fas fa-check" style="font-size:0.6rem;"></i>' : ''}
                    </div>
                    <div class="task-info">
                        <div class="task-name ${isCompleted ? 'completed' : ''}">${task.title}</div>
                        <div class="task-sub">
                            ${task.category} ${task.crop ? `· ${task.crop}` : ''}
                            · Due: ${new Date(task.dueDate).toLocaleDateString()}
                        </div>
                    </div>
                    <div class="task-priority ${priority}"></div>
                    <span class="task-status ${statusClass}">${isCompleted ? 'Completed' : isOverdue ? 'Overdue' : 'Pending'}</span>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    // ============================================================
    // STATS
    // ============================================================

    function updateStats() {
        const tasks = getTasks();
        const today = new Date().toDateString();

        let todayCount = 0;
        let upcomingCount = 0;
        let overdueCount = 0;
        let completedCount = 0;

        tasks.forEach(task => {
            const taskDate = new Date(task.dueDate);
            const isCompleted = task.status === 'completed';

            if (isCompleted) {
                completedCount++;
            } else if (taskDate.toDateString() === today) {
                todayCount++;
            } else if (taskDate < new Date()) {
                overdueCount++;
            } else {
                upcomingCount++;
            }
        });

        document.getElementById('statToday').textContent = todayCount;
        document.getElementById('statUpcoming').textContent = upcomingCount;
        document.getElementById('statOverdue').textContent = overdueCount;
        document.getElementById('statCompleted').textContent = completedCount;
    }

    // ============================================================
    // TASK CRUD
    // ============================================================

    window.openTaskModal = function(taskId) {
        const form = document.getElementById('taskForm');
        form.reset();
        document.getElementById('editTaskId').value = '';
        document.getElementById('taskModalTitle').textContent = 'Create New Task';
        document.getElementById('customRecurrenceGroup').style.display = 'none';

        // Set default date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('taskDueDate').value = today;

        populateCropDropdown();
        populateAreaDropdown();

        if (taskId) {
            const tasks = getTasks();
            const task = tasks.find(t => t.id === taskId);
            if (task) {
                document.getElementById('editTaskId').value = taskId;
                document.getElementById('taskModalTitle').textContent = 'Edit Task';
                document.getElementById('taskTitle').value = task.title || '';
                document.getElementById('taskCategory').value = task.category || '';
                document.getElementById('taskPriority').value = task.priority || 'medium';
                document.getElementById('taskCrop').value = task.crop || '';
                document.getElementById('taskArea').value = task.area || '';
                document.getElementById('taskDueDate').value = task.dueDate || today;
                document.getElementById('taskDueTime').value = task.dueTime || '';
                document.getElementById('taskNotes').value = task.notes || '';
                document.getElementById('taskRecurrence').value = task.recurrence || 'none';
                document.getElementById('taskReminder').value = task.reminder || 'none';
                if (task.recurrence === 'custom') {
                    document.getElementById('customRecurrenceGroup').style.display = 'block';
                    document.getElementById('customRecurrenceInterval').value = task.recurrenceInterval || 1;
                    document.getElementById('customRecurrenceUnit').value = task.recurrenceUnit || 'days';
                }
            }
        }

        openModal('taskModal');
    };

    function saveTask(event) {
        event.preventDefault();

        const editId = document.getElementById('editTaskId').value;
        const title = document.getElementById('taskTitle').value.trim();
        const category = document.getElementById('taskCategory').value;
        const priority = document.getElementById('taskPriority').value;
        const crop = document.getElementById('taskCrop').value;
        const area = document.getElementById('taskArea').value;
        const dueDate = document.getElementById('taskDueDate').value;
        const dueTime = document.getElementById('taskDueTime').value;
        const notes = document.getElementById('taskNotes').value.trim();
        const recurrence = document.getElementById('taskRecurrence').value;
        const reminder = document.getElementById('taskReminder').value;
        const recurrenceInterval = document.getElementById('customRecurrenceInterval')?.value || 1;
        const recurrenceUnit = document.getElementById('customRecurrenceUnit')?.value || 'days';

        if (!title || !dueDate) {
            showToast('Please fill in all required fields.', 'error');
            return;
        }

        const tasks = getTasks();

        if (editId) {
            // Edit existing
            const index = tasks.findIndex(t => t.id === editId);
            if (index !== -1) {
                tasks[index] = {
                    ...tasks[index],
                    title,
                    category,
                    priority,
                    crop,
                    area,
                    dueDate,
                    dueTime,
                    notes,
                    recurrence,
                    reminder,
                    recurrenceInterval: recurrence === 'custom' ? parseInt(recurrenceInterval) : null,
                    recurrenceUnit: recurrence === 'custom' ? recurrenceUnit : null,
                    updatedAt: new Date().toISOString()
                };
                showToast('Task updated successfully!');
            }
        } else {
            // Create new
            const newTask = {
                id: 'task_' + Date.now(),
                title,
                category,
                priority,
                crop,
                area,
                dueDate,
                dueTime,
                notes,
                recurrence,
                reminder,
                recurrenceInterval: recurrence === 'custom' ? parseInt(recurrenceInterval) : null,
                recurrenceUnit: recurrence === 'custom' ? recurrenceUnit : null,
                status: 'pending',
                source: 'manual',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                completedAt: null
            };
            tasks.push(newTask);
            showToast('Task created successfully!');
        }

        saveTasks(tasks);
        closeModal('taskModal');
        renderCalendar();
        renderTodayTasks();
        renderUpcomingTasks();
        updateStats();
        updateNotificationBadge();
        generateAIRecommendations();
    }

    window.toggleTask = function(taskId) {
        const tasks = getTasks();
        const task = tasks.find(t => t.id === taskId);
        if (!task) return;

        if (task.status === 'completed') {
            task.status = 'pending';
            task.completedAt = null;
            showToast('Task reopened.');
        } else {
            task.status = 'completed';
            task.completedAt = new Date().toISOString();
            showToast('✅ Task completed!');
            
            // Ask if they want to add to Daily Farm
            setTimeout(() => {
                if (confirm('Add details to today\'s Daily Farm record?')) {
                    window.location.href = 'daily-farm.html';
                }
            }, 500);
        }

        task.updatedAt = new Date().toISOString();
        saveTasks(tasks);
        renderCalendar();
        renderTodayTasks();
        renderUpcomingTasks();
        updateStats();
        updateNotificationBadge();
    };

    window.deleteTask = function(taskId) {
        if (!confirm('Are you sure you want to delete this task?')) return;
        
        let tasks = getTasks();
        tasks = tasks.filter(t => t.id !== taskId);
        saveTasks(tasks);
        closeModal('taskDetailModal');
        renderCalendar();
        renderTodayTasks();
        renderUpcomingTasks();
        updateStats();
        updateNotificationBadge();
        showToast('Task deleted.');
    };

    // ============================================================
    // TASK DETAIL
    // ============================================================

    window.showTaskDetail = function(taskId) {
        const tasks = getTasks();
        const task = tasks.find(t => t.id === taskId);
        if (!task) return;

        const isCompleted = task.status === 'completed';
        const isOverdue = !isCompleted && new Date(task.dueDate) < new Date();

        document.getElementById('taskDetailTitle').textContent = task.title;

        const html = `
            <div style="display:grid; gap:0.5rem;">
                <div><strong>Status:</strong> <span class="task-status ${isCompleted ? 'completed' : isOverdue ? 'overdue' : 'pending'}">${isCompleted ? 'Completed' : isOverdue ? 'Overdue' : 'Pending'}</span></div>
                <div><strong>Category:</strong> ${task.category}</div>
                <div><strong>Priority:</strong> <span style="color:${task.priority === 'high' ? '#A76D52' : task.priority === 'medium' ? '#B89152' : '#B7C9B0'};">${task.priority}</span></div>
                <div><strong>Due Date:</strong> ${new Date(task.dueDate).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</div>
                ${task.dueTime ? `<div><strong>Time:</strong> ${task.dueTime}</div>` : ''}
                ${task.crop ? `<div><strong>Crop:</strong> ${task.crop}</div>` : ''}
                ${task.area ? `<div><strong>Farm Area:</strong> ${task.area}</div>` : ''}
                ${task.notes ? `<div><strong>Notes:</strong> ${task.notes}</div>` : ''}
                ${task.recurrence && task.recurrence !== 'none' ? `<div><strong>Repeats:</strong> ${task.recurrence}</div>` : ''}
                ${task.completedAt ? `<div><strong>Completed:</strong> ${new Date(task.completedAt).toLocaleString()}</div>` : ''}
                <div style="font-size:0.75rem; color:#6F786F; margin-top:0.5rem;">Created: ${new Date(task.createdAt).toLocaleString()}</div>
            </div>
            <div style="display:flex; gap:0.8rem; margin-top:1.5rem; flex-wrap:wrap;">
                <button class="btn-primary btn-sm" onclick="closeModal('taskDetailModal'); openTaskModal('${task.id}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn-secondary btn-sm" onclick="closeModal('taskDetailModal'); toggleTask('${task.id}')">
                    <i class="fas ${isCompleted ? 'fa-undo' : 'fa-check'}"></i> ${isCompleted ? 'Reopen' : 'Complete'}
                </button>
                <button class="btn-danger-sm" onclick="deleteTask('${task.id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        `;

        document.getElementById('taskDetailContent').innerHTML = html;
        openModal('taskDetailModal');
    };

    // ============================================================
    // AI RECOMMENDATIONS
    // ============================================================

    function generateAIRecommendations() {
        const container = document.getElementById('weeklyRecommendations');
        const crops = getCrops();
        const tasks = getTasks();
        const dailyRecords = getDailyRecords();

        if (crops.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-robot"></i>
                    <p>More farm information is needed to generate reliable recommendations.</p>
                    <button class="btn-primary btn-sm" onclick="window.location.href='my-crops.html'">
                        <i class="fas fa-seedling"></i> Add Crops
                    </button>
                </div>
            `;
            return;
        }

        let recommendations = [];

        crops.forEach(crop => {
            const cropName = crop.name.toLowerCase().trim();
            const plantingDate = crop.plantingDate;
            const growthData = CROP_GROWTH_DATA[cropName];
            
            if (plantingDate && growthData) {
                const daysSince = getDaysSincePlanting(plantingDate);
                const totalDays = growthData.totalDays;
                const progress = (daysSince / totalDays) * 100;

                // Stage-based recommendations
                const currentStage = getCurrentStageFromData(cropName, daysSince, growthData);
                if (currentStage) {
                    const stageName = currentStage.name;
                    const stageIndex = growthData.stages.indexOf(currentStage);
                    
                    if (stageName.includes('Germination') || stageName.includes('Emergence')) {
                        recommendations.push({
                            title: `Monitor ${crop.name} emergence`,
                            reason: `${crop.name} is in the expected germination/emergence stage based on planting date.`,
                            tags: ['Crop Stage', 'Monitoring'],
                            crop: crop.name,
                            suggestedTiming: 'Now'
                        });
                    } else if (stageName.includes('Vegetative') || stageName.includes('Tillering')) {
                        recommendations.push({
                            title: `Apply fertilizer to ${crop.name}`,
                            reason: `${crop.name} is in the active vegetative growth stage. Fertilizer application is often relevant during this period.`,
                            tags: ['Crop Stage', 'Fertilizer'],
                            crop: crop.name,
                            suggestedTiming: 'This week'
                        });
                        recommendations.push({
                            title: `Weed management for ${crop.name}`,
                            reason: `Active growth stages typically require weed monitoring and management.`,
                            tags: ['Crop Stage', 'Weed Management'],
                            crop: crop.name,
                            suggestedTiming: 'This week'
                        });
                    } else if (stageName.includes('Flowering') || stageName.includes('Heading')) {
                        recommendations.push({
                            title: `Monitor ${crop.name} for pests`,
                            reason: `Flowering stages can be vulnerable to pests. Regular monitoring is recommended.`,
                            tags: ['Crop Stage', 'Pest Management'],
                            crop: crop.name,
                            suggestedTiming: 'Now'
                        });
                    } else if (stageName.includes('Fill') || stageName.includes('Bulking')) {
                        recommendations.push({
                            title: `Ensure adequate water for ${crop.name}`,
                            reason: `Grain/fruit fill stages require consistent moisture for optimal development.`,
                            tags: ['Crop Stage', 'Irrigation'],
                            crop: crop.name,
                            suggestedTiming: 'Ongoing'
                        });
                    } else if (stageName.includes('Maturity') || stageName.includes('Maturation')) {
                        recommendations.push({
                            title: `Prepare for ${crop.name} harvest`,
                            reason: `${crop.name} is approaching maturity based on the planting date. Begin harvest preparation.`,
                            tags: ['Crop Stage', 'Harvest'],
                            crop: crop.name,
                            suggestedTiming: 'Soon'
                        });
                    }
                }

                // Check if nearing harvest
                if (progress > 85 && progress < 100) {
                    recommendations.push({
                        title: `Schedule ${crop.name} harvest`,
                        reason: `${crop.name} is nearing the expected harvest period based on planting date.`,
                        tags: ['Harvest', 'Planning'],
                        crop: crop.name,
                        suggestedTiming: 'Plan now'
                    });
                }
            }
        });

        // Weather-based recommendations (if we have weather data)
        const weatherTemp = document.getElementById('navTemp')?.textContent || '';
        if (weatherTemp && weatherTemp !== '--°C') {
            const temp = parseInt(weatherTemp);
            if (temp > 30) {
                recommendations.push({
                    title: 'Monitor crops for heat stress',
                    reason: 'High temperatures are present. Monitor crops for signs of heat stress.',
                    tags: ['Weather', 'Monitoring'],
                    crop: null,
                    suggestedTiming: 'Now'
                });
            }
        }

        // Check for overdue tasks
        const overdueTasks = tasks.filter(t => t.status !== 'completed' && new Date(t.dueDate) < new Date());
        if (overdueTasks.length > 0) {
            recommendations.push({
                title: `${overdueTasks.length} overdue task${overdueTasks.length > 1 ? 's' : ''} need attention`,
                reason: `You have ${overdueTasks.length} task${overdueTasks.length > 1 ? 's' : ''} that ${overdueTasks.length > 1 ? 'are' : 'is'} past due.`,
                tags: ['Task Management'],
                crop: null,
                suggestedTiming: 'Now'
            });
        }

        // Limit to top 5 recommendations
        recommendations = recommendations.slice(0, 5);

        if (recommendations.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <p>No new recommendations at this time. Your farm looks well-managed!</p>
                </div>
            `;
            return;
        }

        let html = '';
        recommendations.forEach(rec => {
            html += `
                <div class="recommendation-item">
                    <div class="rec-header">
                        <span class="rec-title">${rec.title}</span>
                    </div>
                    <div class="rec-reason">${rec.reason}</div>
                    <div class="rec-tags">
                        ${rec.tags.map(tag => `<span class="rec-tag">${tag}</span>`).join('')}
                        ${rec.suggestedTiming ? `<span class="rec-tag" style="background:#FDF8F0; color:#B89152;">⏰ ${rec.suggestedTiming}</span>` : ''}
                    </div>
                    <div class="rec-actions">
                        <button class="btn-primary btn-sm" onclick="addAIRecommendation('${rec.title}')">
                            <i class="fas fa-plus"></i> Add to Calendar
                        </button>
                        <button class="btn-secondary btn-sm" onclick="dismissRecommendation(this)">
                            Dismiss
                        </button>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    window.addAIRecommendation = function(title) {
        // Pre-fill task form with recommendation
        document.getElementById('taskTitle').value = title;
        document.getElementById('taskCategory').value = 'Crop Management';
        document.getElementById('taskPriority').value = 'medium';
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('taskDueDate').value = today;
        document.getElementById('taskModalTitle').textContent = 'Add Recommended Task';
        document.getElementById('editTaskId').value = '';
        document.getElementById('customRecurrenceGroup').style.display = 'none';
        populateCropDropdown();
        populateAreaDropdown();
        openModal('taskModal');
        showToast('Task pre-filled from recommendation. Adjust as needed.');
    };

    window.dismissRecommendation = function(btn) {
        const item = btn.closest('.recommendation-item');
        item.style.opacity = '0.5';
        item.style.transition = '0.3s';
        setTimeout(() => {
            item.style.display = 'none';
            showToast('Recommendation dismissed.');
        }, 300);
    };

    // ============================================================
    // MONTHLY PLANNING
    // ============================================================

    function generateMonthlyPlanning() {
        const container = document.getElementById('monthlyPlanning');
        const crops = getCrops();

        if (crops.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-calendar-plus"></i>
                    <p>Add crops to receive monthly planning insights.</p>
                    <button class="btn-primary btn-sm" onclick="window.location.href='my-crops.html'">
                        <i class="fas fa-seedling"></i> Add Crops
                    </button>
                </div>
            `;
            return;
        }

        let html = `
            <div style="display:grid; gap:1rem; margin-top:0.5rem;">
                <div style="background:#F8F7F2; border-radius:12px; padding:1rem;">
                    <h4 style="font-family:'Playfair Display',serif; color:#12352A; margin-bottom:0.3rem;">Looking Ahead</h4>
                    <p style="color:#6F786F; font-size:0.9rem;">Potential activities for the coming month based on your crops.</p>
                </div>
        `;

        crops.forEach(crop => {
            const cropName = crop.name;
            const plantingDate = crop.plantingDate;
            const growthData = CROP_GROWTH_DATA[cropName.toLowerCase().trim()];
            
            if (plantingDate && growthData) {
                const daysSince = getDaysSincePlanting(plantingDate);
                const totalDays = growthData.totalDays;
                const progress = (daysSince / totalDays) * 100;

                if (progress < 30) {
                    html += `
                        <div style="background:#fff; border:1px solid #E1E7DF; border-radius:12px; padding:0.8rem 1rem;">
                            <div style="font-weight:600;">${cropName}</div>
                            <div style="font-size:0.85rem; color:#6F786F;">🌱 Early growth stage · Monitor emergence and seedling development</div>
                            <div style="margin-top:0.3rem;">
                                <button class="btn-secondary btn-sm" onclick="addMonthlyTask('Monitor ${cropName} emergence')">
                                    <i class="fas fa-plus"></i> Plan Task
                                </button>
                            </div>
                        </div>
                    `;
                } else if (progress >= 30 && progress < 60) {
                    html += `
                        <div style="background:#fff; border:1px solid #E1E7DF; border-radius:12px; padding:0.8rem 1rem;">
                            <div style="font-weight:600;">${cropName}</div>
                            <div style="font-size:0.85rem; color:#6F786F;">🌿 Active growth · Consider fertilization and weed management</div>
                            <div style="margin-top:0.3rem;">
                                <button class="btn-secondary btn-sm" onclick="addMonthlyTask('Apply fertilizer to ${cropName}')">
                                    <i class="fas fa-plus"></i> Plan Task
                                </button>
                            </div>
                        </div>
                    `;
                } else if (progress >= 60 && progress < 85) {
                    html += `
                        <div style="background:#fff; border:1px solid #E1E7DF; border-radius:12px; padding:0.8rem 1rem;">
                            <div style="font-weight:600;">${cropName}</div>
                            <div style="font-size:0.85rem; color:#6F786F;">🌾 Reproductive stage · Monitor for pests and ensure water availability</div>
                            <div style="margin-top:0.3rem;">
                                <button class="btn-secondary btn-sm" onclick="addMonthlyTask('Monitor ${cropName} for pests')">
                                    <i class="fas fa-plus"></i> Plan Task
                                </button>
                            </div>
                        </div>
                    `;
                } else if (progress >= 85) {
                    html += `
                        <div style="background:#fff; border:1px solid #E1E7DF; border-radius:12px; padding:0.8rem 1rem;">
                            <div style="font-weight:600;">${cropName}</div>
                            <div style="font-size:0.85rem; color:#6F786F;">🌾 Nearing harvest · Plan harvesting activities</div>
                            <div style="margin-top:0.3rem;">
                                <button class="btn-secondary btn-sm" onclick="addMonthlyTask('Plan ${cropName} harvest')">
                                    <i class="fas fa-plus"></i> Plan Task
                                </button>
                            </div>
                        </div>
                    `;
                }
            }
        });

        html += '</div>';
        container.innerHTML = html;
    }

    window.addMonthlyTask = function(title) {
        document.getElementById('taskTitle').value = title;
        document.getElementById('taskCategory').value = 'Crop Management';
        document.getElementById('taskPriority').value = 'medium';
        const today = new Date();
        const nextWeek = new Date(today);
        nextWeek.setDate(today.getDate() + 7);
        document.getElementById('taskDueDate').value = nextWeek.toISOString().split('T')[0];
        document.getElementById('taskModalTitle').textContent = 'Plan Monthly Task';
        document.getElementById('editTaskId').value = '';
        document.getElementById('customRecurrenceGroup').style.display = 'none';
        populateCropDropdown();
        populateAreaDropdown();
        openModal('taskModal');
        showToast('Task pre-filled from monthly planning.');
    };

    // ============================================================
    // FILTERS
    // ============================================================

    window.applyFilters = function() {
        state.filterStatus = document.getElementById('filterStatus').value;
        state.filterCategory = document.getElementById('filterCategory').value;
        state.filterPriority = document.getElementById('filterPriority').value;
        renderUpcomingTasks();
    };

    // ============================================================
    // NOTIFICATIONS
    // ============================================================

    function updateNotificationBadge() {
        const tasks = getTasks();
        const today = new Date().toDateString();
        const todayTasks = tasks.filter(t => {
            const taskDate = new Date(t.dueDate);
            return taskDate.toDateString() === today && t.status !== 'completed';
        });

        const overdueTasks = tasks.filter(t => {
            const taskDate = new Date(t.dueDate);
            return taskDate < new Date() && t.status !== 'completed';
        });

        const count = todayTasks.length + overdueTasks.length;
        const badge = document.getElementById('notifBadge');
        
        if (count > 0) {
            badge.textContent = count;
            badge.classList.add('show');
            
            // Show browser notification if permission granted
            if (Notification.permission === 'granted') {
                new Notification('AgriNova Tasks', {
                    body: `You have ${count} task${count > 1 ? 's' : ''} needing attention.`,
                    icon: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Crect fill="%2312352A" width="100" height="100"/%3E%3Ctext x="50" y="65" font-size="50" text-anchor="middle" fill="%23A8C686"%3E🌱%3C/text%3E%3C/svg%3E'
                });
            }
        } else {
            badge.classList.remove('show');
        }
    }

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }

    // ============================================================
    // WEATHER
    // ============================================================

    async function fetchWeather() {
        try {
            const farmer = getFarmer();
            const city = farmer?.city || 'Addis Ababa';
            
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        await getWeatherData(latitude, longitude);
                    },
                    async () => {
                        await getWeatherByCity(city);
                    }
                );
            } else {
                await getWeatherByCity(city);
            }
        } catch (e) {
            console.warn('Weather error:', e);
            document.getElementById('navTemp').textContent = '--°C';
        }
    }

    async function getWeatherData(lat, lon) {
        try {
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`;
            const resp = await fetch(url);
            if (!resp.ok) throw new Error('Weather API error');
            const data = await resp.json();
            if (data.current_weather) {
                const temp = data.current_weather.temperature !== undefined ? `${Math.round(data.current_weather.temperature)}°C` : '--°C';
                document.getElementById('navTemp').textContent = temp;
            }
        } catch (e) {
            console.warn('Weather fetch error:', e);
        }
    }

    async function getWeatherByCity(city) {
        try {
            const geoResp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
            const geoData = await geoResp.json();
            if (geoData && geoData.length > 0) {
                const { lat, lon } = geoData[0];
                await getWeatherData(parseFloat(lat), parseFloat(lon));
            }
        } catch (e) {
            console.warn('City geocode error:', e);
        }
    }

    // ============================================================
    // HELPERS
    // ============================================================

    function getDaysSincePlanting(plantingDate) {
        if (!plantingDate) return 0;
        const planted = new Date(plantingDate);
        const now = new Date();
        const diffTime = Math.abs(now - planted);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    function getCurrentStageFromData(cropName, daysSince, growthData) {
        const stages = growthData.stages;
        for (let i = 0; i < stages.length; i++) {
            if (daysSince >= stages[i].startDay && daysSince <= stages[i].endDay) {
                return stages[i];
            }
        }
        if (daysSince > growthData.totalDays) {
            return stages[stages.length - 1];
        }
        return null;
    }

    // ============================================================
    // MODAL HELPERS
    // ============================================================

    window.openModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    };

    window.closeModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    };

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
                document.body.style.overflow = 'auto';
            }
        });
    });

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast show ${type || ''}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // ============================================================
    // EXPOSE FUNCTIONS FOR ONCLICK
    // ============================================================
    
    window.openTaskModal = openTaskModal;
    window.showTaskDetail = showTaskDetail;
    window.toggleTask = toggleTask;
    window.deleteTask = deleteTask;
    window.addAIRecommendation = addAIRecommendation;
    window.dismissRecommendation = dismissRecommendation;
    window.addMonthlyTask = addMonthlyTask;
    window.applyFilters = applyFilters;
    window.closeModal = closeModal;
    window.changeMonth = changeMonth;
    window.goToToday = goToToday;
    window.setView = setView;
    window.selectDay = selectDay;

    // ============================================================
    // INIT
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();