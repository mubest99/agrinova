(function() {
    "use strict";

    // ============================================================
    // DATA HELPERS - Read from localStorage
    // ============================================================

    function getFarmer() {
        let raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) raw = localStorage.getItem('farmer');
        if (!raw) raw = localStorage.getItem('user');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    // My Farm Data Storage
    function getFarmData() {
        let raw = localStorage.getItem('agrinova_farm_data');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    function saveFarmData(data) {
        localStorage.setItem('agrinova_farm_data', JSON.stringify(data));
    }

    // ============================================================
    // PROFILE & GREETING
    // ============================================================

    function updateProfile() {
        const farmer = getFarmer();
        if (!farmer) return;

        const firstName = farmer.firstName || farmer.firstname || farmer.first_name || farmer.name || 'Farmer';
        document.getElementById('navName').textContent = firstName;

        const fullName = farmer.fullName || farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('pdName').textContent = fullName;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || farmer.phoneNumber || '—';

        const city = farmer.city || farmer.location || '—';
        const region = farmer.region || farmer.state || '—';
        const loc = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdLocation').textContent = loc;

        const farmland = farmer.farmland || farmer.farmArea || farmer.farm_size || farmer.landSize || '—';
        document.getElementById('pdFarmland').textContent = farmland !== '—' ? `${farmland} ha` : '—';
    }

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }
        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // FARM PROFILE
    // ============================================================

    function loadFarmProfile() {
        const farmer = getFarmer();
        const farmData = getFarmData();
        const profile = farmData.profile || {};

        // Get data from registration or farm profile
        const farmName = profile.farmName || 'My Farm';
        const city = profile.city || farmer?.city || 'City';
        const region = profile.region || farmer?.region || 'Region';
        const area = profile.totalArea || farmer?.farmland || farmer?.farmArea || '--';
        const farmType = profile.farmType || 'Not set';

        document.getElementById('farmNameDisplay').textContent = farmName;
        document.getElementById('farmLocationDisplay').textContent = `${city}, ${region}, Ethiopia`;
        document.getElementById('farmAreaDisplay').textContent = area !== '--' ? area : '--';
        document.getElementById('farmTypeDisplay').textContent = farmType;

        // Stats
        const sections = farmData.landSections || [];
        const totalArea = parseFloat(area) || 0;
        const cultivatedArea = sections
            .filter(s => s.landUse === 'Crop Production')
            .reduce((sum, s) => sum + (parseFloat(s.area) || 0), 0);
        const allocatedArea = sections.reduce((sum, s) => sum + (parseFloat(s.area) || 0), 0);
        const availableArea = totalArea - allocatedArea;

        document.getElementById('statTotalArea').textContent = totalArea > 0 ? `${totalArea} ha` : '--';
        document.getElementById('statCultivated').textContent = cultivatedArea > 0 ? `${cultivatedArea.toFixed(1)} ha` : '--';
        document.getElementById('statAvailable').textContent = availableArea > 0 ? `${availableArea.toFixed(1)} ha` : '--';
        document.getElementById('statSections').textContent = sections.length;

        // Check for area warning
        if (allocatedArea > totalArea && totalArea > 0) {
            showToast('Warning: The total area of your land sections exceeds your recorded farm area.', 'warning');
        }
    }

    // ============================================================
    // LAND SECTIONS
    // ============================================================

    function renderLandSections() {
        const container = document.getElementById('landSectionsContainer');
        const farmData = getFarmData();
        const sections = farmData.landSections || [];

        if (sections.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-map"></i>
                    <p>No land sections added yet.</p>
                    <button class="btn-primary btn-sm" onclick="document.getElementById('addLandSectionBtn').click()">
                        + Add First Land Section
                    </button>
                </div>
            `;
            return;
        }

        let html = '';
        sections.forEach((section, index) => {
            html += `
                <div class="land-section-item">
                    <div class="land-section-info">
                        <div class="land-section-name">${section.name || 'Unnamed Section'}</div>
                        <div class="land-section-details">
                            ${section.area || 0} ha · ${section.landUse || 'Not specified'}
                            ${section.crop ? ` · Crop: ${section.crop}` : ''}
                        </div>
                    </div>
                    <div class="land-section-actions">
                        <button class="btn-secondary btn-sm" onclick="editLandSection('${section.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-danger btn-sm" onclick="deleteLandSection('${section.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function addLandSection(data) {
        const farmData = getFarmData();
        if (!farmData.landSections) farmData.landSections = [];

        const newSection = {
            id: 'section_' + Date.now(),
            name: data.name,
            area: data.area,
            landUse: data.landUse || 'Crop Production',
            crop: data.crop || '',
            notes: data.notes || '',
            createdAt: new Date().toISOString()
        };

        farmData.landSections.push(newSection);
        saveFarmData(farmData);
        addHistoryEntry('Land section added', `${newSection.name} (${newSection.area} ha)`);
        renderLandSections();
        loadFarmProfile();
        renderLandUtilization();
        showToast('Land section added successfully!');
    }

    function editLandSection(id) {
        const farmData = getFarmData();
        const sections = farmData.landSections || [];
        const section = sections.find(s => s.id === id);
        if (!section) return;

        document.getElementById('editSectionId').value = id;
        document.getElementById('sectionNameInput').value = section.name || '';
        document.getElementById('sectionAreaInput').value = section.area || '';
        document.getElementById('sectionUseInput').value = section.landUse || 'Crop Production';
        document.getElementById('sectionCropInput').value = section.crop || '';
        document.getElementById('sectionNotesInput').value = section.notes || '';
        document.getElementById('landSectionModalTitle').textContent = 'Edit Land Section';
        openModal('landSectionModal');
    }

    function deleteLandSection(id) {
        if (!confirm('Are you sure you want to delete this land section?')) return;

        const farmData = getFarmData();
        farmData.landSections = (farmData.landSections || []).filter(s => s.id !== id);
        saveFarmData(farmData);
        addHistoryEntry('Land section deleted', `Section ID: ${id}`);
        renderLandSections();
        loadFarmProfile();
        renderLandUtilization();
        showToast('Land section deleted.');
    }

    // ============================================================
    // LAND UTILIZATION
    // ============================================================

    function renderLandUtilization() {
        const container = document.getElementById('landUtilizationContainer');
        const farmData = getFarmData();
        const sections = farmData.landSections || [];

        if (sections.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-chart-pie"></i>
                    <p>Add land sections to view land utilization.</p>
                </div>
            `;
            return;
        }

        const totalArea = sections.reduce((sum, s) => sum + (parseFloat(s.area) || 0), 0);
        const utilization = {};

        sections.forEach(s => {
            const use = s.landUse || 'Other';
            const area = parseFloat(s.area) || 0;
            utilization[use] = (utilization[use] || 0) + area;
        });

        const colors = {
            'Crop Production': '#4F8A45',
            'Fallow / Unused': '#A8C686',
            'Pasture': '#8B7355',
            'Infrastructure': '#6B766E',
            'Other': '#D4A76A'
        };

        let html = '';
        for (const [use, area] of Object.entries(utilization)) {
            const percent = totalArea > 0 ? (area / totalArea * 100) : 0;
            const color = colors[use] || '#6B766E';
            html += `
                <div class="utilization-item">
                    <span class="utilization-label">${use}</span>
                    <div class="utilization-bar">
                        <div class="utilization-fill" style="width: ${percent}%; background: ${color};"></div>
                    </div>
                    <span class="utilization-value">${area.toFixed(1)} ha (${percent.toFixed(0)}%)</span>
                </div>
            `;
        }

        container.innerHTML = html;
    }

    // ============================================================
    // FARM CONDITIONS
    // ============================================================

    function renderFarmConditions() {
        const container = document.getElementById('farmConditionsContainer');
        const farmData = getFarmData();
        const conditions = farmData.conditions || {};

        if (!conditions.soilType && !conditions.terrain && !conditions.generalConditions) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clipboard-check"></i>
                    <p>Farm conditions not added yet.</p>
                </div>
            `;
            return;
        }

        let html = '<div style="display:grid; gap:0.5rem;">';
        if (conditions.soilType) {
            html += `<div><strong>Soil Type:</strong> ${conditions.soilType}</div>`;
        }
        if (conditions.soilTestDate) {
            html += `<div><strong>Soil Test Date:</strong> ${conditions.soilTestDate}</div>`;
        }
        if (conditions.soilNotes) {
            html += `<div><strong>Soil Notes:</strong> ${conditions.soilNotes}</div>`;
        }
        if (conditions.terrain) {
            html += `<div><strong>Terrain:</strong> ${conditions.terrain}</div>`;
        }
        if (conditions.generalConditions) {
            html += `<div><strong>General Conditions:</strong> ${conditions.generalConditions}</div>`;
        }
        html += '</div>';
        container.innerHTML = html;
    }

    // ============================================================
    // WATER & IRRIGATION
    // ============================================================

    function renderWater() {
        const container = document.getElementById('waterContainer');
        const farmData = getFarmData();
        const water = farmData.water || {};

        if (!water.waterSource && !water.irrigationAvailability) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-water"></i>
                    <p>Water and irrigation information not added.</p>
                </div>
            `;
            return;
        }

        let html = '<div style="display:grid; gap:0.5rem;">';
        if (water.waterSource) {
            html += `<div><strong>Water Source:</strong> ${water.waterSource}</div>`;
        }
        if (water.irrigationAvailability) {
            html += `<div><strong>Irrigation:</strong> ${water.irrigationAvailability}</div>`;
        }
        if (water.irrigationMethod) {
            html += `<div><strong>Method:</strong> ${water.irrigationMethod}</div>`;
        }
        if (water.irrigatedArea) {
            html += `<div><strong>Irrigated Area:</strong> ${water.irrigatedArea} ha</div>`;
        }
        if (water.notes) {
            html += `<div><strong>Notes:</strong> ${water.notes}</div>`;
        }
        html += '</div>';
        container.innerHTML = html;
    }

    // ============================================================
    // FARM LOCATION
    // ============================================================

    function renderLocation() {
        const container = document.getElementById('locationContainer');
        const farmData = getFarmData();
        const location = farmData.location || {};
        const farmer = getFarmer();

        const city = location.city || farmer?.city || '—';
        const region = location.region || farmer?.region || '—';

        if (!location.city && !location.region && !location.lat && !location.lng) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-map-marker-alt"></i>
                    <p>Farm location not set.</p>
                </div>
            `;
            return;
        }

        let html = `<div><strong>City:</strong> ${city}</div>`;
        html += `<div><strong>Region:</strong> ${region}</div>`;
        if (location.lat && location.lng) {
            html += `<div><strong>Coordinates:</strong> ${location.lat}, ${location.lng}</div>`;
        }
        if (location.notes) {
            html += `<div><strong>Notes:</strong> ${location.notes}</div>`;
        }
        container.innerHTML = html;
    }

    // ============================================================
    // ASSETS & EQUIPMENT
    // ============================================================

    function renderAssets() {
        const container = document.getElementById('assetsContainer');
        const farmData = getFarmData();
        const assets = farmData.assets || [];

        if (assets.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-tools"></i>
                    <p>No farm assets recorded yet.</p>
                </div>
            `;
            return;
        }

        let html = '';
        assets.forEach(asset => {
            html += `
                <div class="land-section-item">
                    <div class="land-section-info">
                        <div class="land-section-name">${asset.name}</div>
                        <div class="land-section-details">
                            ${asset.category} · Qty: ${asset.quantity || 1}
                            ${asset.condition ? ` · ${asset.condition}` : ''}
                        </div>
                    </div>
                    <div class="land-section-actions">
                        <button class="btn-danger btn-sm" onclick="deleteAsset('${asset.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function deleteAsset(id) {
        if (!confirm('Delete this asset?')) return;
        const farmData = getFarmData();
        farmData.assets = (farmData.assets || []).filter(a => a.id !== id);
        saveFarmData(farmData);
        renderAssets();
        showToast('Asset deleted.');
    }

    // ============================================================
    // INFRASTRUCTURE
    // ============================================================

    function renderInfrastructure() {
        const container = document.getElementById('infrastructureContainer');
        const farmData = getFarmData();
        const infrastructures = farmData.infrastructure || [];

        if (infrastructures.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-warehouse"></i>
                    <p>No farm infrastructure recorded yet.</p>
                </div>
            `;
            return;
        }

        let html = '';
        infrastructures.forEach(item => {
            html += `
                <div class="land-section-item">
                    <div class="land-section-info">
                        <div class="land-section-name">${item.name}</div>
                        <div class="land-section-details">
                            ${item.type} ${item.capacity ? `· ${item.capacity}` : ''}
                            ${item.condition ? `· ${item.condition}` : ''}
                        </div>
                    </div>
                    <div class="land-section-actions">
                        <button class="btn-danger btn-sm" onclick="deleteInfrastructure('${item.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function deleteInfrastructure(id) {
        if (!confirm('Delete this infrastructure item?')) return;
        const farmData = getFarmData();
        farmData.infrastructure = (farmData.infrastructure || []).filter(i => i.id !== id);
        saveFarmData(farmData);
        renderInfrastructure();
        showToast('Infrastructure deleted.');
    }

    // ============================================================
    // SEASONAL PLANNING
    // ============================================================

    function renderSeasonalPlans() {
        const container = document.getElementById('seasonalPlanContainer');
        const farmData = getFarmData();
        const plans = farmData.seasonalPlans || [];

        if (plans.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-calendar-alt"></i>
                    <p>No seasonal plan created yet.</p>
                </div>
            `;
            return;
        }

        let html = '';
        plans.forEach(plan => {
            html += `
                <div class="land-section-item">
                    <div class="land-section-info">
                        <div class="land-section-name">${plan.season}</div>
                        <div class="land-section-details">
                            ${plan.crops ? `Crops: ${plan.crops}` : ''}
                            ${plan.landAllocation ? `· ${plan.landAllocation} ha` : ''}
                        </div>
                    </div>
                    <div class="land-section-actions">
                        <button class="btn-danger btn-sm" onclick="deleteSeasonalPlan('${plan.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function deleteSeasonalPlan(id) {
        if (!confirm('Delete this seasonal plan?')) return;
        const farmData = getFarmData();
        farmData.seasonalPlans = (farmData.seasonalPlans || []).filter(p => p.id !== id);
        saveFarmData(farmData);
        renderSeasonalPlans();
        showToast('Seasonal plan deleted.');
    }

    // ============================================================
    // FARM DOCUMENTS
    // ============================================================

    function renderDocuments() {
        const container = document.getElementById('documentsContainer');
        const farmData = getFarmData();
        const documents = farmData.documents || [];

        if (documents.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-file-alt"></i>
                    <p>No farm documents uploaded.</p>
                </div>
            `;
            return;
        }

        let html = '';
        documents.forEach(doc => {
            html += `
                <div class="land-section-item">
                    <div class="land-section-info">
                        <div class="land-section-name">${doc.name}</div>
                        <div class="land-section-details">
                            ${doc.category} · Uploaded: ${doc.uploadDate || '—'}
                        </div>
                    </div>
                    <div class="land-section-actions">
                        <button class="btn-danger btn-sm" onclick="deleteDocument('${doc.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function deleteDocument(id) {
        if (!confirm('Delete this document?')) return;
        const farmData = getFarmData();
        farmData.documents = (farmData.documents || []).filter(d => d.id !== id);
        saveFarmData(farmData);
        renderDocuments();
        showToast('Document deleted.');
    }

    // ============================================================
    // FARM HISTORY
    // ============================================================

    function renderHistory() {
        const container = document.getElementById('historyContainer');
        const farmData = getFarmData();
        const history = farmData.history || [];

        if (history.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p>No farm history available yet.</p>
                </div>
            `;
            return;
        }

        let html = '<div style="position:relative; padding-left:1.5rem;">';
        history.slice().reverse().forEach(item => {
            html += `
                <div style="border-left: 2px solid #4F8A45; padding-left: 1rem; padding-bottom: 0.8rem; position:relative;">
                    <div style="position:absolute; left:-6px; top:0; width:10px; height:10px; background:#4F8A45; border-radius:50%;"></div>
                    <div style="font-weight:500;">${item.event}</div>
                    <div style="font-size:0.85rem; color:#6B766E;">${item.details || ''}</div>
                    <div style="font-size:0.75rem; color:#8A948D;">${item.date || '—'}</div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;
    }

    function addHistoryEntry(event, details) {
        const farmData = getFarmData();
        if (!farmData.history) farmData.history = [];
        farmData.history.push({
            event: event,
            details: details || '',
            date: new Date().toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric', 
                year: 'numeric' 
            })
        });
        saveFarmData(farmData);
        renderHistory();
    }

    // ============================================================
    // FARM NOTES
    // ============================================================

    function renderNotes() {
        const container = document.getElementById('notesContainer');
        const farmData = getFarmData();
        const notes = farmData.notes || [];

        if (notes.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-sticky-note"></i>
                    <p>No farm notes added.</p>
                </div>
            `;
            return;
        }

        let html = '';
        notes.forEach(note => {
            html += `
                <div class="land-section-item">
                    <div class="land-section-info">
                        <div style="font-size:0.9rem;">${note.content}</div>
                        <div style="font-size:0.75rem; color:#6B766E;">${note.date || '—'}</div>
                    </div>
                    <div class="land-section-actions">
                        <button class="btn-danger btn-sm" onclick="deleteNote('${note.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function deleteNote(id) {
        if (!confirm('Delete this note?')) return;
        const farmData = getFarmData();
        farmData.notes = (farmData.notes || []).filter(n => n.id !== id);
        saveFarmData(farmData);
        renderNotes();
        showToast('Note deleted.');
    }

    // ============================================================
    // MODAL HELPERS
    // ============================================================

    window.openModal = function(id) {
        document.getElementById(id).classList.add('show');
    };

    window.closeModal = function(id) {
        document.getElementById(id).classList.remove('show');
    };

    // Close modals on backdrop click
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
            }
        });
    });

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast show ${type || ''}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // ============================================================
    // FORM HANDLERS
    // ============================================================

    // Farm Profile Form
    document.getElementById('farmProfileForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        if (!farmData.profile) farmData.profile = {};

        farmData.profile.farmName = document.getElementById('farmNameInput').value || 'My Farm';
        farmData.profile.farmType = document.getElementById('farmTypeInput').value || '';
        farmData.profile.description = document.getElementById('farmDescriptionInput').value || '';
        farmData.profile.totalArea = parseFloat(document.getElementById('farmAreaInput').value) || 0;
        farmData.profile.city = document.getElementById('farmCityInput').value || '';
        farmData.profile.region = document.getElementById('farmRegionInput').value || '';

        saveFarmData(farmData);
        closeModal('farmProfileModal');
        loadFarmProfile();
        addHistoryEntry('Farm profile updated', 'Farm information was updated');
        showToast('Farm profile saved successfully!');
    });

    // Land Section Form
    document.getElementById('landSectionForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const editId = document.getElementById('editSectionId').value;
        const data = {
            name: document.getElementById('sectionNameInput').value.trim(),
            area: parseFloat(document.getElementById('sectionAreaInput').value),
            landUse: document.getElementById('sectionUseInput').value,
            crop: document.getElementById('sectionCropInput').value.trim(),
            notes: document.getElementById('sectionNotesInput').value.trim()
        };

        if (!data.name || !data.area) {
            showToast('Please fill in all required fields.', 'error');
            return;
        }

        if (editId) {
            // Update existing
            const farmData = getFarmData();
            const section = (farmData.landSections || []).find(s => s.id === editId);
            if (section) {
                Object.assign(section, data);
                saveFarmData(farmData);
                addHistoryEntry('Land section updated', `${data.name} (${data.area} ha)`);
                showToast('Land section updated!');
            }
        } else {
            addLandSection(data);
        }

        document.getElementById('editSectionId').value = '';
        document.getElementById('landSectionModalTitle').textContent = 'Add Land Section';
        closeModal('landSectionModal');
        this.reset();
    });

    // Conditions Form
    document.getElementById('conditionsForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        farmData.conditions = {
            soilType: document.getElementById('soilTypeInput').value,
            soilTestDate: document.getElementById('soilTestDateInput').value,
            soilNotes: document.getElementById('soilNotesInput').value,
            terrain: document.getElementById('terrainInput').value,
            generalConditions: document.getElementById('generalConditionsInput').value
        };
        saveFarmData(farmData);
        closeModal('conditionsModal');
        renderFarmConditions();
        addHistoryEntry('Farm conditions updated', 'Soil and terrain information updated');
        showToast('Farm conditions saved!');
    });

    // Water Form
    document.getElementById('waterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        farmData.water = {
            waterSource: document.getElementById('waterSourceInput').value,
            irrigationAvailability: document.getElementById('irrigationAvailabilityInput').value,
            irrigationMethod: document.getElementById('irrigationMethodInput').value,
            irrigatedArea: parseFloat(document.getElementById('irrigatedAreaInput').value) || 0,
            notes: document.getElementById('waterNotesInput').value
        };
        saveFarmData(farmData);
        closeModal('waterModal');
        renderWater();
        addHistoryEntry('Water & irrigation updated', 'Water source and irrigation information updated');
        showToast('Water information saved!');
    });

    // Location Form
    document.getElementById('locationForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        farmData.location = {
            city: document.getElementById('locationCityInput').value,
            region: document.getElementById('locationRegionInput').value,
            lat: parseFloat(document.getElementById('locationLatInput').value) || null,
            lng: parseFloat(document.getElementById('locationLngInput').value) || null,
            notes: document.getElementById('locationNotesInput').value
        };
        saveFarmData(farmData);
        closeModal('locationModal');
        renderLocation();
        addHistoryEntry('Farm location updated', 'Location information updated');
        showToast('Location saved!');
    });

    // Asset Form
    document.getElementById('assetForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        if (!farmData.assets) farmData.assets = [];

        const asset = {
            id: 'asset_' + Date.now(),
            name: document.getElementById('assetNameInput').value.trim(),
            category: document.getElementById('assetCategoryInput').value,
            quantity: parseInt(document.getElementById('assetQuantityInput').value) || 1,
            condition: document.getElementById('assetConditionInput').value,
            notes: document.getElementById('assetNotesInput').value
        };

        farmData.assets.push(asset);
        saveFarmData(farmData);
        closeModal('assetModal');
        renderAssets();
        addHistoryEntry('Asset added', `${asset.name} (${asset.category})`);
        showToast('Asset added!');
        document.getElementById('assetForm').reset();
    });

    // Infrastructure Form
    document.getElementById('infrastructureForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        if (!farmData.infrastructure) farmData.infrastructure = [];

        const item = {
            id: 'infra_' + Date.now(),
            type: document.getElementById('infrastructureTypeInput').value,
            name: document.getElementById('infrastructureNameInput').value.trim(),
            capacity: document.getElementById('infrastructureCapacityInput').value,
            condition: document.getElementById('infrastructureConditionInput').value,
            notes: document.getElementById('infrastructureNotesInput').value
        };

        farmData.infrastructure.push(item);
        saveFarmData(farmData);
        closeModal('infrastructureModal');
        renderInfrastructure();
        addHistoryEntry('Infrastructure added', `${item.name} (${item.type})`);
        showToast('Infrastructure added!');
        document.getElementById('infrastructureForm').reset();
    });

    // Seasonal Plan Form
    document.getElementById('seasonalPlanForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        if (!farmData.seasonalPlans) farmData.seasonalPlans = [];

        const plan = {
            id: 'plan_' + Date.now(),
            season: document.getElementById('seasonNameInput').value.trim(),
            crops: document.getElementById('seasonCropsInput').value,
            landAllocation: parseFloat(document.getElementById('seasonLandInput').value) || 0,
            notes: document.getElementById('seasonNotesInput').value
        };

        farmData.seasonalPlans.push(plan);
        saveFarmData(farmData);
        closeModal('seasonalPlanModal');
        renderSeasonalPlans();
        addHistoryEntry('Seasonal plan created', plan.season);
        showToast('Seasonal plan created!');
        document.getElementById('seasonalPlanForm').reset();
    });

    // Document Form
    document.getElementById('documentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        if (!farmData.documents) farmData.documents = [];

        const fileInput = document.getElementById('documentFileInput');
        const fileName = fileInput.files[0] ? fileInput.files[0].name : 'No file';

        const doc = {
            id: 'doc_' + Date.now(),
            name: document.getElementById('documentNameInput').value.trim(),
            category: document.getElementById('documentCategoryInput').value,
            file: fileName,
            notes: document.getElementById('documentNotesInput').value,
            uploadDate: new Date().toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric', 
                year: 'numeric' 
            })
        };

        farmData.documents.push(doc);
        saveFarmData(farmData);
        closeModal('documentModal');
        renderDocuments();
        addHistoryEntry('Document uploaded', doc.name);
        showToast('Document uploaded!');
        document.getElementById('documentForm').reset();
    });

    // Note Form
    document.getElementById('noteForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const farmData = getFarmData();
        if (!farmData.notes) farmData.notes = [];

        const note = {
            id: 'note_' + Date.now(),
            content: document.getElementById('noteContentInput').value.trim(),
            date: new Date().toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric', 
                year: 'numeric' 
            })
        };

        farmData.notes.push(note);
        saveFarmData(farmData);
        closeModal('noteModal');
        renderNotes();
        addHistoryEntry('Farm note added', note.content.substring(0, 50) + (note.content.length > 50 ? '...' : ''));
        showToast('Note added!');
        document.getElementById('noteForm').reset();
    });

    // ============================================================
    // BUTTON EVENT LISTENERS
    // ============================================================

    // Edit Farm Profile
    document.getElementById('editFarmProfileBtn').addEventListener('click', function() {
        const farmData = getFarmData();
        const profile = farmData.profile || {};
        const farmer = getFarmer();

        document.getElementById('farmNameInput').value = profile.farmName || '';
        document.getElementById('farmTypeInput').value = profile.farmType || '';
        document.getElementById('farmDescriptionInput').value = profile.description || '';
        document.getElementById('farmAreaInput').value = profile.totalArea || farmer?.farmland || '';
        document.getElementById('farmCityInput').value = profile.city || farmer?.city || '';
        document.getElementById('farmRegionInput').value = profile.region || farmer?.region || '';
        openModal('farmProfileModal');
    });

    document.getElementById('editFarmProfileBtn2').addEventListener('click', function() {
        document.getElementById('editFarmProfileBtn').click();
    });

    // Add Land Section
    document.getElementById('addLandSectionBtn').addEventListener('click', function() {
        document.getElementById('editSectionId').value = '';
        document.getElementById('landSectionModalTitle').textContent = 'Add Land Section';
        document.getElementById('landSectionForm').reset();
        openModal('landSectionModal');
    });

    // Edit Conditions
    document.getElementById('editConditionsBtn').addEventListener('click', function() {
        const farmData = getFarmData();
        const conditions = farmData.conditions || {};
        document.getElementById('soilTypeInput').value = conditions.soilType || '';
        document.getElementById('soilTestDateInput').value = conditions.soilTestDate || '';
        document.getElementById('soilNotesInput').value = conditions.soilNotes || '';
        document.getElementById('terrainInput').value = conditions.terrain || '';
        document.getElementById('generalConditionsInput').value = conditions.generalConditions || '';
        openModal('conditionsModal');
    });

    // Edit Water
    document.getElementById('editWaterBtn').addEventListener('click', function() {
        const farmData = getFarmData();
        const water = farmData.water || {};
        document.getElementById('waterSourceInput').value = water.waterSource || '';
        document.getElementById('irrigationAvailabilityInput').value = water.irrigationAvailability || '';
        document.getElementById('irrigationMethodInput').value = water.irrigationMethod || '';
        document.getElementById('irrigatedAreaInput').value = water.irrigatedArea || '';
        document.getElementById('waterNotesInput').value = water.notes || '';
        openModal('waterModal');
    });

    // Edit Location
    document.getElementById('editLocationBtn').addEventListener('click', function() {
        const farmData = getFarmData();
        const location = farmData.location || {};
        const farmer = getFarmer();
        document.getElementById('locationCityInput').value = location.city || farmer?.city || '';
        document.getElementById('locationRegionInput').value = location.region || farmer?.region || '';
        document.getElementById('locationLatInput').value = location.lat || '';
        document.getElementById('locationLngInput').value = location.lng || '';
        document.getElementById('locationNotesInput').value = location.notes || '';
        openModal('locationModal');
    });

    // Add Asset
    document.getElementById('addAssetBtn').addEventListener('click', function() {
        document.getElementById('assetForm').reset();
        document.getElementById('assetModalTitle').textContent = 'Add Asset';
        openModal('assetModal');
    });

    // Add Infrastructure
    document.getElementById('addInfrastructureBtn').addEventListener('click', function() {
        document.getElementById('infrastructureForm').reset();
        document.getElementById('infrastructureModalTitle').textContent = 'Add Infrastructure';
        openModal('infrastructureModal');
    });

    // Add Seasonal Plan
    document.getElementById('addSeasonalPlanBtn').addEventListener('click', function() {
        document.getElementById('seasonalPlanForm').reset();
        document.getElementById('seasonalPlanModalTitle').textContent = 'Create Seasonal Plan';
        openModal('seasonalPlanModal');
    });

    // Add Document
    document.getElementById('addDocumentBtn').addEventListener('click', function() {
        document.getElementById('documentForm').reset();
        openModal('documentModal');
    });

    // Add Note
    document.getElementById('addNoteBtn').addEventListener('click', function() {
        document.getElementById('noteForm').reset();
        document.getElementById('noteModalTitle').textContent = 'Add Farm Note';
        openModal('noteModal');
    });

    // ============================================================
    // WEATHER (for nav temp)
    // ============================================================

    async function fetchNavWeather() {
        try {
            // Try geolocation first
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&timezone=auto`;
                        const resp = await fetch(url);
                        if (resp.ok) {
                            const data = await resp.json();
                            if (data.current_weather) {
                                document.getElementById('navTemp').textContent = data.current_weather.temperature + '°C';
                            }
                        }
                    },
                    async () => {
                        // Fallback: use city from registration
                        const farmer = getFarmer();
                        const city = farmer?.city || 'Addis Ababa';
                        const geoResp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
                        const geoData = await geoResp.json();
                        if (geoData && geoData.length > 0) {
                            const { lat, lon } = geoData[0];
                            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`;
                            const resp = await fetch(url);
                            if (resp.ok) {
                                const data = await resp.json();
                                if (data.current_weather) {
                                    document.getElementById('navTemp').textContent = data.current_weather.temperature + '°C';
                                }
                            }
                        }
                    }
                );
            }
        } catch (e) {
            console.warn('Nav weather error:', e);
        }
    }

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim();
                    if (query) {
                        // Search through farm data
                        const farmData = getFarmData();
                        let results = [];

                        // Search land sections
                        (farmData.landSections || []).forEach(s => {
                            if (s.name?.toLowerCase().includes(query.toLowerCase())) {
                                results.push(`Land Section: ${s.name}`);
                            }
                        });

                        // Search assets
                        (farmData.assets || []).forEach(a => {
                            if (a.name?.toLowerCase().includes(query.toLowerCase())) {
                                results.push(`Asset: ${a.name}`);
                            }
                        });

                        if (results.length > 0) {
                            showToast(`Found: ${results.join(', ')}`);
                        } else {
                            showToast('No results found in your farm data.');
                        }
                    }
                }
            });
        }
    }

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova My Farm Page Initializing...');
        
        updateProfile();
        setupProfileImage();
        setupDropdown();
        setupSearch();
        fetchNavWeather();
        
        loadFarmProfile();
        renderLandSections();
        renderLandUtilization();
        renderFarmConditions();
        renderWater();
        renderLocation();
        renderAssets();
        renderInfrastructure();
        renderSeasonalPlans();
        renderDocuments();
        renderHistory();
        renderNotes();

        // Add initial history entry if farm data exists
        const farmData = getFarmData();
        if (farmData && !farmData.history) {
            farmData.history = [];
            const farmer = getFarmer();
            if (farmer) {
                farmData.history.push({
                    event: 'Farm profile created',
                    details: `Initial registration from ${farmer.city || 'unknown location'}`,
                    date: new Date().toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric' 
                    })
                });
                saveFarmData(farmData);
                renderHistory();
            }
        }

        console.log('AgriNova My Farm Page Ready.');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();