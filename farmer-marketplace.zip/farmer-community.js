(function() {
    "use strict";

    // ============================================================
    // STORAGE FUNCTIONS
    // ============================================================

    function getPosts() {
        var raw = localStorage.getItem('agrinova_community_posts');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function savePosts(posts) {
        localStorage.setItem('agrinova_community_posts', JSON.stringify(posts));
    }

    function getComments() {
        var raw = localStorage.getItem('agrinova_community_comments');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    function saveComments(comments) {
        localStorage.setItem('agrinova_community_comments', JSON.stringify(comments));
    }

    function getFollows() {
        var raw = localStorage.getItem('agrinova_community_follows');
        if (!raw) return { followers: {}, following: {} };
        try { return JSON.parse(raw); } catch { return { followers: {}, following: {} }; }
    }

    function saveFollows(follows) {
        localStorage.setItem('agrinova_community_follows', JSON.stringify(follows));
    }

    function getLikes() {
        var raw = localStorage.getItem('agrinova_community_likes');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    function saveLikes(likes) {
        localStorage.setItem('agrinova_community_likes', JSON.stringify(likes));
    }

    function getReports() {
        var raw = localStorage.getItem('agrinova_community_reports');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveReports(reports) {
        localStorage.setItem('agrinova_community_reports', JSON.stringify(reports));
    }

    function getReposts() {
        var raw = localStorage.getItem('agrinova_community_reposts');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveReposts(reposts) {
        localStorage.setItem('agrinova_community_reposts', JSON.stringify(reposts));
    }

    // ============================================================
    // FARMER DATA HELPERS
    // ============================================================

    function getFarmer() {
        var raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getCurrentUserId() {
        var farmer = getFarmer();
        if (!farmer) return null;
        return farmer.id || farmer.email || 'farmer_' + Date.now();
    }

    function getCommunityDisplayName() {
        var farmer = getFarmer();
        if (!farmer) return 'Farmer';
        var fullName = farmer.name || farmer.fullName || farmer.firstName || 'Farmer';
        var parts = fullName.trim().split(/\s+/);
        if (parts.length >= 2) {
            return parts[0] + ' ' + parts[1];
        }
        return parts[0] || 'Farmer';
    }

    function getProfilePicture() {
        var saved = localStorage.getItem('agrinova_profileImage');
        if (saved) return saved;
        var farmer = getFarmer();
        if (farmer && farmer.profileImage) return farmer.profileImage;
        return null;
    }

    function getFarmerNameById(userId) {
        var farmers = getFarmersList();
        if (farmers[userId]) return farmers[userId].displayName || 'Farmer';
        return 'Farmer';
    }

    function getFarmerProfilePicture(userId) {
        var farmers = getFarmersList();
        if (farmers[userId]) return farmers[userId].profilePicture || null;
        return null;
    }

    function getFarmersList() {
        var raw = localStorage.getItem('agrinova_farmers_list');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    function saveFarmersList(farmers) {
        localStorage.setItem('agrinova_farmers_list', JSON.stringify(farmers));
    }

    function registerFarmer() {
        var farmer = getFarmer();
        if (!farmer) return;
        var userId = getCurrentUserId();
        var farmers = getFarmersList();
        if (!farmers[userId]) {
            farmers[userId] = {
                displayName: getCommunityDisplayName(),
                profilePicture: getProfilePicture(),
                joinedAt: new Date().toISOString()
            };
            saveFarmersList(farmers);
        } else {
            // Update existing
            farmers[userId].displayName = getCommunityDisplayName();
            var pic = getProfilePicture();
            if (pic) farmers[userId].profilePicture = pic;
            saveFarmersList(farmers);
        }
    }

    // ============================================================
    // STATE
    // ============================================================

    var state = {
        currentTab: 'for-you',
        currentPostId: null,
        currentCommentPostId: null,
        currentProfileUserId: null,
        viewingProfileUserId: null,
        mediaFiles: [],
        editingPostId: null
    };

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova Farmer Community Initializing...');

        var farmer = getFarmer();
        if (!farmer) {
            document.getElementById('mainFeed').innerHTML = `
                <div style="text-align:center; padding:3rem 1rem; background:rgba(252,252,249,0.9); border-radius:16px;">
                    <i class="fas fa-leaf" style="font-size:3rem; color:#2F7D4A; opacity:0.3; display:block; margin-bottom:1rem;"></i>
                    <h3 style="font-family:'Playfair Display',serif; color:#0B3D2E;">Welcome to the Farmer Community</h3>
                    <p style="color:#6B746E; margin:0.5rem 0 1.5rem;">Please log in to access the Farmer Community.</p>
                    <a href="index.html" class="btn-primary">Login</a>
                </div>
            `;
            return;
        }

        registerFarmer();
        updateNav();
        updateComposerAvatar();
        renderFeed();

        // Setup profile image upload
        setupProfileImageUpload();

        console.log('AgriNova Farmer Community Ready.');
    }

    // ============================================================
    // NAV
    // ============================================================

    window.switchTab = function(tab) {
        state.currentTab = tab;
        document.querySelectorAll('.nav-tab').forEach(function(el) {
            el.classList.toggle('active', el.dataset.tab === tab);
        });
        if (tab === 'profile') {
            showMyProfile();
        } else {
            renderFeed();
        }
    };

    function updateNav() {
        var name = getCommunityDisplayName();
        document.getElementById('navName').textContent = name;
        var pic = getProfilePicture();
        var avatar = document.getElementById('navAvatar');
        if (pic) {
            avatar.innerHTML = '<img src="' + pic + '" alt="Profile">';
        } else {
            avatar.innerHTML = '<i class="fas fa-user"></i>';
        }
        document.getElementById('composerUserName').textContent = name;
    }

    function updateComposerAvatar() {
        var pic = getProfilePicture();
        var avatar = document.getElementById('composerAvatar');
        if (pic) {
            avatar.innerHTML = '<img src="' + pic + '" alt="Profile">';
        } else {
            avatar.innerHTML = '<i class="fas fa-user"></i>';
        }
    }

    // ============================================================
    // COMPOSER
    // ============================================================

    window.openComposer = function() {
        document.getElementById('composerText').value = '';
        document.getElementById('composerMediaPreview').innerHTML = '';
        document.getElementById('composerAllowComments').checked = true;
        state.mediaFiles = [];
        state.editingPostId = null;
        openModal('composerModal');
    };

    window.handleComposerMedia = function(input, type) {
        var files = input.files;
        if (!files.length) return;

        var preview = document.getElementById('composerMediaPreview');
        var maxSize = type === 'photo' ? 700 * 1024 : 1 * 1024 * 1024; // 700KB for photos, 1MB for videos

        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            if (file.size > maxSize) {
                showToast(type === 'photo' ? 'Photo must be under 700KB.' : 'Video must be under 1MB.', 'error');
                continue;
            }
            var reader = new FileReader();
            reader.onload = function(ev) {
                var dataUrl = ev.target.result;
                state.mediaFiles.push({ type: type, data: dataUrl });
                var div = document.createElement('div');
                div.className = 'media-preview-item';
                if (type === 'photo') {
                    div.innerHTML = '<img src="' + dataUrl + '" alt="Media"><div class="remove-media" onclick="this.parentElement.remove(); state.mediaFiles = state.mediaFiles.filter(function(m) { return m.data !== "' + dataUrl + '"; });">&times;</div>';
                } else {
                    div.innerHTML = '<video src="' + dataUrl + '" muted></video><div class="remove-media" onclick="this.parentElement.remove(); state.mediaFiles = state.mediaFiles.filter(function(m) { return m.data !== "' + dataUrl + '"; });">&times;</div>';
                }
                preview.appendChild(div);
            };
            reader.readAsDataURL(file);
        }
        input.value = '';
    };

    window.submitPost = function() {
        var text = document.getElementById('composerText').value.trim();
        var allowComments = document.getElementById('composerAllowComments').checked;
        var farmer = getFarmer();
        if (!farmer) {
            showToast('Please log in to post.', 'error');
            return;
        }

        if (!text && state.mediaFiles.length === 0) {
            showToast('Please write something or add media.', 'warning');
            return;
        }

        var posts = getPosts();
        var userId = getCurrentUserId();

        if (state.editingPostId) {
            // Edit existing post
            var index = posts.findIndex(function(p) { return p.id === state.editingPostId; });
            if (index !== -1) {
                posts[index].text = text;
                posts[index].media = state.mediaFiles;
                posts[index].allowComments = allowComments;
                posts[index].updatedAt = new Date().toISOString();
                savePosts(posts);
                showToast('Post updated!', 'success');
            }
        } else {
            // New post
            var newPost = {
                id: 'post_' + Date.now(),
                userId: userId,
                displayName: getCommunityDisplayName(),
                profilePicture: getProfilePicture(),
                text: text,
                media: state.mediaFiles,
                allowComments: allowComments,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            posts.unshift(newPost);
            savePosts(posts);
            showToast('Post created!', 'success');
        }

        closeModal('composerModal');
        renderFeed();
    };

    // ============================================================
    // RENDER FEED
    // ============================================================

    function renderFeed() {
        var container = document.getElementById('postsContainer');
        var posts = getPosts();
        var userId = getCurrentUserId();
        var follows = getFollows();

        if (state.currentTab === 'following') {
            var following = follows.following[userId] || [];
            posts = posts.filter(function(p) {
                return following.indexOf(p.userId) !== -1;
            });
        }

        if (posts.length === 0) {
            var emptyMsg = state.currentTab === 'following' ?
                'You are not following anyone yet. Discover farmers and follow their journey.' :
                'Your community feed is waiting. No posts have been created yet.';
            container.innerHTML = `
                <div style="text-align:center; padding:3rem 1rem; background:rgba(252,252,249,0.9); border-radius:16px;">
                    <i class="fas fa-leaf" style="font-size:3rem; color:#2F7D4A; opacity:0.3; display:block; margin-bottom:1rem;"></i>
                    <h3 style="font-family:'Playfair Display',serif; color:#0B3D2E;">${state.currentTab === 'following' ? 'Following Feed' : 'Welcome to the Community'}</h3>
                    <p style="color:#6B746E; margin:0.5rem 0;">${emptyMsg}</p>
                    ${state.currentTab === 'following' ? `<button class="btn-secondary" onclick="switchTab('for-you')">Explore Farmers</button>` : `<button class="btn-primary" onclick="openComposer()">Create First Post</button>`}
                </div>
            `;
            return;
        }

        var html = '';
        for (var i = 0; i < posts.length; i++) {
            html += renderPostCard(posts[i], userId);
        }
        container.innerHTML = html;
    }

    function renderPostCard(post, currentUserId) {
        var isOwner = post.userId === currentUserId;
        var likes = getLikes();
        var postLikes = likes[post.id] || [];
        var isLiked = postLikes.indexOf(currentUserId) !== -1;
        var comments = getComments();
        var postComments = comments[post.id] || [];
        var reposts = getReposts();
        var isReposted = reposts.some(function(r) { return r.postId === post.id && r.userId === currentUserId; });
        var repostCount = reposts.filter(function(r) { return r.postId === post.id; }).length;

        var mediaHtml = '';
        if (post.media && post.media.length > 0) {
            post.media.forEach(function(m) {
                if (m.type === 'photo') {
                    mediaHtml += '<img src="' + m.data + '" alt="Post image" onclick="viewImage(\'' + m.data + '\')">';
                } else if (m.type === 'video') {
                    mediaHtml += '<video src="' + m.data + '" controls preload="metadata"></video>';
                }
            });
        }

        var commentsOffHtml = '';
        if (!post.allowComments) {
            commentsOffHtml = '<div class="comments-off">Comments are turned off for this post.</div>';
        }

        var dropdownHtml = '';
        if (isOwner) {
            dropdownHtml = `
                <div class="post-options">
                    <button class="post-options-btn" onclick="event.stopPropagation(); togglePostOptions('${post.id}')">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="post-options-dropdown" id="options_${post.id}">
                        <button onclick="editPost('${post.id}')"><i class="fas fa-edit"></i> Edit Post</button>
                        <button onclick="toggleCommentSettings('${post.id}')"><i class="fas fa-comment"></i> ${post.allowComments ? 'Disable' : 'Enable'} Comments</button>
                        <button class="danger" onclick="deletePost('${post.id}')"><i class="fas fa-trash"></i> Delete Post</button>
                    </div>
                </div>
            `;
        } else {
            dropdownHtml = `
                <div class="post-options">
                    <button class="post-options-btn" onclick="event.stopPropagation(); togglePostOptions('${post.id}')">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="post-options-dropdown" id="options_${post.id}">
                        <button onclick="reportPost('${post.id}')"><i class="fas fa-flag"></i> Report</button>
                    </div>
                </div>
            `;
        }

        var isFollowing = false;
        var follows = getFollows();
        if (follows.following[currentUserId] && follows.following[currentUserId].indexOf(post.userId) !== -1) {
            isFollowing = true;
        }

        var profilePic = post.profilePicture || '';
        var avatarHtml = profilePic ? '<img src="' + profilePic + '" alt="Profile">' : '<i class="fas fa-user"></i>';

        var timeAgo = getTimeAgo(post.createdAt);

        return `
            <div class="post-card" id="post_${post.id}">
                <div class="post-header">
                    <div class="post-avatar" onclick="viewProfile('${post.userId}')">${avatarHtml}</div>
                    <div class="post-user-info" onclick="viewProfile('${post.userId}')">
                        <div class="post-user-name">${post.displayName || 'Farmer'}</div>
                        <div class="post-time">${timeAgo}</div>
                    </div>
                    ${dropdownHtml}
                </div>
                ${post.text ? `<div class="post-text">${post.text}</div>` : ''}
                ${mediaHtml ? `<div class="post-media">${mediaHtml}</div>` : ''}
                <div class="post-stats">
                    <span>❤️ ${postLikes.length} Likes</span>
                    <span>💬 ${postComments.length} Comments</span>
                    <span>🔄 ${repostCount} Reposts</span>
                </div>
                ${commentsOffHtml}
                <div class="post-actions">
                    <button class="post-action-btn ${isLiked ? 'liked' : ''}" onclick="toggleLike('${post.id}')">
                        <i class="fas fa-heart"></i> <span class="count">${postLikes.length}</span>
                    </button>
                    ${post.allowComments !== false ? `<button class="post-action-btn" onclick="openComments('${post.id}')">
                        <i class="fas fa-comment"></i> <span class="count">${postComments.length}</span>
                    </button>` : '<span style="color:#6B746E; font-size:0.8rem; padding:0.3rem 0;">Comments disabled</span>'}
                    <button class="post-action-btn ${isReposted ? 'liked' : ''}" onclick="toggleRepost('${post.id}')">
                        <i class="fas fa-retweet"></i> <span class="count">${repostCount}</span>
                    </button>
                    <button class="post-action-btn" onclick="sharePost('${post.id}')">
                        <i class="fas fa-share-alt"></i>
                    </button>
                </div>
            </div>
        `;
    }

    // ============================================================
    // LIKE
    // ============================================================

    window.toggleLike = function(postId) {
        var userId = getCurrentUserId();
        if (!userId) { showToast('Please log in.', 'warning'); return; }

        var likes = getLikes();
        if (!likes[postId]) likes[postId] = [];
        var index = likes[postId].indexOf(userId);

        if (index !== -1) {
            likes[postId].splice(index, 1);
        } else {
            likes[postId].push(userId);
        }

        saveLikes(likes);
        renderFeed();
    };

    // ============================================================
    // COMMENTS
    // ============================================================

    window.openComments = function(postId) {
        state.currentCommentPostId = postId;
        var posts = getPosts();
        var post = posts.find(function(p) { return p.id === postId; });
        if (!post) { showToast('Post not found.', 'error'); return; }

        document.getElementById('commentModalTitle').textContent = 'Comments on ' + (post.displayName || 'Farmer') + '\'s post';
        renderComments(postId);
        document.getElementById('commentInput').value = '';
        openModal('commentModal');
    };

    function renderComments(postId) {
        var container = document.getElementById('commentsContainer');
        var comments = getComments();
        var postComments = comments[postId] || [];
        var userId = getCurrentUserId();

        if (postComments.length === 0) {
            container.innerHTML = '<div style="text-align:center; padding:1.5rem; color:#6B746E;">No comments yet.</div>';
            return;
        }

        var html = '';
        for (var i = postComments.length - 1; i >= 0; i--) {
            var c = postComments[i];
            var isOwner = c.userId === userId;
            var pic = c.profilePicture || '';
            var avatarHtml = pic ? '<img src="' + pic + '" alt="Profile">' : '<i class="fas fa-user"></i>';

            html += `
                <div class="comment-item" id="comment_${c.id}">
                    <div class="avatar">${avatarHtml}</div>
                    <div class="comment-body">
                        <div>
                            <span class="comment-name">${c.displayName || 'Farmer'}</span>
                            <span class="comment-time">${getTimeAgo(c.createdAt)}</span>
                        </div>
                        <div class="comment-text">${c.text}</div>
                        ${isOwner ? `<div class="comment-actions"><button onclick="deleteComment('${postId}', '${c.id}')">Delete</button></div>` : ''}
                    </div>
                </div>
            `;
        }
        container.innerHTML = html;
    }

    window.submitComment = function() {
        var input = document.getElementById('commentInput');
        var text = input.value.trim();
        if (!text) return;

        var postId = state.currentCommentPostId;
        if (!postId) { showToast('Error: No post selected.', 'error'); return; }

        var userId = getCurrentUserId();
        if (!userId) { showToast('Please log in.', 'warning'); return; }

        var comments = getComments();
        if (!comments[postId]) comments[postId] = [];

        var newComment = {
            id: 'comment_' + Date.now(),
            userId: userId,
            displayName: getCommunityDisplayName(),
            profilePicture: getProfilePicture(),
            text: text,
            createdAt: new Date().toISOString()
        };

        comments[postId].push(newComment);
        saveComments(comments);
        input.value = '';
        renderComments(postId);
        renderFeed();
        showToast('Comment added!', 'success');
    };

    window.deleteComment = function(postId, commentId) {
        if (!confirm('Delete this comment?')) return;
        var comments = getComments();
        if (comments[postId]) {
            comments[postId] = comments[postId].filter(function(c) { return c.id !== commentId; });
            saveComments(comments);
            renderComments(postId);
            renderFeed();
            showToast('Comment deleted.', 'info');
        }
    };

    // ============================================================
    // REPOST
    // ============================================================

    window.toggleRepost = function(postId) {
        var userId = getCurrentUserId();
        if (!userId) { showToast('Please log in.', 'warning'); return; }

        var reposts = getReposts();
        var existingIndex = reposts.findIndex(function(r) { return r.postId === postId && r.userId === userId; });

        if (existingIndex !== -1) {
            reposts.splice(existingIndex, 1);
            showToast('Repost removed.', 'info');
        } else {
            var posts = getPosts();
            var post = posts.find(function(p) { return p.id === postId; });
            if (!post) { showToast('Post not found.', 'error'); return; }

            reposts.push({
                postId: postId,
                userId: userId,
                displayName: getCommunityDisplayName(),
                originalCreatorId: post.userId,
                originalCreatorName: post.displayName,
                createdAt: new Date().toISOString()
            });
            showToast('Reposted!', 'success');
        }

        saveReposts(reposts);
        renderFeed();
    };

    // ============================================================
    // SHARE
    // ============================================================

    window.sharePost = function(postId) {
        var posts = getPosts();
        var post = posts.find(function(p) { return p.id === postId; });
        if (!post) { showToast('Post not found.', 'error'); return; }

        var shareText = post.text || 'Check out this post on AgriNova!';
        var shareUrl = window.location.href;

        if (navigator.share) {
            navigator.share({
                title: 'AgriNova Post',
                text: shareText,
                url: shareUrl
            }).catch(function() {});
        } else {
            // Fallback: copy to clipboard
            var textToCopy = shareText + '\n\n' + shareUrl;
            navigator.clipboard.writeText(textToCopy).then(function() {
                showToast('Share link copied to clipboard!', 'success');
            }).catch(function() {
                // Manual copy fallback
                var textarea = document.createElement('textarea');
                textarea.value = textToCopy;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                showToast('Share link copied!', 'success');
            });
        }
    };

    // ============================================================
    // FOLLOW
    // ============================================================

    window.toggleFollow = function(targetUserId) {
        var userId = getCurrentUserId();
        if (!userId) { showToast('Please log in.', 'warning'); return; }
        if (userId === targetUserId) { showToast('You cannot follow yourself.', 'warning'); return; }

        var follows = getFollows();
        if (!follows.following[userId]) follows.following[userId] = [];
        if (!follows.followers[targetUserId]) follows.followers[targetUserId] = [];

        var index = follows.following[userId].indexOf(targetUserId);

        if (index !== -1) {
            follows.following[userId].splice(index, 1);
            var followerIndex = follows.followers[targetUserId].indexOf(userId);
            if (followerIndex !== -1) follows.followers[targetUserId].splice(followerIndex, 1);
            showToast('Unfollowed.', 'info');
        } else {
            follows.following[userId].push(targetUserId);
            follows.followers[targetUserId].push(userId);
            showToast('Following!', 'success');
        }

        saveFollows(follows);
        renderProfile(state.viewingProfileUserId || state.currentProfileUserId);
        renderFeed();
    };

    // ============================================================
    // PROFILE
    // ============================================================

    window.viewProfile = function(userId) {
        state.viewingProfileUserId = userId;
        state.currentProfileUserId = userId;
        renderProfile(userId);
        openModal('profileModal');
    };

    window.showMyProfile = function() {
        var userId = getCurrentUserId();
        if (!userId) { showToast('Please log in.', 'warning'); return; }
        state.viewingProfileUserId = userId;
        state.currentProfileUserId = userId;
        renderProfile(userId);
        openModal('profileModal');
    };

    function renderProfile(userId) {
        var container = document.getElementById('profileContent');
        var farmers = getFarmersList();
        var farmer = farmers[userId];
        var posts = getPosts();
        var userPosts = posts.filter(function(p) { return p.userId === userId; });
        var follows = getFollows();
        var currentUserId = getCurrentUserId();

        var displayName = farmer ? farmer.displayName : getFarmerNameById(userId);
        var profilePic = farmer ? farmer.profilePicture : null;

        var followers = follows.followers[userId] || [];
        var following = follows.following[userId] || [];

        var isOwnProfile = userId === currentUserId;
        var isFollowing = false;
        if (follows.following[currentUserId] && follows.following[currentUserId].indexOf(userId) !== -1) {
            isFollowing = true;
        }

        var picHtml = profilePic ? '<img src="' + profilePic + '" alt="Profile">' : '<i class="fas fa-user"></i>';

        var followBtnHtml = '';
        if (!isOwnProfile) {
            followBtnHtml = `
                <button class="btn-follow ${isFollowing ? 'following' : ''}" onclick="toggleFollow('${userId}')">
                    ${isFollowing ? 'Following' : 'Follow'}
                </button>
            `;
        } else {
            followBtnHtml = `
                <button class="btn-secondary btn-sm" onclick="document.getElementById('profilePhotoInput').click()">
                    <i class="fas fa-camera"></i> Change Photo
                </button>
                <input type="file" id="profilePhotoInput" accept="image/*" style="display:none;" onchange="uploadProfilePhoto(this)">
            `;
        }

        document.getElementById('profileModalTitle').textContent = isOwnProfile ? 'My Profile' : 'Profile';

        var postsHtml = '';
        if (userPosts.length === 0) {
            postsHtml = '<p style="color:#6B746E; text-align:center; padding:0.5rem;">No posts yet.</p>';
        } else {
            userPosts.forEach(function(p) {
                postsHtml += `
                    <div style="padding:0.5rem 0; border-bottom:1px solid #EAE7DE; cursor:pointer;" onclick="closeModal('profileModal'); document.getElementById('post_${p.id}').scrollIntoView({behavior:'smooth'});">
                        <div style="font-size:0.85rem; color:#1F2D26;">${p.text ? p.text.substring(0, 100) + (p.text.length > 100 ? '...' : '') : '📷 Photo post'}</div>
                        <div style="font-size:0.7rem; color:#6B746E;">${getTimeAgo(p.createdAt)}</div>
                    </div>
                `;
            });
        }

        container.innerHTML = `
            <div class="profile-header">
                <div class="avatar">${picHtml}</div>
                <div class="profile-name">${displayName}</div>
                <div class="profile-stats">
                    <div class="stat" onclick="showFollowList('${userId}', 'followers')">
                        <div class="num">${followers.length}</div>
                        <div class="label">Followers</div>
                    </div>
                    <div class="stat" onclick="showFollowList('${userId}', 'following')">
                        <div class="num">${following.length}</div>
                        <div class="label">Following</div>
                    </div>
                    <div class="stat">
                        <div class="num">${userPosts.length}</div>
                        <div class="label">Posts</div>
                    </div>
                </div>
                <div class="profile-follow-btn">${followBtnHtml}</div>
            </div>
            <div class="profile-posts">
                <div class="profile-posts-title">Posts</div>
                ${postsHtml}
            </div>
        `;
    }

    // ============================================================
    // PROFILE PHOTO UPLOAD
    // ============================================================

    window.uploadProfilePhoto = function(input) {
        var file = input.files[0];
        if (!file) return;
        if (file.size > 700 * 1024) {
            showToast('Image must be under 700KB.', 'error');
            return;
        }
        if (!file.type.startsWith('image/')) {
            showToast('Please select an image.', 'error');
            return;
        }
        var reader = new FileReader();
        reader.onload = function(ev) {
            var dataUrl = ev.target.result;
            localStorage.setItem('agrinova_profileImage', dataUrl);
            // Update farmer list
            var farmers = getFarmersList();
            var userId = getCurrentUserId();
            if (farmers[userId]) {
                farmers[userId].profilePicture = dataUrl;
                saveFarmersList(farmers);
            }
            updateNav();
            updateComposerAvatar();
            renderProfile(userId);
            renderFeed();
            showToast('Profile picture updated!', 'success');
        };
        reader.readAsDataURL(file);
        input.value = '';
    };

    function setupProfileImageUpload() {
        // Handle existing upload button in modal
        document.addEventListener('change', function(e) {
            if (e.target.id === 'profilePhotoInput') {
                // Already handled above
            }
        });
    }

    // ============================================================
    // FOLLOW LISTS
    // ============================================================

    window.showFollowList = function(userId, type) {
        var follows = getFollows();
        var list = type === 'followers' ? (follows.followers[userId] || []) : (follows.following[userId] || []);
        var farmers = getFarmersList();

        document.getElementById('followModalTitle').textContent = type === 'followers' ? 'Followers' : 'Following';

        if (list.length === 0) {
            document.getElementById('followListContainer').innerHTML = `
                <div style="text-align:center; padding:1.5rem; color:#6B746E;">
                    ${type === 'followers' ? 'No followers yet.' : 'Not following anyone yet.'}
                </div>
            `;
        } else {
            var html = '';
            var currentUserId = getCurrentUserId();
            for (var i = 0; i < list.length; i++) {
                var id = list[i];
                var farmer = farmers[id] || {};
                var displayName = farmer.displayName || getFarmerNameById(id);
                var pic = farmer.profilePicture || null;
                var avatarHtml = pic ? '<img src="' + pic + '" alt="Profile">' : '<i class="fas fa-user"></i>';
                var isFollowing = false;
                if (follows.following[currentUserId] && follows.following[currentUserId].indexOf(id) !== -1) {
                    isFollowing = true;
                }
                var followBtn = '';
                if (id !== currentUserId) {
                    followBtn = `<button class="btn-follow ${isFollowing ? 'following' : ''}" style="font-size:0.7rem; padding:0.1rem 0.8rem;" onclick="toggleFollow('${id}'); showFollowList('${userId}', '${type}');">${isFollowing ? 'Following' : 'Follow'}</button>`;
                }

                html += `
                    <div style="display:flex; align-items:center; gap:0.8rem; padding:0.5rem 0; border-bottom:1px solid #EAE7DE;">
                        <div class="avatar" style="width:32px; height:32px; border-radius:50%; background:#A8C69F; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">${avatarHtml}</div>
                        <div style="flex:1; cursor:pointer;" onclick="closeModal('followModal'); viewProfile('${id}')">
                            <div style="font-weight:500;">${displayName}</div>
                        </div>
                        ${followBtn}
                    </div>
                `;
            }
            document.getElementById('followListContainer').innerHTML = html;
        }
        openModal('followModal');
    };

    // ============================================================
    // POST OPTIONS
    // ============================================================

    window.togglePostOptions = function(postId) {
        var dropdown = document.getElementById('options_' + postId);
        if (dropdown) {
            dropdown.classList.toggle('show');
            // Close other dropdowns
            document.querySelectorAll('.post-options-dropdown').forEach(function(el) {
                if (el.id !== 'options_' + postId) {
                    el.classList.remove('show');
                }
            });
        }
    };

    // Close dropdowns on click outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.post-options')) {
            document.querySelectorAll('.post-options-dropdown').forEach(function(el) {
                el.classList.remove('show');
            });
        }
    });

    window.editPost = function(postId) {
        var posts = getPosts();
        var post = posts.find(function(p) { return p.id === postId; });
        if (!post) { showToast('Post not found.', 'error'); return; }

        state.editingPostId = postId;
        document.getElementById('composerText').value = post.text || '';
        document.getElementById('composerAllowComments').checked = post.allowComments !== false;
        document.getElementById('composerMediaPreview').innerHTML = '';
        state.mediaFiles = post.media ? post.media.slice() : [];

        if (state.mediaFiles.length > 0) {
            var preview = document.getElementById('composerMediaPreview');
            state.mediaFiles.forEach(function(m) {
                var div = document.createElement('div');
                div.className = 'media-preview-item';
                if (m.type === 'photo') {
                    div.innerHTML = '<img src="' + m.data + '" alt="Media"><div class="remove-media" onclick="this.parentElement.remove(); state.mediaFiles = state.mediaFiles.filter(function(media) { return media.data !== "' + m.data + '"; });">&times;</div>';
                } else {
                    div.innerHTML = '<video src="' + m.data + '" muted></video><div class="remove-media" onclick="this.parentElement.remove(); state.mediaFiles = state.mediaFiles.filter(function(media) { return media.data !== "' + m.data + '"; });">&times;</div>';
                }
                preview.appendChild(div);
            });
        }

        openModal('composerModal');
        document.querySelector('.post-submit').textContent = 'Update Post';
    };

    window.deletePost = function(postId) {
        if (!confirm('Are you sure you want to delete this post?')) return;
        var posts = getPosts();
        posts = posts.filter(function(p) { return p.id !== postId; });
        savePosts(posts);
        // Delete associated comments
        var comments = getComments();
        delete comments[postId];
        saveComments(comments);
        renderFeed();
        showToast('Post deleted.', 'info');
    };

    window.toggleCommentSettings = function(postId) {
        var posts = getPosts();
        var post = posts.find(function(p) { return p.id === postId; });
        if (!post) return;
        post.allowComments = !post.allowComments;
        savePosts(posts);
        renderFeed();
        showToast(post.allowComments ? 'Comments enabled.' : 'Comments disabled.', 'info');
    };

    // ============================================================
    // REPORT
    // ============================================================

    var reportPostId = null;

    window.reportPost = function(postId) {
        reportPostId = postId;
        openModal('reportModal');
    };

    window.submitReport = function(reason) {
        if (!reportPostId) return;
        var reports = getReports();
        reports.push({
            postId: reportPostId,
            reason: reason,
            reportedBy: getCurrentUserId(),
            reportedAt: new Date().toISOString()
        });
        saveReports(reports);
        closeModal('reportModal');
        showToast('Report submitted and stored locally for this prototype.', 'info');
        reportPostId = null;
    };

    // ============================================================
    // IMAGE VIEWER
    // ============================================================

    window.viewImage = function(src) {
        document.getElementById('imageViewerImg').src = src;
        openModal('imageViewerModal');
    };

    // ============================================================
    // TIME HELPERS
    // ============================================================

    function getTimeAgo(dateString) {
        var now = new Date();
        var past = new Date(dateString);
        var diffMs = now - past;
        var diffSec = Math.floor(diffMs / 1000);
        var diffMin = Math.floor(diffSec / 60);
        var diffHour = Math.floor(diffMin / 60);
        var diffDay = Math.floor(diffHour / 24);
        var diffWeek = Math.floor(diffDay / 7);
        var diffMonth = Math.floor(diffDay / 30);
        var diffYear = Math.floor(diffDay / 365);

        if (diffSec < 60) return 'Just now';
        if (diffMin < 60) return diffMin + 'm ago';
        if (diffHour < 24) return diffHour + 'h ago';
        if (diffDay < 7) return diffDay + 'd ago';
        if (diffWeek < 4) return diffWeek + 'w ago';
        if (diffMonth < 12) return diffMonth + 'mo ago';
        return diffYear + 'y ago';
    }

    // ============================================================
    // MODAL HELPERS
    // ============================================================

    window.openModal = function(id) {
        var modal = document.getElementById(id);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    };

    window.closeModal = function(id) {
        var modal = document.getElementById(id);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    };

    document.querySelectorAll('.modal').forEach(function(modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
                document.body.style.overflow = 'auto';
            }
        });
    });

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        var existing = document.querySelector('.toast');
        if (existing) existing.remove();

        var toast = document.createElement('div');
        toast.className = 'toast show ' + (type || '');
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(function() {
            toast.classList.remove('show');
            setTimeout(function() { toast.remove(); }, 300);
        }, 3500);
    }

    window.showToast = showToast;

    // ============================================================
    // INJECT TOAST STYLES
    // ============================================================

    (function injectToastStyles() {
        var style = document.createElement('style');
        style.textContent = `
            .toast {
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                background: #0B3D2E;
                color: #fff;
                padding: 0.8rem 1.5rem;
                border-radius: 12px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.15);
                z-index: 2000;
                display: none;
                max-width: 400px;
                animation: slideUp 0.3s ease;
                font-family: 'Inter', sans-serif;
                font-size: 0.9rem;
            }
            .toast.show { display: block; }
            .toast.error { background: #B85C45; }
            .toast.warning { background: #C68A2B; }
            .toast.success { background: #2F7D4A; }
            .toast.info { background: #145A3A; }
            @keyframes slideUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(style);
    })();

    // ============================================================
    // START
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();