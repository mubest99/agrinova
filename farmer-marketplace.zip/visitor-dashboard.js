// ===== VISITOR DASHBOARD — JAVASCRIPT =====
// Weather Feature: HTML5 Geolocation → IP Fallback → Open-Meteo API

(function() {

    // ----- 1. WEATHER DATA (will be populated from API) -----
    let weatherData = {
        temp: '--',
        condition: 'Loading...',
        rain: '--',
        humidity: '--',
        wind: '--',
        recommendation: 'Fetching weather data...'
    };

    // ----- 2. WEATHER PHOTOS BASED ON CONDITION -----
    const weatherPhotos = {
        sunny: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80',
        rainy: 'https://images.unsplash.com/photo-1519692933481-e162a57d6721?w=800&q=80',
        cloudy: 'https://images.unsplash.com/photo-1534088568595-a310f17c5d8c?w=800&q=80',
        windy: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80',
        snowy: 'https://images.unsplash.com/photo-1478265409135-1ad5c8afad5f?w=800&q=80',
        foggy: 'https://images.unsplash.com/photo-1487621167305-5d248087c724?w=800&q=80',
        default: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80'
    };

    const conditionNames = {
        sunny: '☀️ Sunny',
        rainy: '🌧️ Rainy',
        cloudy: '☁️ Cloudy',
        windy: '💨 Windy',
        snowy: '❄️ Snowy',
        foggy: '🌫️ Foggy',
        default: 'Weather'
    };

    // ----- 3. WMO WEATHER CODE TO CONDITION MAPPING -----
    function getConditionFromCode(code) {
        // WMO Weather code to description mapping
        const conditions = {
            0: 'sunny',
            1: 'sunny',
            2: 'cloudy',
            3: 'cloudy',
            45: 'foggy',
            48: 'foggy',
            51: 'rainy',
            53: 'rainy',
            55: 'rainy',
            56: 'rainy',
            57: 'rainy',
            61: 'rainy',
            63: 'rainy',
            65: 'rainy',
            66: 'rainy',
            67: 'rainy',
            71: 'snowy',
            73: 'snowy',
            75: 'snowy',
            77: 'snowy',
            80: 'rainy',
            81: 'rainy',
            82: 'rainy',
            85: 'snowy',
            86: 'snowy',
            95: 'rainy',
            96: 'rainy',
            99: 'rainy'
        };
        return conditions[code] || 'default';
    }

    // ----- 4. GET WEATHER RECOMMENDATION -----
    function getWeatherRecommendation(condition, rainProb, windSpeed) {
        if (condition === 'rainy' && rainProb > 70) {
            return 'Heavy rainfall is expected. Consider postponing irrigation and outdoor activities.';
        } else if (condition === 'rainy' && rainProb > 40) {
            return 'Rain is expected today. Farmers may need to consider current rainfall before irrigating.';
        } else if (windSpeed > 30) {
            return 'Strong winds expected. Avoid spraying pesticides during high-wind conditions.';
        } else if (windSpeed > 20) {
            return 'Moderate winds today. Check for wind-sensitive crops.';
        } else if (condition === 'sunny') {
            return 'Clear skies today. Good conditions for field work and harvesting.';
        } else if (condition === 'cloudy') {
            return 'Overcast conditions. Check soil moisture before irrigation.';
        } else {
            return 'No significant weather concerns. Continue regular farm activities.';
        }
    }

    // ----- 5. UPDATE WEATHER UI -----
    function updateWeatherUI(data) {
        const weatherImage = document.getElementById('weatherImage');
        const weatherPlaceholder = document.getElementById('weatherPlaceholder');

        // Update image
        const photo = weatherPhotos[data.condition] || weatherPhotos.default;
        weatherImage.style.backgroundImage = `url('${photo}')`;

        // Update placeholder with real data
        weatherPlaceholder.innerHTML = `
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0.5rem; width: 100%; text-align: center;">
                <div>
                    <div style="font-size: 0.65rem; text-transform: uppercase; opacity: 0.7;">Temperature</div>
                    <div style="font-size: 1.5rem; font-weight: 700; color: #164A2A;">${data.temp}°C</div>
                </div>
                <div>
                    <div style="font-size: 0.65rem; text-transform: uppercase; opacity: 0.7;">Condition</div>
                    <div style="font-size: 1.1rem; font-weight: 600; color: #164A2A;">${conditionNames[data.condition] || data.condition}</div>
                </div>
                <div>
                    <div style="font-size: 0.65rem; text-transform: uppercase; opacity: 0.7;">Rain</div>
                    <div style="font-size: 1.1rem; font-weight: 600; color: #164A2A;">${data.rain}%</div>
                </div>
                <div>
                    <div style="font-size: 0.65rem; text-transform: uppercase; opacity: 0.7;">Humidity</div>
                    <div style="font-size: 1.1rem; font-weight: 600; color: #164A2A;">${data.humidity}%</div>
                </div>
                <div>
                    <div style="font-size: 0.65rem; text-transform: uppercase; opacity: 0.7;">Wind</div>
                    <div style="font-size: 1.1rem; font-weight: 600; color: #164A2A;">${data.wind} km/h</div>
                </div>
                <div></div>
            </div>
            <div style="margin-top: 0.8rem; padding: 0.6rem 1rem; background: rgba(22, 74, 42, 0.06); border-radius: 12px; border-left: 3px solid #D9A441; font-size: 0.9rem; width: 100%; text-align: left; color: #26332A;">
                <span style="font-weight: 600;">📋 Recommendation:</span> ${data.recommendation}
            </div>
        `;
    }

    // ----- 6. SHOW WEATHER LOADING/PLACEHOLDER -----
    function showWeatherPlaceholder(message) {
        const weatherPlaceholder = document.getElementById('weatherPlaceholder');
        weatherPlaceholder.innerHTML = `
            <p class="placeholder-text">${message || 'Weather data unavailable'}</p>
            <p class="placeholder-sub">Please allow location access or try again later.</p>
        `;
    }

    // ----- 7. FETCH WEATHER FROM OPEN-METEO -----
    function fetchWeatherFromOpenMeteo(lat, lon) {
        // Explicitly request current variables: temperature (°C), relative humidity (%), wind speed (km/h), weather code
        // & daily precipitation probability max (%)
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=precipitation_probability_max&wind_speed_unit=kmh&timezone=auto`;

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Weather API response not OK');
                }
                return response.json();
            })
            .then(data => {
                const current = data.current;
                const temp = Math.round(current.temperature_2m); // Exact Celsius
                const wind = Math.round(current.wind_speed_10m); // Exact km/h
                const humidity = Math.round(current.relative_humidity_2m); // Exact real-time humidity (%)
                const weatherCode = current.weather_code;
                const condition = getConditionFromCode(weatherCode);
                const rainProb = data.daily?.precipitation_probability_max?.[0] ?? 0;

                const recommendation = getWeatherRecommendation(condition, rainProb, wind);

                weatherData = {
                    temp: temp,
                    condition: condition,
                    rain: rainProb,
                    humidity: humidity,
                    wind: wind,
                    recommendation: recommendation
                };

                updateWeatherUI(weatherData);
                console.log(`🌤️ Weather updated: ${temp}°C, ${condition}, Humidity: ${humidity}%, Rain: ${rainProb}%, Wind: ${wind} km/h`);
            })
            .catch(error => {
                console.error('Weather fetch error:', error);
                showWeatherPlaceholder('Could not fetch weather data. Please try again later.');
            });
    }

    // ----- 8. GET LOCATION VIA HTML5 GEOLOCATION -----
    function getLocationViaGeolocation() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                // Success
                function(position) {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    console.log(`📍 Location found via GPS: ${lat}, ${lon}`);
                    fetchWeatherFromOpenMeteo(lat, lon);
                },
                // Failure (user denied or error)
                function(error) {
                    console.log('Geolocation failed, falling back to IP:', error.message);
                    getLocationViaIP();
                },
                // Options
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 60000
                }
            );
        } else {
            console.log('Geolocation not supported, using IP fallback');
            getLocationViaIP();
        }
    }

    // ----- 9. GET LOCATION VIA IP (FALLBACK) -----
    function getLocationViaIP() {
        // Try ipapi.co first (free, no API key)
        fetch('https://ipapi.co/json/')
            .then(response => {
                if (!response.ok) throw new Error('IP API failed');
                return response.json();
            })
            .then(data => {
                const lat = data.latitude;
                const lon = data.longitude;
                if (lat && lon) {
                    console.log(`📍 Location found via IP: ${data.city}, ${data.country_name} (${lat}, ${lon})`);
                    fetchWeatherFromOpenMeteo(lat, lon);
                } else {
                    throw new Error('No coordinates from IP');
                }
            })
            .catch(error => {
                console.log('IP API failed, trying fallback...');
                // Fallback to ip-api.com
                fetch('https://ip-api.com/json/')
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            const lat = data.lat;
                            const lon = data.lon;
                            console.log(`📍 Location found via IP fallback: ${data.city}, ${data.country} (${lat}, ${lon})`);
                            fetchWeatherFromOpenMeteo(lat, lon);
                        } else {
                            // Final fallback: Default to Addis Ababa
                            console.log('All location methods failed, using default (Addis Ababa)');
                            fetchWeatherFromOpenMeteo(9.03, 38.74);
                            showWeatherPlaceholder('Using default location (Addis Ababa). Please allow location access for accurate weather.');
                        }
                    })
                    .catch(() => {
                        // Ultimate fallback
                        console.log('All fallbacks failed, using Addis Ababa');
                        fetchWeatherFromOpenMeteo(9.03, 38.74);
                        showWeatherPlaceholder('Using default location (Addis Ababa). Please allow location access for accurate weather.');
                    });
            });
    }

    // ----- 10. START WEATHER FETCHING -----
    function initWeather() {
        console.log('🌤️ Starting weather fetch...');
        getLocationViaGeolocation();
    }

    // ----- 11. NAVIGATION ITEMS (click handlers) -----
    document.querySelectorAll('.nav-items a').forEach(link => {
    link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        
        // If it's a real link (not "#"), let the browser navigate
        if (href && href !== '#') {
            return;  // Do nothing, let the browser follow the link
        }
        
        e.preventDefault();
        document.querySelectorAll('.nav-items a').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
        const section = this.textContent.trim();
        alert(`📌 ${section}\n\nThis feature is currently being built.\n\nAgriNova will provide real agricultural content here when connected to reliable data sources.`);
    });
});
    // ----- 12. CARD CLICK HANDLERS -----

    // Weather Card
    document.getElementById('weatherCard').addEventListener('click', function() {
        alert(
            `🌤️ Weather Information\n\nCurrent conditions:\n• Temperature: ${weatherData.temp}°C\n• Condition: ${conditionNames[weatherData.condition] || weatherData.condition}\n• Rain probability: ${weatherData.rain}%\n• Humidity: ${weatherData.humidity}%\n• Wind: ${weatherData.wind} km/h\n\n📋 Recommendation: ${weatherData.recommendation}`
        );
    });

    // Articles Card
    document.getElementById('articlesCard').addEventListener('click', function(e) {
        if (e.target.tagName === 'BUTTON') return;
        alert(
            '📚 Agriculture Articles\n\nAgricultural articles will appear here.\n\nWe are building a library of practical farming knowledge, agricultural techniques, and research-based information for Ethiopian farmers and agricultural enthusiasts.'
        );
    });
    document.getElementById('articlesBtn').addEventListener('click', function(e) {
        e.stopPropagation();
        alert(
            '📚 Agriculture Articles\n\nOpening articles section...\n\nThis feature is currently under development.\n\nComing soon: Practical farming guides, crop management information, agricultural research, and sustainable farming practices for Ethiopian agriculture.'
        );
    });

    // Fertilizers Card
    document.getElementById('fertilizersCard').addEventListener('click', function(e) {
        if (e.target.tagName === 'BUTTON') return;
        alert(
            '🧪 Fertilizers\n\nFertilizer information will appear here.\n\nWe are developing a comprehensive fertilizer guide with information about types, nutrients, crop suitability, and responsible application for Ethiopian agriculture.'
        );
    });
    document.getElementById('fertilizersBtn').addEventListener('click', function(e) {
        e.stopPropagation();
        alert(
            '🧪 Fertilizer Information\n\nOpening fertilizers section...\n\nThis feature is currently under development.\n\nComing soon: Fertilizer types, nutrient content, application timing, crop suitability, and agricultural best practices.'
        );
    });

    // News Card
    document.getElementById('newsCard').addEventListener('click', function(e) {
        if (e.target.tagName === 'BUTTON') return;
        alert(
            '📰 Agriculture News\n\nAgricultural news will appear here.\n\nWe are working to bring you important agricultural developments, research findings, technology updates, climate information, and government programs affecting Ethiopian agriculture.'
        );
    });
    document.getElementById('newsBtn').addEventListener('click', function(e) {
        e.stopPropagation();
        alert(
            '📰 Agriculture News\n\nOpening news section...\n\nThis feature is currently under development.\n\nComing soon: Latest agricultural news, technology updates, research developments, and important farming information for Ethiopia.'
        );
    });

    // Simulation Card
    document.getElementById('simulationCard').addEventListener('click', function(e) {
        if (e.target.tagName === 'BUTTON') return;
        alert(
            '🎮 Farm Simulation\n\nThe Farm Simulator is currently under development.\n\nComing soon: An interactive virtual farm where you can plant crops, care for them, manage your farm, and experience agricultural production.'
        );
    });
    document.getElementById('simulationBtn').addEventListener('click', function(e) {
        e.stopPropagation();
        alert(
            '🎮 Farm Simulation\n\nLoading farm simulator...\n\nThis feature is currently under development.\n\nComing soon: Interactive virtual farming experience with crop planting, management, and harvesting activities.'
        );
    });

    // ----- 13. INITIALIZE ON PAGE LOAD -----
    document.addEventListener('DOMContentLoaded', function() {
        console.log('🌾 AgriNova Visitor Dashboard loaded successfully.');
        console.log('ℹ️  Weather feature: HTML5 Geolocation → IP Fallback → Open-Meteo API');
        initWeather();
    });

})();