// ===== PEST & DISEASE LIBRARY — JAVASCRIPT =====
// Data sourced from CABI, CIMMYT, FAO, and verified agricultural sources

(function() {

    // ----- 1. DATA (50 entries from your dataset) -----
    const entries = [
        {
            id: "PD001",
            name: "Maize Lethal Necrosis Disease",
            localName: "",
            scientific: "Co-infection of Maize chlorotic mottle virus (MCMV) and Sugarcane mosaic virus (SCMV)",
            type: "disease",
            affectedCrops: ["Maize"],
            partsAffected: ["Leaf", "Stem", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Maize Lethal Necrosis (MLN) is a devastating viral disease complex caused by co-infection of Maize chlorotic mottle virus and Sugarcane mosaic virus. The disease causes severe yield losses and can lead to complete crop failure in susceptible maize varieties.",
            symptoms: "Early: Chlorotic mottling on leaves, mild stunting, yellowing of young leaves. Advanced: Severe leaf necrosis from leaf margins inward, premature plant death, poor or no cob formation, small deformed cobs with few kernels, complete plant collapse.",
            favorableConditions: "Warm temperatures (25-30°C), high vector insect populations (thrips and aphids), presence of alternative hosts, continuous maize cropping, overlapping maize growing seasons.",
            prevention: "Use certified disease-free seed, plant resistant/tolerant maize varieties, avoid continuous maize cropping, control insect vectors, remove volunteer maize plants.",
            culturalManagement: "Crop rotation with non-cereal crops, rogue out and destroy infected plants, synchronize planting dates to avoid vector build-up, maintain field sanitation, remove alternative weed hosts.",
            biologicalManagement: "Control insect vectors (thrips and aphids) using natural enemies, conserve beneficial insects that prey on vectors.",
            chemicalManagement: "No verified chemical management information available for the viral complex; insecticide application for vector management only.",
            ethiopianDistribution: "Oromia — Confirmed presence; SNNPR — Confirmed presence; Amhara — Reported presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Severe yield losses reported up to 100% in susceptible varieties, major threat to maize-based food systems and smallholder livelihoods.",
            detailedDescription: "Maize Lethal Necrosis (MLN) is a devastating viral disease complex that results from the synergistic co-infection of Maize chlorotic mottle virus (MCMV) and Sugarcane mosaic virus (SCMV), or other potyviruses. When these two viruses infect a maize plant simultaneously, they interact in a way that produces symptoms far more severe than either virus alone, often leading to complete crop failure. The disease was first confirmed in Ethiopia in 2014 and has since spread to major maize-growing regions, posing a serious threat to food security and the livelihoods of millions of smallholder farmers who depend on maize as their primary staple crop. The disease affects maize at all growth stages, but infections during early vegetative stages typically result in the most severe losses, including complete plant death and total yield loss. MLN is particularly dangerous because both viruses are transmitted by common insect vectors — MCMV by thrips and SCMV by aphids — which can spread the disease rapidly within and between fields. The presence of alternative weed hosts and continuous maize cropping patterns in Ethiopia creates favorable conditions for disease persistence and spread, making management challenging and requiring integrated approaches that combine resistant varieties, vector control, and cultural practices.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20lethal%20necrosis.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20lethal%20necrosis.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20lethal%20necrosis.jpg",
            source: "CIMMYT (International Maize and Wheat Improvement Center)",
            sourceUrl: "https://www.cimmyt.org/projects/mln/",
            pubDate: "2018",
            lastUpdated: "2021",
            notes: "MLN is caused by synergistic interaction between MCMV and SCMV; first confirmed in Ethiopia in 2014."
        },
        {
            id: "PD002",
            name: "Wheat Stem Rust",
            localName: "",
            scientific: "Puccinia graminis f. sp. tritici",
            type: "disease",
            affectedCrops: ["Wheat", "Barley"],
            partsAffected: ["Stem", "Leaf"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Wheat stem rust is a fungal disease caused by Puccinia graminis f. sp. tritici that attacks stems, leaves, and leaf sheaths of wheat and barley. The disease can cause severe yield losses, particularly when susceptible varieties are grown under favorable conditions.",
            symptoms: "Early: Small reddish-brown pustules on stems and leaf sheaths, elongated rust-colored lesions. Advanced: Large reddish-brown to black pustules breaking through epidermis, weakened stems leading to lodging, shriveled grains, severe yield reduction, black teliospores at maturity.",
            favorableConditions: "Warm temperatures (15-30°C), high humidity, free moisture on plant surfaces, susceptible wheat varieties, presence of barberry alternate host.",
            prevention: "Plant resistant varieties, use certified seed, monitor fields regularly, remove barberry plants near wheat fields.",
            culturalManagement: "Early planting, avoid excessive nitrogen fertilization, practice crop rotation, remove volunteer wheat plants, proper field drainage.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Tebuconazole, Propiconazole, Epoxiconazole, Triadimefon (applied at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Confirmed presence; SNNPR — Confirmed presence.",
            economicImpact: "Yield losses can reach 70-100% in susceptible varieties during epidemic years, significant threat to wheat production.",
            detailedDescription: "Wheat stem rust, caused by the fungal pathogen Puccinia graminis f. sp. tritici, is one of the most feared diseases of wheat globally and has caused devastating epidemics throughout agricultural history. The disease attacks the stems, leaf sheaths, and leaves of wheat and barley plants, producing characteristic reddish-brown pustules that rupture the plant epidermis and release millions of spores capable of wind-borne dispersal over vast distances. What makes stem rust particularly dangerous is its ability to cause complete crop loss in susceptible varieties within a matter of weeks under favorable conditions. The emergence of the Ug99 race group, first identified in Uganda in 1998 (and subsequently found in several African and Middle Eastern countries), has raised global alarm because it overcomes many of the resistance genes that have protected wheat crops for decades. Ethiopia, as one of Africa's largest wheat producers, faces significant risk from stem rust, particularly in the highland wheat-growing areas where environmental conditions often favor disease development. The presence of barberry (the alternate host) in some regions adds complexity to disease management, as it allows for sexual recombination and the emergence of new virulent races.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stem%20rust%20close%20up.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stem%20rust%20close%20up.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stem%20rust%20close%20up.jpg",
            source: "USDA-ARS Cereal Disease Laboratory",
            sourceUrl: "https://www.ars.usda.gov/midwest-area/stpaul/cereal-disease-lab/",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Ug99 race group first identified in Uganda in 1998, poses serious threat to global wheat production."
        },
        {
            id: "PD003",
            name: "Wheat Yellow Rust",
            localName: "",
            scientific: "Puccinia striiformis f. sp. tritici",
            type: "disease",
            affectedCrops: ["Wheat"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Wheat yellow rust (stripe rust) is a fungal disease caused by Puccinia striiformis f. sp. tritici. It appears as yellow-orange stripes on leaves and can cause substantial yield losses in susceptible wheat varieties.",
            symptoms: "Early: Small yellow-orange pustules arranged in stripes on leaves, chlorotic flecks. Advanced: Distinct yellow stripes along leaf veins, severe leaf chlorosis and necrosis, reduced photosynthesis, stunted growth, poor grain filling, shriveled grains.",
            favorableConditions: "Cool temperatures (10-20°C), high humidity, prolonged leaf wetness, susceptible wheat varieties, high nitrogen fertilization.",
            prevention: "Plant resistant varieties, use certified disease-free seed, avoid excessive nitrogen application, monitor fields early in season.",
            culturalManagement: "Crop rotation, adjust planting dates to avoid favorable conditions, remove volunteer wheat and grass weeds, balanced fertilization.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Tebuconazole, Propiconazole, Cyproconazole, Azoxystrobin (applied preventatively or at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence; SNNPR — Confirmed presence.",
            economicImpact: "Yield losses of 10-70% reported depending on variety susceptibility and environmental conditions, major constraint to wheat production in highlands.",
            detailedDescription: "Wheat yellow rust, also known as stripe rust, is caused by the fungal pathogen Puccinia striiformis f. sp. tritici and is characterized by distinctive yellow-orange pustules arranged in stripes along wheat leaf veins. The disease is particularly adapted to cool, humid conditions, making it a major threat to wheat production in highland areas of Ethiopia where these environmental conditions prevail during much of the growing season. Yellow rust reduces photosynthetic capacity, leading to poor grain filling, shriveled kernels, and significant yield losses ranging from 10% to 70% in susceptible varieties. The pathogen has a remarkable ability to evolve new virulent races, and Ethiopia has experienced several yellow rust epidemics in recent decades as new races have overcome resistance in previously resistant varieties. The high genetic variability of the pathogen population in Ethiopia, combined with the presence of susceptible wheat varieties and favorable environmental conditions, makes yellow rust one of the most economically important wheat diseases in the country. Effective management requires continuous breeding efforts to develop resistant varieties, along with strategic fungicide application and cultural practices that reduce disease pressure.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stripe%20rust%20on%20wheat.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stripe%20rust%20on%20wheat.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stripe%20rust%20on%20wheat.jpg",
            source: "CIMMYT (International Maize and Wheat Improvement Center)",
            sourceUrl: "https://www.cimmyt.org/research/wheat/",
            pubDate: "2018",
            lastUpdated: "2021",
            notes: "High genetic variability in pathogen population; new virulent races emerging regularly in Ethiopia."
        },
        {
            id: "PD004",
            name: "Barley Scald",
            localName: "",
            scientific: "Rhynchosporium secalis",
            type: "disease",
            affectedCrops: ["Barley"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Barley scald is a fungal disease caused by Rhynchosporium secalis that affects barley leaves and leaf sheaths. It is one of the most economically important diseases of barley in cool, humid highland regions.",
            symptoms: "Early: Water-soaked grayish-green spots on leaves, small oval lesions. Advanced: Well-defined oval lesions with dark brown margins and pale gray centers, lesions coalesce forming large necrotic areas, leaf death, reduced grain size, premature senescence.",
            favorableConditions: "Cool temperatures (15-20°C), high relative humidity, frequent rainfall, dense crop canopy, susceptible barley varieties.",
            prevention: "Use certified disease-free seed, plant resistant varieties, practice crop rotation, avoid excessive plant density.",
            culturalManagement: "Crop rotation with non-host crops (2-3 years), remove and destroy crop residues, control volunteer barley, maintain proper spacing for air circulation, balanced fertilization.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Propiconazole, Tebuconazole, Chlorothalonil (applied at early disease onset or preventatively).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 20-40% reported in susceptible varieties under favorable conditions, significant impact on food barley production.",
            detailedDescription: "Barley scald, caused by the fungal pathogen Rhynchosporium secalis (also known as Rhynchosporium commune), is one of the most economically important diseases of barley worldwide, particularly in cool, humid growing regions. The disease produces distinctive oval lesions with dark brown margins and pale gray centers on leaves and leaf sheaths, which reduce photosynthetic area and can lead to significant yield losses of 20-40% in susceptible varieties. Scald is especially damaging to malt barley production because it affects grain quality parameters such as kernel plumpness and protein content, which are critical for brewing quality. In Ethiopia, barley is both a food security crop (used for traditional foods like injera and local beverages) and an increasingly important cash crop for the malting industry, making scald management crucial for both food security and farmer incomes. The pathogen survives on crop residues and infected seed, and spreads through rain-splash and wind-blown spores, which makes disease management challenging in smallholder farming systems where crop rotation and residue management may be limited.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20scald.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20scald.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20scald.jpg",
            source: "Department of Primary Industries and Regional Development, Western Australia",
            sourceUrl: "https://www.agric.wa.gov.au/barley/barley-scald",
            pubDate: "2020",
            lastUpdated: "2022",
            notes: "Pathogen can survive on crop residues for up to one year; seed transmission possible."
        },
        {
            id: "PD005",
            name: "Tef Rust",
            localName: "",
            scientific: "Uromyces eragrostidis",
            type: "disease",
            affectedCrops: ["Tef"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Tef rust is a fungal disease caused by Uromyces eragrostidis that affects tef (Eragrostis tef), Ethiopia's most important cereal crop. The disease appears as reddish-brown pustules on leaves and stems, reducing photosynthetic capacity and causing premature senescence.",
            symptoms: "Early: Small chlorotic spots on leaves, developing into reddish-brown pustules. Advanced: Numerous rust pustules covering leaves and stems, leaf yellowing and necrosis, premature leaf death, reduced grain filling, stunted growth in severe infections.",
            favorableConditions: "Warm temperatures (20-28°C), high humidity, prolonged leaf wetness, dense crop canopy, susceptible tef varieties.",
            prevention: "Plant resistant varieties, use clean seed, avoid dense planting, monitor fields regularly for early detection.",
            culturalManagement: "Crop rotation, proper spacing for air circulation, avoid excessive nitrogen application, remove volunteer tef plants, field sanitation.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Propiconazole, Tebuconazole (applied at early disease onset, contact local agricultural authorities for registered products).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 10-30% reported, significant impact on staple food production and smallholder livelihoods.",
            detailedDescription: "Tef rust, caused by the fungal pathogen Uromyces eragrostidis, is a significant disease affecting tef (Eragrostis tef), which is Ethiopia's most important cereal crop both in terms of area cultivated and dietary importance for over 50 million people. The disease produces reddish-brown pustules on leaves and stems that reduce photosynthetic capacity, cause premature senescence, and can result in yield losses of 10-30% in susceptible varieties. Given tef's central role in Ethiopian food culture and the fact that Ethiopia is the world's only major producer of tef, any disease that affects tef production has direct implications for national food security. The disease is favored by warm, humid conditions and dense crop canopies, which are common in major tef-growing areas during the main growing season. While tef has historically shown relatively good tolerance to many diseases compared to other cereals, rust can be problematic in years with favorable environmental conditions, particularly when susceptible varieties are grown. Management focuses on resistant varieties, cultural practices that reduce humidity in the crop canopy, and targeted fungicide application in high-value seed production fields.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Eragrostis%20tef.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Eragrostis%20tef.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Eragrostis%20tef.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/55926",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Tef is endemic to Ethiopia and is the primary staple crop for over 50 million people."
        },
        {
            id: "PD006",
            name: "Late Blight of Potato",
            localName: "",
            scientific: "Phytophthora infestans",
            type: "disease",
            affectedCrops: ["Potato", "Tomato"],
            partsAffected: ["Leaf", "Stem", "Fruit", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Late blight is a devastating disease caused by the oomycete pathogen Phytophthora infestans. It affects potato and tomato, causing rapid foliage destruction and tuber/fruit rot. The disease can spread extremely quickly under favorable conditions.",
            symptoms: "Early: Water-soaked irregular spots on leaves, pale green to brown lesions, white downy growth on lesion undersides in humid conditions. Advanced: Dark brown to black necrotic lesions, rapid leaf death and stem collapse, characteristic odor, brown discoloration of tubers, firm brown rot extending into tuber flesh.",
            favorableConditions: "Cool temperatures (10-25°C), high relative humidity (>90%), prolonged leaf wetness, foggy or rainy weather, dense canopy, susceptible varieties.",
            prevention: "Plant resistant varieties, use certified disease-free seed tubers, avoid overhead irrigation, space plants properly for air circulation.",
            culturalManagement: "Hilling to protect tubers, remove and destroy infected plants, harvest during dry conditions, avoid bruising tubers at harvest, proper storage ventilation, remove volunteer plants.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, Bacillus subtilis (limited efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Mancozeb, Chlorothalonil, Metalaxyl, Cymoxanil, Propamocarb (rotation recommended to prevent resistance).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; SNNPR — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 50-100% in susceptible varieties during epidemic years, major threat to potato production.",
            detailedDescription: "Late blight, caused by the oomycete pathogen Phytophthora infestans, is the most destructive disease of potato worldwide and was responsible for the Irish Potato Famine of the 1840s. The disease attacks leaves, stems, and tubers, causing rapid foliage destruction and tuber rot under favorable conditions of cool temperatures (10-25°C) and high humidity. In Ethiopia, late blight is the primary constraint to potato production, causing losses of 50-100% in susceptible varieties during epidemic years. The pathogen is particularly aggressive, capable of destroying an entire field within 1-2 weeks under optimal conditions. What makes late blight especially challenging is the pathogen's ability to rapidly evolve new strains that overcome host resistance, requiring continuous breeding efforts to develop resistant varieties. The disease is most severe during rainy seasons in highland potato-growing areas, where prolonged leaf wetness favors infection and spread. Smallholder farmers are particularly vulnerable because they often lack access to resistant varieties and cannot afford repeated fungicide applications, leading to complete crop loss in severe years and contributing to food insecurity in potato-dependent communities.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potato%20Late%20Blight.JPG",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potato%20Late%20Blight.JPG",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potato%20Late%20Blight.JPG",
            source: "International Potato Center (CIP)",
            sourceUrl: "https://cipotato.org/potato/late-blight/",
            pubDate: "2020",
            lastUpdated: "2022",
            notes: "Caused by oomycete (water mold), not a true fungus; capable of rapid evolution and overcoming resistance genes."
        },
        {
            id: "PD007",
            name: "Bacterial Wilt of Potato",
            localName: "",
            scientific: "Ralstonia solanacearum",
            type: "disease",
            affectedCrops: ["Potato", "Tomato", "Pepper"],
            partsAffected: ["Stem", "Root", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Bacterial wilt is caused by the soil-borne bacterium Ralstonia solanacearum. The disease affects the vascular system of plants, causing rapid wilting and death. It is particularly severe in warm, humid conditions and can persist in soil for many years.",
            symptoms: "Early: Wilting of young leaves during hot periods, recovery at night, yellowing of lower leaves. Advanced: Permanent wilting of entire plant, brown discoloration of vascular tissue, bacterial ooze from cut stems, stem rot, brown rings in tubers, complete plant death.",
            favorableConditions: "Warm temperatures (25-35°C), high soil moisture, acidic soils (pH 5-6.5), presence of nematodes, continuous cropping of susceptible hosts.",
            prevention: "Plant resistant varieties, use certified disease-free planting material, rotate with non-host crops, avoid planting in infested fields.",
            culturalManagement: "Crop rotation with cereals (3-5 years), remove and destroy infected plants, improve soil drainage, maintain balanced soil pH, control nematode populations, field sanitation of tools.",
            biologicalManagement: "Biocontrol agents: Pseudomonas fluorescens, Bacillus species (limited field efficacy, research ongoing).",
            chemicalManagement: "No effective chemical control available; soil fumigation with Metam sodium (restricted use, not recommended for smallholders).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Reported presence; SNNPR — Confirmed presence.",
            economicImpact: "Yield losses of 30-100% reported in infested fields, severe impact on smallholder potato production.",
            detailedDescription: "Bacterial wilt, caused by the soil-borne bacterium Ralstonia solanacearum, is one of the most devastating diseases of potato and other solanaceous crops in tropical and subtropical regions. The pathogen enters through roots, colonizes the vascular system, and causes rapid wilting and death of infected plants. What makes bacterial wilt particularly challenging to manage is the pathogen's ability to survive in soil, water, and plant debris for many years, its extremely wide host range (over 200 plant species), and its capacity to spread through contaminated soil, water, and planting material. In Ethiopia, bacterial wilt causes significant losses in potato production, particularly in warmer growing areas where soil temperatures favor pathogen activity. The disease is especially problematic for smallholder farmers because once a field becomes infested, it remains infested for years, and there is no effective chemical control available. Infected tubers may show no symptoms at harvest but develop brown rings and rot during storage, contributing to post-harvest losses. Management requires an integrated approach combining resistant varieties, certified disease-free seed, long crop rotations with non-host crops, and strict field sanitation practices.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Bacterial%20wilt%20of%20potato.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Bacterial%20wilt%20of%20potato.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Bacterial%20wilt%20of%20potato.jpg",
            source: "International Potato Center (CIP)",
            sourceUrl: "https://cipotato.org/potato/diseases/bacterial-wilt/",
            pubDate: "2020",
            lastUpdated: "2022",
            notes: "Pathogen has extremely wide host range (>200 plant species); can survive in water and soil for years."
        },
        {
            id: "PD008",
            name: "Fusarium Wilt of Banana",
            localName: "",
            scientific: "Fusarium oxysporum f. sp. cubense",
            type: "disease",
            affectedCrops: ["Banana", "Enset"],
            partsAffected: ["Root", "Stem", "Leaf", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Fusarium wilt (Panama disease) is a soil-borne fungal disease caused by Fusarium oxysporum f. sp. cubense. The pathogen enters through roots and colonizes the vascular system, causing yellowing, wilting, and death of banana plants.",
            symptoms: "Early: Yellowing of older leaves progressing upward, leaf margin necrosis, wilting during hot periods. Advanced: Brown discoloration of vascular tissue (visible in pseudostem cross-section), splitting of pseudostem base, complete leaf collapse, plant death, internal rhizome discoloration.",
            favorableConditions: "Warm temperatures (25-32°C), acidic soils, poor drainage, presence of nematodes, movement of infested soil and planting material.",
            prevention: "Use disease-free planting material, avoid moving soil from infested areas, quarantine infested fields, plant resistant varieties where available.",
            culturalManagement: "Improve soil drainage, maintain soil pH, avoid root damage during cultivation, remove and destroy infected plants (including roots), prevent spread of infested soil on tools and machinery.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, non-pathogenic Fusarium (limited field efficacy, research ongoing).",
            chemicalManagement: "No effective chemical control available; soil fumigation not economically feasible for smallholders.",
            ethiopianDistribution: "Not confirmed in Ethiopia from verified source; enset bacterial wilt is a separate disease.",
            economicImpact: "Potential catastrophic losses if TR4 introduced; current impact limited to susceptible varieties.",
            detailedDescription: "Fusarium wilt of banana, also known as Panama disease, is caused by the soil-borne fungus Fusarium oxysporum f. sp. cubense and is considered one of the most destructive diseases in agricultural history. The pathogen enters through the roots, colonizes the vascular system, and causes yellowing, wilting, and eventual death of banana plants. The disease gained international attention in the 1950s when it destroyed the global export banana industry based on the 'Gros Michel' variety, forcing a switch to 'Cavendish' varieties. A new strain, Tropical Race 4 (TR4), emerged in the 1990s and threatens the current Cavendish-based industry because it overcomes the resistance that Cavendish varieties possess. While TR4 has not yet been confirmed in Ethiopia, the presence of other races and the disease's presence in neighboring countries raises concerns about future introduction. The pathogen survives in soil for decades, making infested fields permanently unsuitable for susceptible banana varieties. In Ethiopia, where banana and enset (a closely related crop) are important food and income sources in many regions, Fusarium wilt represents a serious potential threat. Management focuses on prevention through quarantine, use of disease-free planting material, and deployment of resistant varieties, as no effective chemical control exists.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Banana%20Fusarium%20Wilt%20Race%20TR4%20%2805410326%29%20%2851901906297%29.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Banana%20Fusarium%20Wilt%20Race%20TR4%20%2805410326%29%20%2851901906297%29.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Banana%20Fusarium%20Wilt%20Race%20TR4%20%2805410326%29%20%2851901906297%29.jpg",
            source: "Bioversity International",
            sourceUrl: "https://www.bioversityinternational.org/banana/fusarium-wilt/",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "TR4 strain not confirmed in Africa (as of 2021); Race 1 present in some African countries."
        },
        {
            id: "PD009",
            name: "Enset Bacterial Wilt",
            localName: "",
            scientific: "Xanthomonas campestris pv. musacearum",
            type: "disease",
            affectedCrops: ["Enset", "Banana"],
            partsAffected: ["Leaf", "Stem", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Enset bacterial wilt is a devastating bacterial disease caused by Xanthomonas campestris pv. musacearum. It affects enset (false banana), a staple food crop for over 20 million Ethiopians, and banana. The disease spreads rapidly and can cause complete crop loss.",
            symptoms: "Early: Yellowing and wilting of central leaves, bacterial ooze from cut pseudostem, leaf sheath discoloration. Advanced: Complete plant collapse, brownish-black discoloration of vascular tissue, rotten corm with foul odor, death of entire plant.",
            favorableConditions: "Warm temperatures (20-30°C), high rainfall, presence of insect vectors (especially foraging bees and flies), contaminated tools, movement of infected planting material.",
            prevention: "Use disease-free planting material, sterilize tools between plants, quarantine new planting material, control insect vectors where possible, avoid transplanting during rainy season.",
            culturalManagement: "Remove and destroy infected plants immediately, avoid using contaminated tools without disinfection, maintain field hygiene, rotate fields, use proper spacing to reduce spread.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "No effective chemical control available; focus on prevention and cultural management.",
            ethiopianDistribution: "SNNPR — Confirmed presence (Gurage, Sidama, Wolayta zones); Oromia — Confirmed presence; Amhara — Reported presence.",
            economicImpact: "Total crop loss reported in affected areas, severe threat to food security and cultural heritage of enset-growing communities.",
            detailedDescription: "Enset bacterial wilt, caused by the bacterium Xanthomonas campestris pv. musacearum (now reclassified as Xanthomonas vasicola pv. musacearum), is the most important disease threatening enset (Ensete ventricosum), a staple food crop for over 20 million people in southern and southwestern Ethiopia. Enset, often called 'false banana,' is unique to Ethiopia and is deeply embedded in the culture and food systems of the region, providing food, fiber, animal feed, and environmental services. The disease attacks the vascular system, causing leaf yellowing, wilting, and complete plant death, with entire fields being destroyed within weeks. First described in Ethiopia in 1968, the disease remained relatively contained for decades but has spread more aggressively in recent years, causing severe food insecurity in affected areas. The pathogen spreads through contaminated tools, infected planting material, and insect vectors, making it difficult to control once established. The disease also affects banana, which shares genetic similarity with enset, raising concerns about cross-infection between these important crops. Management is challenging and relies heavily on prevention through use of disease-free planting material, tool sterilization, removal and destruction of infected plants, and community-level coordinated action to prevent spread.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Enset%20bacterial%20wilt.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Enset%20bacterial%20wilt.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Enset%20bacterial%20wilt.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56849",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "First reported in Ethiopia in 1968; has since spread to Uganda, Kenya, Tanzania, and other East African countries."
        },
        {
            id: "PD010",
            name: "Coffee Berry Disease",
            localName: "",
            scientific: "Colletotrichum kahawae",
            type: "disease",
            affectedCrops: ["Coffee"],
            partsAffected: ["Fruit"],
            growthStage: ["Flowering", "Fruiting"],
            description: "Coffee Berry Disease (CBD) is a fungal disease caused by Colletotrichum kahawae that specifically affects Coffea arabica. The disease attacks developing coffee berries, causing them to rot and drop prematurely.",
            symptoms: "Early: Small sunken dark spots on green berries, lesions enlarge and darken. Advanced: Black sunken lesions covering entire berry, premature berry drop, mummified berries remaining on branches, branches dieback, severe yield loss, quality deterioration of remaining crop.",
            favorableConditions: "Cool temperatures (18-22°C), high rainfall (>1200mm annually), high humidity, altitude 1500-2200m, susceptible coffee varieties, dense shade.",
            prevention: "Plant resistant varieties, maintain proper spacing, prune to improve air circulation, avoid excessive shade.",
            culturalManagement: "Regular pruning and desuckering, remove and destroy infected berries and branches, maintain balanced shade, proper harvesting of all berries (including diseased), crop sanitation.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, Bacillus subtilis (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Copper-based fungicides, Azoxystrobin, Chlorothalonil (timing critical, apply at flowering and early fruit development).",
            ethiopianDistribution: "Oromia — Confirmed presence (Jimma, Illubabor, West Wollega zones); SNNPR — Confirmed presence (Sidama, Gedeo zones); Gambella — Reported presence.",
            economicImpact: "Yield losses of 20-80% in susceptible varieties under favorable conditions, major threat to Ethiopia's coffee industry.",
            detailedDescription: "Coffee Berry Disease (CBD), caused by the fungal pathogen Colletotrichum kahawae, is the most economically important disease of Arabica coffee in Africa and is endemic to the continent. The disease specifically attacks developing coffee berries, causing dark sunken lesions that lead to premature berry drop and significant yield losses of 20-80% in susceptible varieties under favorable conditions. Ethiopia, as the center of origin and genetic diversity for Arabica coffee, faces unique challenges and opportunities in managing CBD. On one hand, the rich genetic diversity of wild and cultivated coffee in Ethiopia provides valuable resources for breeding resistant varieties; on the other hand, the disease is well-adapted to Ethiopian coffee-growing conditions and can be devastating in epidemic years. CBD is favored by cool temperatures, high rainfall, and altitudes between 1500-2200 meters, which correspond to the optimal coffee-growing zones in Ethiopia. The disease is particularly severe in forest coffee systems where humidity is high and air circulation is limited. Management combines resistant varieties, cultural practices that reduce humidity, and strategic fungicide application, though smallholder farmers often struggle to implement chemical control due to cost constraints.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Coffee%20berry%20disease.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Coffee%20berry%20disease.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Coffee%20berry%20disease.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/15253",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Ethiopia is the center of genetic diversity for Arabica coffee; CBD resistance is a major breeding priority."
        },
        {
            id: "PD011",
            name: "Coffee Leaf Rust",
            localName: "",
            scientific: "Hemileia vastatrix",
            type: "disease",
            affectedCrops: ["Coffee"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Coffee leaf rust is a fungal disease caused by Hemileia vastatrix that affects coffee leaves, causing defoliation and reduced photosynthesis. The disease is present in most coffee-growing regions worldwide and can cause severe yield losses.",
            symptoms: "Early: Small yellow-orange powdery spots on leaf undersides, chlorotic patches on upper leaf surface. Advanced: Orange powdery pustules covering leaf undersides, leaves turn brown and drop prematurely, severe defoliation, branch dieback, reduced berry development, poor bean quality, weakened plants.",
            favorableConditions: "Warm temperatures (21-28°C), high relative humidity, prolonged leaf wetness, dense shade, susceptible coffee varieties, high rainfall.",
            prevention: "Plant resistant varieties, maintain proper spacing, prune to improve air circulation, monitor fields regularly.",
            culturalManagement: "Regular pruning, maintain balanced shade (avoid excessive shade), proper harvesting and processing, remove severely infected branches, balanced fertilization.",
            biologicalManagement: "Biocontrol agents: Lecanicillium lecanii, Trichoderma species (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Copper-based fungicides, Triazole fungicides, Strobilurin fungicides (rotate to prevent resistance).",
            ethiopianDistribution: "Oromia — Confirmed presence; SNNPR — Confirmed presence; Gambella — Reported presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 30-70% reported in susceptible varieties during epidemic years, significant economic impact on coffee production.",
            detailedDescription: "Coffee leaf rust, caused by the fungal pathogen Hemileia vastatrix, is the most widely distributed and economically significant disease of coffee globally. The disease attacks coffee leaves, producing characteristic orange powdery pustules on the leaf undersides that lead to premature defoliation, weakened trees, and significant yield losses of 30-70% in susceptible varieties. Coffee leaf rust has shaped the history of coffee production, destroying industries in Asia in the 19th century and continuing to cause major losses in Latin America, Africa, and Asia. Ethiopia, as the center of origin for Arabica coffee, has a complex relationship with coffee leaf rust. The disease is present in Ethiopia, but the high genetic diversity of coffee populations provides natural resistance and has historically moderated its impact compared to other coffee-growing regions. However, climate change and the expansion of coffee production into new areas may alter this dynamic. The conservation of Ethiopia's coffee genetic resources is critically important not only for the country's coffee industry but for global coffee production, as these genetic resources are essential for breeding resistance to rust and other diseases. Management focuses on resistant varieties, cultural practices that reduce humidity, and fungicide application in high-value production systems.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Hemileia%20vastatrix%20-%20coffee%20leaf%20rust.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Hemileia%20vastatrix%20-%20coffee%20leaf%20rust.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Hemileia%20vastatrix%20-%20coffee%20leaf%20rust.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/27144",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Ethiopia's coffee genetic diversity provides natural resistance; conservation of wild coffee populations is critical."
        },
        {
            id: "PD012",
            name: "Maize Gray Leaf Spot",
            localName: "",
            scientific: "Cercospora zeae-maydis",
            type: "disease",
            affectedCrops: ["Maize"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Gray leaf spot is a fungal disease caused by Cercospora zeae-maydis that affects maize leaves. The disease reduces photosynthetic area and can cause significant yield losses, particularly in continuous maize cropping systems with high residue levels.",
            symptoms: "Early: Small tan to brown rectangular spots on leaves, lesions with yellow halo. Advanced: Large gray to brown rectangular lesions, lesions coalesce forming large necrotic areas, leaf death, premature senescence, reduced grain filling, stalk weakening.",
            favorableConditions: "Warm temperatures (25-32°C), high humidity, prolonged leaf wetness, continuous maize cropping, high crop residue levels, susceptible varieties.",
            prevention: "Plant resistant varieties, practice crop rotation, remove or incorporate crop residues, avoid continuous maize cropping.",
            culturalManagement: "Crop rotation with legumes or other non-host crops (2-3 years), remove and destroy crop residues, balanced fertilization, proper spacing for air circulation.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Azoxystrobin, Propiconazole, Tebuconazole (applied at early disease onset, economics may not favor smallholder use).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 20-60% reported in susceptible varieties under favorable conditions, significant in continuous maize systems.",
            detailedDescription: "Gray leaf spot, caused by the fungal pathogen Cercospora zeae-maydis, has emerged as one of the most important diseases of maize in Ethiopia and globally, particularly in areas where maize is grown continuously and crop residues remain on the soil surface. The disease produces characteristic rectangular gray to brown lesions on leaves that reduce photosynthetic area and can cause yield losses of 20-60% in susceptible varieties. What makes gray leaf spot particularly challenging is the pathogen's ability to survive in crop residues, which means that reduced tillage and continuous maize cropping — practices that are increasingly common in Ethiopia — can increase disease pressure over time. The disease is favored by warm, humid conditions and is most severe in high-rainfall maize-growing areas. In Ethiopia, the intensification of maize production to meet growing food demand has created conditions that favor gray leaf spot epidemics, particularly in the western highlands where rainfall is abundant. Management requires an integrated approach combining resistant varieties, crop rotation with non-host crops, and residue management, as fungicide application is often not economically feasible for smallholder farmers.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Disease%20Cycle%20Corn%20Grey%20Leaf%20Spot.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Disease%20Cycle%20Corn%20Grey%20Leaf%20Spot.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Disease%20Cycle%20Corn%20Grey%20Leaf%20Spot.jpg",
            source: "Corteva Agriscience (Pioneer)",
            sourceUrl: "https://www.pioneer.com/us/agronomy/gray_leaf_spot.html",
            pubDate: "2020",
            lastUpdated: "2021",
            notes: "Pathogen survives in crop residues; reduced tillage systems may increase disease pressure."
        },
        {
            id: "PD013",
            name: "Sorghum Anthracnose",
            localName: "",
            scientific: "Colletotrichum sublineolum",
            type: "disease",
            affectedCrops: ["Sorghum"],
            partsAffected: ["Leaf", "Stem", "Grain"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Sorghum anthracnose is a fungal disease caused by Colletotrichum sublineolum. It affects leaves, stems, and grains of sorghum, causing significant yield and quality losses.",
            symptoms: "Early: Small circular to elliptical spots on leaves, reddish-brown to tan centers with dark margins. Advanced: Lesions coalesce forming large necrotic areas, leaf death, stem lesions with black centers, grain infection causing quality loss, premature senescence, stunted growth.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, frequent rainfall, dense crop canopy, susceptible varieties, high nitrogen fertilization.",
            prevention: "Plant resistant varieties, practice crop rotation, use certified disease-free seed, avoid dense planting.",
            culturalManagement: "Crop rotation with non-host crops, remove and destroy crop residues, balanced fertilization (avoid excess nitrogen), proper spacing, weed management.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Azoxystrobin, Propiconazole, Mancozeb (applied at early disease onset, seed treatment with Thiram or Captan).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Reported presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported in susceptible varieties, significant impact on sorghum production for food and feed.",
            detailedDescription: "Sorghum anthracnose, caused by the fungal pathogen Colletotrichum sublineolum, is one of the most important diseases affecting sorghum in warm, humid growing regions. The disease attacks leaves, stems, and grains, producing characteristic lesions that reduce photosynthetic capacity and can cause yield losses of 20-50% in susceptible varieties. Sorghum is a critical food security crop in Ethiopia, particularly in semi-arid regions where it is better adapted to drought than maize or other cereals. The importance of sorghum anthracnose is increasing as climate change brings more variable rainfall patterns, creating conditions that can favor disease development in some areas. The disease is particularly problematic when susceptible varieties are grown in continuous cropping systems with high residue levels. Ethiopia's sorghum production spans diverse agro-ecologies, from lowland semi-arid areas to mid-altitude highlands, and the disease is present across these production zones. Management focuses on resistant varieties, crop rotation, and cultural practices that reduce disease pressure, with fungicide application reserved for high-value seed production or epidemic conditions.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Anthracnose%20on%20Sweet%20sorghum.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Anthracnose%20on%20Sweet%20sorghum.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Anthracnose%20on%20Sweet%20sorghum.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/14863",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Sorghum is an important food security crop in semi-arid regions of Ethiopia."
        },
        {
            id: "PD014",
            name: "Chickpea Ascochyta Blight",
            localName: "",
            scientific: "Ascochyta rabiei",
            type: "disease",
            affectedCrops: ["Chickpea"],
            partsAffected: ["Leaf", "Stem", "Seed/Grain"],
            growthStage: ["Seedling", "Vegetative", "Flowering", "Grain Filling"],
            description: "Ascochyta blight is a fungal disease caused by Ascochyta rabiei that affects chickpea crops. The disease can cause complete crop failure under favorable conditions and is a major constraint to chickpea production in Ethiopia.",
            symptoms: "Early: Small brown spots on leaves and stems, water-soaked lesions. Advanced: Large brown lesions with dark margins and concentric rings, stem breakage, leaf drop, pod lesions with seed infection, complete plant death, circular patches of dead plants in field.",
            favorableConditions: "Cool temperatures (15-25°C), high humidity, frequent rainfall, prolonged leaf wetness, dense canopy, susceptible varieties, infected seed.",
            prevention: "Use certified disease-free seed, plant resistant varieties, practice crop rotation, avoid dense planting.",
            culturalManagement: "Crop rotation with cereals (3-4 years), remove and destroy crop residues, proper spacing for air circulation, avoid overhead irrigation, field sanitation.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Seed treatment: Thiram, Mancozeb, Carbendazim; Foliar application: Chlorothalonil, Azoxystrobin, Propiconazole (applied preventatively and at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 50-100% reported in susceptible varieties during epidemic years, major constraint to chickpea production.",
            detailedDescription: "Ascochyta blight, caused by the fungal pathogen Ascochyta rabiei, is the most devastating disease of chickpea worldwide and a major constraint to chickpea production in Ethiopia, which is one of Africa's largest chickpea producers and exporters. The disease attacks all above-ground plant parts, producing characteristic brown lesions with concentric rings that can lead to complete crop failure under favorable conditions. Ascochyta blight is favored by cool, wet conditions and can spread explosively during rainy periods, with yield losses of 50-100% reported in susceptible varieties during epidemic years. The pathogen is seed-borne and can also survive on crop residues, making disease management challenging in smallholder farming systems where certified seed use and crop rotation may be limited. Ethiopia's chickpea production has expanded significantly in recent decades due to growing export demand, particularly for Kabuli types, which has increased the importance of disease management. The development and deployment of resistant varieties has been a major focus of Ethiopian agricultural research, with significant progress made through collaboration between EIAR and international research centers. Management integrates resistant varieties, certified seed, crop rotation, and targeted fungicide application.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Didymella%20rabiei%20%28Chickpea%20ascochyta%20blight%20fungus%29.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Didymella%20rabiei%20%28Chickpea%20ascochyta%20blight%20fungus%29.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Didymella%20rabiei%20%28Chickpea%20ascochyta%20blight%20fungus%29.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/7487",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Ethiopia is one of the largest chickpea producers in Africa; disease management is critical for export markets."
        },
        {
            id: "PD015",
            name: "Fusarium Head Blight of Wheat",
            localName: "",
            scientific: "Fusarium graminearum",
            type: "disease",
            affectedCrops: ["Wheat", "Barley"],
            partsAffected: ["Flower", "Seed/Grain"],
            growthStage: ["Flowering", "Grain Filling"],
            description: "Fusarium head blight (FHB), also known as scab, is a fungal disease caused by Fusarium graminearum and related species. The disease affects wheat and barley heads, causing yield losses and contamination with mycotoxins.",
            symptoms: "Early: Bleached spikelets on green heads, water-soaked appearance at base of spikelets. Advanced: Pinkish-orange fungal growth on glumes, complete bleaching of heads, shriveled and discolored grains (tombstones), mycotoxin contamination, poor germination of infected seed.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity during flowering, prolonged wet periods, maize-wheat rotation (increased inoculum), susceptible varieties.",
            prevention: "Plant resistant varieties, practice crop rotation (avoid maize before wheat), use certified disease-free seed.",
            culturalManagement: "Crop rotation with non-host crops, remove and incorporate crop residues (especially maize), avoid excessive nitrogen, harvest promptly at maturity, separate infected grains.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, Bacillus species (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Tebuconazole, Prothioconazole, Metconazole (applied at flowering, timing critical for efficacy).",
            ethiopianDistribution: "Oromia — Reported presence; Amhara — Reported presence.",
            economicImpact: "Yield losses of 10-40% reported, mycotoxin contamination poses serious health and trade risks.",
            detailedDescription: "Fusarium head blight (FHB), also known as scab, is caused by several Fusarium species, primarily Fusarium graminearum, and is one of the most serious diseases of wheat and barley globally due to both yield losses and mycotoxin contamination. The disease infects wheat heads during flowering, producing bleached spikelets and pinkish-orange fungal growth that reduces grain yield and quality. However, the most serious concern is the production of mycotoxins, particularly deoxynivalenol (DON), which pose significant health risks to humans and animals and can make grain unsuitable for consumption or sale. In Ethiopia, FHB is emerging as an important disease in wheat-growing areas, particularly where wheat follows maize in rotation (maize residues serve as inoculum sources) and where humid conditions occur during flowering. The health implications of mycotoxin contamination are particularly concerning in Ethiopia, where wheat is a staple food for millions of people and contaminated grain can have chronic health effects. Management requires an integrated approach combining resistant varieties, crop rotation that avoids wheat after maize, residue management, and fungicide application at flowering when economic thresholds are met.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Fusarium%20head%20blight%20of%20wheat.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Fusarium%20head%20blight%20of%20wheat.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Fusarium%20head%20blight%20of%20wheat.jpg",
            source: "USDA-ARS Cereal Disease Laboratory",
            sourceUrl: "https://www.ars.usda.gov/midwest-area/stpaul/cereal-disease-lab/",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "DON mycotoxin levels above 2ppm in grain pose health risks; monitoring essential for food safety."
        },
        {
            id: "PD016",
            name: "Common Bean Angular Leaf Spot",
            localName: "",
            scientific: "Phaeoisariopsis griseola",
            type: "disease",
            affectedCrops: ["Common Bean"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Angular leaf spot is a fungal disease caused by Phaeoisariopsis griseola that affects common beans. The disease is characterized by angular lesions on leaves and can cause significant yield losses, particularly in humid bean-growing regions.",
            symptoms: "Early: Small gray to brown angular spots on leaves, lesions bounded by leaf veins. Advanced: Angular necrotic lesions with yellow halos, severe defoliation, lesions on stems and pods, premature leaf drop, reduced photosynthesis, poor pod filling.",
            favorableConditions: "Moderate temperatures (20-28°C), high humidity, frequent rainfall, prolonged leaf wetness, dense canopy, susceptible varieties, infected seed.",
            prevention: "Use certified disease-free seed, plant resistant varieties, practice crop rotation, avoid dense planting.",
            culturalManagement: "Crop rotation with non-host crops, remove and destroy crop residues, proper spacing for air circulation, avoid overhead irrigation, weed management.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Seed treatment: Mancozeb, Captan; Foliar application: Azoxystrobin, Chlorothalonil, Copper-based fungicides.",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; SNNPR — Confirmed presence.",
            economicImpact: "Yield losses of 30-60% reported in susceptible varieties, significant impact on bean production and nutrition.",
            detailedDescription: "Angular leaf spot, caused by the fungal pathogen Phaeoisariopsis griseola (also known as Pseudocercospora griseola), is a significant disease affecting common beans (haricot beans) in Ethiopia, where beans are a major source of dietary protein and an important export crop. The disease produces characteristic angular lesions on leaves that are bounded by leaf veins, reducing photosynthetic area and causing premature defoliation. Yield losses of 30-60% have been reported in susceptible varieties under favorable conditions. The disease is favored by warm, humid conditions and is particularly severe in densely planted crops with poor air circulation. Ethiopia is one of Africa's largest producers and exporters of common beans, with white pea beans being particularly important for export markets. The quality requirements of export markets make disease management critical, as diseased beans are downgraded or rejected. The pathogen is seed-borne and can also survive on crop residues, making clean seed and crop rotation important components of integrated management. Research on resistant varieties has been ongoing through Ethiopian and international agricultural research programs.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Angular%20leaf%20spot%20of%20bean.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Angular%20leaf%20spot%20of%20bean.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Angular%20leaf%20spot%20of%20bean.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/40517",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Common bean is a major food security crop in Ethiopia; white pea beans are important export commodity."
        },
        {
            id: "PD017",
            name: "Faba Bean Chocolate Spot",
            localName: "",
            scientific: "Botrytis fabae",
            type: "disease",
            affectedCrops: ["Faba Bean"],
            partsAffected: ["Leaf", "Stem", "Flower"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Chocolate spot is a fungal disease caused by Botrytis fabae that affects faba beans. The disease appears as chocolate-brown spots on leaves and stems and can cause severe defoliation and yield losses.",
            symptoms: "Early: Small reddish-brown spots on leaves, lesions on stems and flowers. Advanced: Large chocolate-brown lesions, leaf death and defoliation, stem lesions causing breakage, flower abortion, poor pod set, complete plant death in severe cases.",
            favorableConditions: "Cool temperatures (15-22°C), high humidity, prolonged leaf wetness, dense canopy, susceptible varieties, excessive nitrogen fertilization.",
            prevention: "Plant resistant varieties, use certified disease-free seed, practice crop rotation, avoid dense planting.",
            culturalManagement: "Crop rotation with cereals, remove and destroy crop residues, proper spacing for air circulation, avoid excessive nitrogen, balanced fertilization, weed management.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Chlorothalonil, Mancozeb, Azoxystrobin (applied preventatively and at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Confirmed presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 30-70% reported in susceptible varieties, major constraint to faba bean production.",
            detailedDescription: "Chocolate spot, caused by the fungal pathogen Botrytis fabae, is the most destructive disease of faba bean (Vicia faba) in Ethiopia, where the crop is a major source of dietary protein and plays an important role in soil fertility through nitrogen fixation. The disease produces characteristic chocolate-brown lesions on leaves and stems that can cause severe defoliation and yield losses of 30-70% in susceptible varieties under favorable conditions. Chocolate spot is favored by cool, humid conditions and is particularly severe in the highland faba bean-growing areas of Ethiopia where these conditions prevail. The disease is especially problematic in dense crop canopies where humidity remains high for extended periods. Faba bean is deeply integrated into Ethiopian cropping systems, often grown in rotation with cereals and providing both food and income for smallholder farmers. The disease threatens both these direct benefits and the indirect benefits of nitrogen fixation for subsequent crops. Management focuses on resistant varieties, cultural practices that reduce canopy humidity, and targeted fungicide application in high-value production systems.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chocolate%20spot%20of%20faba%20bean.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chocolate%20spot%20of%20faba%20bean.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chocolate%20spot%20of%20faba%20bean.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/9704",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Faba bean is a major pulse crop in Ethiopian highlands; important for food and soil fertility."
        },
        {
            id: "PD018",
            name: "Finger Millet Blast",
            localName: "",
            scientific: "Magnaporthe oryzae",
            type: "disease",
            affectedCrops: ["Finger Millet", "Rice", "Wheat"],
            partsAffected: ["Leaf", "Stem", "Seed/Grain"],
            growthStage: ["Seedling", "Vegetative", "Flowering", "Grain Filling"],
            description: "Finger millet blast is a fungal disease caused by Magnaporthe oryzae that affects finger millet and other cereals. The disease causes leaf lesions, neck blast, and grain infection, leading to significant yield losses.",
            symptoms: "Early: Small water-soaked spots on leaves, grayish-green lesions. Advanced: Diamond-shaped lesions with gray centers and brown margins, leaf death, neck blast causing head breakage, shriveled grains, complete panicle loss in severe infections.",
            favorableConditions: "Moderate temperatures (25-28°C), high humidity, frequent rainfall, prolonged leaf wetness, high nitrogen fertilization, susceptible varieties.",
            prevention: "Plant resistant varieties, use certified disease-free seed, practice crop rotation, avoid excessive nitrogen.",
            culturalManagement: "Crop rotation, remove and destroy crop residues, balanced fertilization, proper spacing, avoid continuous cereal cropping.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Tricyclazole, Isoprothiolane, Azoxystrobin (applied preventatively, particularly for neck blast).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Reported presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported, significant impact on food security in finger millet-growing areas.",
            detailedDescription: "Finger millet blast, caused by the fungal pathogen Magnaporthe oryzae, is one of the most important diseases of finger millet (Eleusine coracana) in Ethiopia and globally. The disease attacks leaves, stems, and panicles, producing characteristic diamond-shaped lesions and causing neck blast that leads to panicle breakage and significant yield losses. Finger millet is an important food security crop in Ethiopia's semi-arid regions, valued for its drought tolerance, nutritional quality (high calcium content), and long storage life. The disease is favored by moderate temperatures, high humidity, and high nitrogen fertilization, and can cause yield losses of 20-50% in susceptible varieties. Blast is particularly damaging when neck blast occurs, as this directly prevents grain formation and can cause complete panicle loss. In Ethiopia, finger millet is grown primarily in western and southwestern regions, often by smallholder farmers who depend on the crop for household food security and local markets. Management combines resistant varieties, cultural practices that reduce humidity and nitrogen levels, and fungicide application in high-value production systems.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Finger%20millet%20blast.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Finger%20millet%20blast.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Finger%20millet%20blast.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/34585",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Magnaporthe oryzae is a species complex with host-specific forms; rice blast is a closely related disease."
        },
        {
            id: "PD019",
            name: "Tomato Early Blight",
            localName: "",
            scientific: "Alternaria solani",
            type: "disease",
            affectedCrops: ["Tomato", "Potato"],
            partsAffected: ["Leaf", "Stem", "Fruit"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Early blight is a fungal disease caused by Alternaria solani that affects tomato and potato. The disease causes characteristic target-shaped lesions on leaves and can cause significant yield losses.",
            symptoms: "Early: Small brown spots on older leaves, concentric rings developing in lesions. Advanced: Target-shaped lesions with concentric rings, leaf yellowing and death, stem lesions, fruit rot at stem end, premature defoliation, reduced fruit quality and yield.",
            favorableConditions: "Warm temperatures (24-29°C), high humidity, frequent rainfall, prolonged leaf wetness, plant stress, poor nutrition, susceptible varieties.",
            prevention: "Plant resistant varieties, use certified disease-free seed/transplants, practice crop rotation, avoid plant stress.",
            culturalManagement: "Crop rotation with non-solanaceous crops, remove and destroy infected plant material, proper spacing for air circulation, balanced fertilization, avoid overhead irrigation, stake plants.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, Bacillus subtilis (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Chlorothalonil, Mancozeb, Azoxystrobin, Copper-based fungicides (applied preventatively and at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported in susceptible varieties, significant impact on tomato production.",
            detailedDescription: "Early blight, caused by the fungal pathogen Alternaria solani, is one of the most common and economically important diseases of tomato worldwide, including in Ethiopia where tomato is a major vegetable crop for both domestic consumption and emerging processing industries. The disease produces characteristic target-shaped lesions with concentric rings on leaves, stems, and fruits, reducing yield and fruit quality. Early blight is favored by warm temperatures, high humidity, and plant stress, and is particularly severe in fields with poor nutrition or where plants are weakened by other stresses. Yield losses of 20-50% have been reported in susceptible varieties under favorable conditions. In Ethiopia, tomato production is expanding rapidly to meet growing urban demand and export opportunities, making disease management increasingly important for both productivity and profitability. Smallholder farmers often struggle with early blight due to limited access to resistant varieties and fungicides, leading to significant losses in affected areas. Management integrates resistant varieties, crop rotation, cultural practices that reduce humidity and plant stress, and fungicide application in high-value production.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20early%20blight.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20early%20blight.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20early%20blight.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/4489",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Alternaria solani also causes early blight of potato; affects solanaceous crops broadly."
        },
        {
            id: "PD020",
            name: "Onion Downy Mildew",
            localName: "",
            scientific: "Peronospora destructor",
            type: "disease",
            affectedCrops: ["Onion", "Garlic"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Onion downy mildew is a fungal disease caused by Peronospora destructor that affects onions and related alliums. The disease causes leaf destruction and bulb size reduction, leading to significant yield and quality losses.",
            symptoms: "Early: Pale green to yellow patches on leaves, grayish-purple fuzzy growth on leaf surfaces in humid conditions. Advanced: Extensive leaf yellowing and death, leaf collapse, reduced bulb development, poor bulb storage, secondary bacterial infections, complete crop failure in severe cases.",
            favorableConditions: "Cool temperatures (10-22°C), high humidity, prolonged leaf wetness, foggy conditions, dense canopy, susceptible varieties.",
            prevention: "Plant resistant varieties, use certified disease-free bulbs, practice crop rotation, avoid dense planting.",
            culturalManagement: "Crop rotation with non-allium crops (3-4 years), proper spacing for air circulation, avoid overhead irrigation, remove volunteer onions, field sanitation.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Mancozeb, Chlorothalonil, Metalaxyl, Cymoxanil (applied preventatively, rotation recommended).",
            ethiopianDistribution: "Oromia — Reported presence; Amhara — Reported presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 30-60% reported in susceptible varieties under favorable conditions.",
            detailedDescription: "Onion downy mildew, caused by the oomycete pathogen Peronospora destructor, is a destructive disease of onions and other allium crops in cool, humid growing regions. The disease produces pale green to yellow patches on leaves with grayish-purple fuzzy growth, leading to leaf death and reduced bulb development. Yield losses of 30-60% have been reported in susceptible varieties under favorable conditions. Onion is an increasingly important crop in Ethiopia, grown for domestic consumption and emerging export markets, and downy mildew represents a significant constraint to production, particularly in highland areas with cool, humid conditions. The pathogen is favored by cool temperatures, high humidity, and prolonged leaf wetness, conditions that are common in many Ethiopian onion-growing regions during parts of the growing season. The oomycete survives in infected bulbs and crop residues, making disease management challenging in continuous onion production systems. Management focuses on resistant varieties, crop rotation with non-allium crops, cultural practices that reduce humidity, and preventative fungicide application in high-value production.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20downy%20mildew.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20downy%20mildew.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20downy%20mildew.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/39855",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Oomycete pathogen (water mold), not a true fungus; overwinters in bulbs and crop residues."
        },
        {
            id: "PD021",
            name: "Pepper Bacterial Spot",
            localName: "",
            scientific: "Xanthomonas euvesicatoria",
            type: "disease",
            affectedCrops: ["Pepper", "Tomato"],
            partsAffected: ["Leaf", "Fruit", "Stem"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Bacterial spot is caused by Xanthomonas species (X. euvesicatoria, X. vesicatoria, X. perforans) affecting peppers and tomatoes. The disease causes leaf and fruit lesions, reducing both yield and marketability.",
            symptoms: "Early: Small water-soaked spots on leaves and fruits, yellow halos around lesions. Advanced: Dark brown to black lesions on leaves and fruits, leaf yellowing and drop, fruit lesions become raised and scabby, defoliation, sunscald of exposed fruits, reduced marketability.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, frequent rainfall, overhead irrigation, dense canopy, susceptible varieties.",
            prevention: "Use certified disease-free seed/transplants, plant resistant varieties, avoid overhead irrigation, practice crop rotation.",
            culturalManagement: "Crop rotation with non-solanaceous crops, remove and destroy infected plants, proper spacing for air circulation, avoid working in wet fields, field sanitation.",
            biologicalManagement: "Biocontrol agents: Bacillus species (limited field efficacy, research ongoing).",
            chemicalManagement: "Copper-based fungicides + Mancozeb combination, Streptomycin (restricted use, resistance concerns), applied preventatively.",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported, significant quality losses due to fruit lesions.",
            detailedDescription: "Bacterial spot, caused by several Xanthomonas species (X. euvesicatoria, X. vesicatoria, and X. perforans), is a significant disease affecting peppers and tomatoes in warm, humid growing regions including Ethiopia. The disease produces small water-soaked spots on leaves and fruits that develop into dark lesions, reducing both yield and marketability of fruits. Pepper (Capsicum) is an important vegetable and spice crop in Ethiopia, used extensively in traditional cuisine (particularly for berbere spice) and increasingly for export markets. Bacterial spot is favored by warm temperatures, high humidity, and overhead irrigation, and is particularly problematic during rainy seasons when conditions favor bacterial spread. Yield losses of 20-50% have been reported, with additional quality losses due to fruit lesions that make peppers unmarketable. The pathogen is seed-borne, making certified disease-free seed critical for disease management. The bacteria can also survive on crop residues and spread through water splash, contaminated tools, and worker movement. Management integrates certified seed, resistant varieties, cultural practices that reduce humidity and spread, and copper-based bactericide application in high-value production.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Pepper%20bacterial%20spot.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Pepper%20bacterial%20spot.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Pepper%20bacterial%20spot.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56958",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Multiple Xanthomonas species cause similar symptoms; accurate identification requires laboratory testing."
        },
        {
            id: "PD022",
            name: "Citrus Tristeza Virus",
            localName: "",
            scientific: "Citrus tristeza virus (CTV)",
            type: "disease",
            affectedCrops: ["Citrus"],
            partsAffected: ["Whole Plant", "Stem", "Root"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Citrus tristeza virus is one of the most important viral diseases of citrus worldwide. The virus is transmitted by aphids and through infected grafting material. It causes decline, stem pitting, and death of susceptible citrus trees.",
            symptoms: "Early: Reduced tree vigor, yellowing of leaves, twig dieback. Advanced: Stem pitting (small pits in wood beneath bark), tree decline, poor fruit quality, reduced fruit size, tree death in susceptible rootstock combinations, slow decline over several years.",
            favorableConditions: "Presence of efficient aphid vectors (Toxoptera citricida, Aphis gossypii), susceptible rootstock (sour orange), infected propagation material, warm climates favoring aphid populations.",
            prevention: "Use certified virus-free planting material, use tolerant rootstocks, control aphid vectors, quarantine infected trees.",
            culturalManagement: "Remove and destroy severely infected trees, control aphid populations, avoid propagation from infected trees, use resistant/tolerant rootstocks where available.",
            biologicalManagement: "Biological control of aphid vectors using natural predators (ladybirds, lacewings, parasitic wasps).",
            chemicalManagement: "No chemical control for virus; insecticide application for vector control: Imidacloprid, Thiamethoxam (limited efficacy).",
            ethiopianDistribution: "Not confirmed in Ethiopia from verified source; present in other East African countries.",
            economicImpact: "Potential serious economic losses if introduced; stem pitting strains cause significant yield reduction.",
            detailedDescription: "Citrus tristeza virus (CTV) is one of the most destructive viral diseases of citrus worldwide, responsible for the death of millions of trees and the collapse of citrus industries in many countries. The virus is transmitted by aphids and through infected grafting material, and causes a range of symptoms depending on the virus strain and citrus rootstock combination. The most severe form causes stem pitting and decline in trees grafted on susceptible rootstocks, leading to reduced vigor, poor fruit quality, and eventual tree death. Ethiopia's citrus production is relatively modest compared to other countries, but the crop is important for domestic consumption and emerging export markets. The presence of efficient aphid vectors and susceptible rootstocks would create conditions for rapid spread if the virus is introduced. While CTV has not been confirmed in Ethiopia from verified sources, it is present in other East African countries, raising concerns about future introduction through movement of infected planting material. Prevention through quarantine and use of certified virus-free planting material is critical, as no effective chemical control exists for the virus.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Citrus%20tristeza%20virus.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Citrus%20tristeza%20virus.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Citrus%20tristeza%20virus.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/13373",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "One of the most destructive citrus diseases globally; responsible for death of millions of trees."
        },
        {
            id: "PD023",
            name: "Barley Net Blotch",
            localName: "",
            scientific: "Pyrenophora teres",
            type: "disease",
            affectedCrops: ["Barley"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Barley net blotch is a fungal disease caused by Pyrenophora teres. It occurs in two forms: net form and spot form. The disease causes leaf lesions that reduce photosynthetic area and can cause significant yield and quality losses.",
            symptoms: "Early: Small brown spots on leaves, developing into net-like or spot patterns. Net form: Dark brown net-like pattern of lesions on leaves. Spot form: Circular to elliptical brown spots with dark margins. Advanced: Lesions coalesce, leaf yellowing and death, premature senescence, reduced grain size and quality.",
            favorableConditions: "Moderate temperatures (15-25°C), high humidity, frequent rainfall, prolonged leaf wetness, susceptible varieties, continuous barley cropping.",
            prevention: "Plant resistant varieties, use certified disease-free seed, practice crop rotation, remove crop residues.",
            culturalManagement: "Crop rotation with non-host crops, remove and destroy crop residues, avoid continuous barley cropping, balanced fertilization, proper spacing.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Seed treatment: Carboxin, Tebuconazole; Foliar application: Propiconazole, Azoxystrobin (applied at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 20-40% reported, significant impact on malt barley quality.",
            detailedDescription: "Barley net blotch, caused by the fungal pathogen Pyrenophora teres, is one of the most economically important diseases of barley worldwide, occurring in two forms: the net form and the spot form. The net form produces characteristic dark brown net-like patterns on leaves, while the spot form produces circular to elliptical brown spots. Both forms reduce photosynthetic area and can cause significant yield and quality losses, particularly in malt barley where quality requirements are stringent. In Ethiopia, barley is an important crop for both food (used in traditional foods and beverages) and income (increasingly grown for the malting industry), making net blotch management important for both food security and farmer livelihoods. The pathogen is seed-borne and survives on crop residues, making disease management challenging in areas where certified seed use is limited and continuous barley cropping is practiced. Yield losses of 20-40% have been reported in susceptible varieties. Management integrates resistant varieties, certified seed, crop rotation, residue management, and targeted fungicide application in high-value production.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20net%20blotch.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20net%20blotch.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20net%20blotch.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/46177",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Net form and spot form caused by same species but different pathotypes."
        },
        {
            id: "PD024",
            name: "Rice Blast",
            localName: "",
            scientific: "Magnaporthe oryzae (Pyricularia oryzae)",
            type: "disease",
            affectedCrops: ["Rice"],
            partsAffected: ["Leaf", "Stem", "Seed/Grain"],
            growthStage: ["Seedling", "Vegetative", "Flowering", "Grain Filling"],
            description: "Rice blast is one of the most destructive fungal diseases of rice worldwide, caused by Magnaporthe oryzae. The disease attacks leaves, stems, and panicles, causing significant yield losses.",
            symptoms: "Early: Small water-soaked spots on leaves, grayish-green lesions. Advanced: Diamond-shaped lesions with gray centers and brown margins, leaf death, neck blast (brown lesion at panicle base), panicle breakage, shriveled grains, complete crop loss in severe epidemics.",
            favorableConditions: "Moderate temperatures (25-28°C), high humidity (>90%), prolonged leaf wetness, high nitrogen fertilization, susceptible varieties, continuous rice cropping.",
            prevention: "Plant resistant varieties, use certified disease-free seed, practice crop rotation, avoid excessive nitrogen, manage water properly.",
            culturalManagement: "Crop rotation, remove and destroy crop residues, balanced fertilization, proper water management, avoid dense planting.",
            biologicalManagement: "Biocontrol agents: Pseudomonas fluorescens, Trichoderma species (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Tricyclazole, Isoprothiolane, Azoxystrobin (applied preventatively, especially for neck blast).",
            ethiopianDistribution: "Gambella — Confirmed presence; Amhara — Reported presence; Oromia — Reported presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 30-100% reported in susceptible varieties during epidemic years, major threat to rice production.",
            detailedDescription: "Rice blast, caused by the fungal pathogen Magnaporthe oryzae, is the most destructive disease of rice worldwide and is considered one of the top 10 most scientifically important fungal diseases globally. The disease attacks leaves, stems, and panicles, producing characteristic diamond-shaped lesions and causing neck blast that leads to panicle breakage and complete yield loss in severe cases. Rice production in Ethiopia is relatively recent but expanding rapidly, particularly in Gambella and other areas with suitable conditions. Blast is favored by moderate temperatures, high humidity, and high nitrogen fertilization, and is particularly severe in continuous rice systems with susceptible varieties. Yield losses of 30-100% have been reported in susceptible varieties during epidemic years. The disease is especially challenging in smallholder systems where resistant varieties and fungicides may not be readily available. As Ethiopia seeks to expand domestic rice production to reduce imports, blast management will be critical for achieving sustainable productivity. Management combines resistant varieties, cultural practices that reduce humidity and nitrogen levels, and fungicide application in high-value production.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Rice%20blast.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Rice%20blast.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Rice%20blast.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/34683",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Rice blast is one of the top 10 most scientifically important fungal diseases globally."
        },
        {
            id: "PD025",
            name: "Sesame Phyllody",
            localName: "",
            scientific: "Phytoplasma (Candidatus Phytoplasma)",
            type: "disease",
            affectedCrops: ["Sesame"],
            partsAffected: ["Flower", "Leaf", "Whole Plant"],
            growthStage: ["Flowering", "Fruiting"],
            description: "Sesame phyllody is a serious disease caused by phytoplasma and transmitted by leafhoppers. The disease causes flower parts to transform into leaf-like structures, resulting in complete yield loss in affected plants.",
            symptoms: "Early: Yellowing of leaves, stunted growth, flower buds remain green. Advanced: Floral organs transform into green leaf-like structures (phyllody), proliferation of branches (witches' broom), complete sterility, no seed set, plants remain green longer than healthy plants.",
            favorableConditions: "Presence of leafhopper vectors (Orosius species), warm temperatures favoring vector activity, presence of alternative host plants, susceptible varieties, continuous sesame cropping.",
            prevention: "Plant resistant/tolerant varieties, control leafhopper vectors, remove alternative weed hosts, practice crop rotation.",
            culturalManagement: "Crop rotation with non-host crops, remove and destroy infected plants, control weed hosts, timely planting to avoid peak vector activity, field sanitation.",
            biologicalManagement: "Biological control of leafhopper vectors using natural enemies.",
            chemicalManagement: "No chemical control for phytoplasma; insecticide application for vector control: Imidacloprid, Thiamethoxam (limited efficacy).",
            ethiopianDistribution: "Amhara — Confirmed presence; Tigray — Confirmed presence; Oromia — Reported presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 30-100% reported in affected fields, significant impact on sesame export earnings.",
            detailedDescription: "Sesame phyllody is a devastating disease caused by phytoplasma (Candidatus Phytoplasma) and transmitted by leafhopper vectors. The disease causes flower parts to transform into leaf-like structures (phyllody), resulting in complete sterility and yield loss in affected plants. Ethiopia is one of the world's top sesame producers and exporters, with the crop being particularly important in the northwestern lowlands (Amhara and Tigray regions) and increasingly in other areas. Phyllody is a major constraint to sesame production, causing yield losses of 30-100% in affected fields. The disease is favored by conditions that support leafhopper vector populations, including warm temperatures and the presence of alternative host plants that serve as phytoplasma reservoirs. Management is challenging because no chemical control exists for phytoplasma, and insecticide application for vector control has limited efficacy due to the persistent nature of transmission. Research on resistant varieties and integrated management approaches is ongoing through Ethiopian and international agricultural research programs. The economic importance of sesame phyllody to Ethiopia's export earnings makes this disease a priority for research and management.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Sesame%20phyllody.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Sesame%20phyllody.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Sesame%20phyllody.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/49913",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Ethiopia is among the top 5 sesame producers and exporters globally; phyllody is a major production constraint."
        },
        {
            id: "PD026",
            name: "Maize Northern Leaf Blight",
            localName: "",
            scientific: "Exserohilum turcicum",
            type: "disease",
            affectedCrops: ["Maize"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Northern leaf blight is a fungal disease caused by Exserohilum turcicum that affects maize leaves. The disease causes characteristic cigar-shaped lesions and can cause significant yield losses.",
            symptoms: "Early: Small grayish-green oval spots on lower leaves. Advanced: Large cigar-shaped gray to tan lesions, lesions coalesce forming large necrotic areas, leaf death, premature senescence, reduced photosynthesis, poor grain filling, stalk weakening.",
            favorableConditions: "Moderate temperatures (18-27°C), high humidity, prolonged leaf wetness, susceptible varieties, high nitrogen fertilization, continuous maize cropping.",
            prevention: "Plant resistant varieties, practice crop rotation, avoid dense planting, balanced fertilization.",
            culturalManagement: "Crop rotation with legumes or non-host crops, remove and incorporate crop residues, proper spacing, avoid excessive nitrogen.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Azoxystrobin, Propiconazole, Tebuconazole (applied at early disease onset; economics may not favor smallholder use).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported in susceptible varieties, significant in high-rainfall maize areas.",
            detailedDescription: "Northern leaf blight, caused by the fungal pathogen Exserohilum turcicum, is one of the most important diseases of maize in Ethiopia and globally, particularly in high-rainfall areas with moderate temperatures. The disease produces characteristic cigar-shaped gray to tan lesions on leaves that reduce photosynthetic area and can cause yield losses of 20-50% in susceptible varieties. Northern leaf blight is favored by moderate temperatures, high humidity, and prolonged leaf wetness, conditions that are common in Ethiopia's highland maize-growing areas. The pathogen survives on crop residues, making disease pressure higher in continuous maize systems with limited residue management. In Ethiopia, maize is the most important cereal crop by production volume, serving as a staple food for millions of people and an input for the livestock industry. The importance of northern leaf blight has increased as maize production has intensified to meet growing food demand. Management integrates resistant varieties, crop rotation, residue management, and fungicide application in high-value production, though economics may not favor chemical control for smallholder farmers.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Northern%20corn%20leaf%20blight.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Northern%20corn%20leaf%20blight.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Northern%20corn%20leaf%20blight.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/22249",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Pathogen can survive in maize residues; reduced tillage may increase disease pressure."
        },
        {
            id: "PD027",
            name: "Cowpea Bacterial Blight",
            localName: "",
            scientific: "Xanthomonas axonopodis pv. vignicola",
            type: "disease",
            affectedCrops: ["Cowpea"],
            partsAffected: ["Leaf", "Stem", "Seed/Grain"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Cowpea bacterial blight is caused by Xanthomonas axonopodis pv. vignicola. The disease affects leaves, stems, and pods of cowpea, causing lesions that reduce yield and quality.",
            symptoms: "Early: Small water-soaked spots on leaves, yellow halos around lesions. Advanced: Large brown necrotic lesions, leaf death and defoliation, stem lesions, pod lesions with seed infection, stunted growth, reduced yield and quality.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, frequent rainfall, overhead irrigation, contaminated seed, susceptible varieties.",
            prevention: "Use certified disease-free seed, practice crop rotation, avoid overhead irrigation, plant resistant varieties where available.",
            culturalManagement: "Crop rotation with cereals, remove and destroy infected plants, proper spacing for air circulation, avoid working in wet fields, field sanitation.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Seed treatment: Copper-based compounds; Foliar application: Copper-based fungicides (limited efficacy).",
            ethiopianDistribution: "Oromia — Reported presence; Amhara — Reported presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 20-40% reported, significant impact on cowpea production for food and fodder.",
            detailedDescription: "Cowpea bacterial blight, caused by Xanthomonas axonopodis pv. vignicola, is a significant disease affecting cowpea in warm, humid growing regions including Ethiopia. The disease produces water-soaked spots that develop into brown necrotic lesions on leaves, stems, and pods, reducing yield and quality. Cowpea is an important legume crop in semi-arid regions of Ethiopia, valued for its drought tolerance, protein-rich seeds, and nutritious leaves used as vegetables, as well as fodder for livestock. The disease is seed-borne and spreads through water splash and contaminated tools, making management challenging in smallholder systems where certified seed use may be limited. Yield losses of 20-40% have been reported in susceptible varieties. The importance of cowpea in Ethiopia is increasing as climate change makes drought-tolerant crops more valuable, and disease management will be critical for realizing the crop's potential. Management focuses on certified disease-free seed, crop rotation, cultural practices that reduce humidity and spread, and copper-based bactericide application where economically feasible.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cowpea%20bacterial%20blight.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cowpea%20bacterial%20blight.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cowpea%20bacterial%20blight.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56955",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Seed-borne disease; use of clean seed is critical for management."
        },
        {
            id: "PD028",
            name: "Potato Virus Y",
            localName: "",
            scientific: "Potato virus Y (PVY)",
            type: "disease",
            affectedCrops: ["Potato", "Tomato", "Pepper"],
            partsAffected: ["Leaf", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Potato virus Y is one of the most economically important viral diseases of potato worldwide. The virus is transmitted by aphids in a non-persistent manner and through infected seed tubers.",
            symptoms: "Early: Mild mottling and yellowing of leaves, leaf distortion. Advanced: Severe leaf necrosis (necrotic strains), leaf drop, stunted growth, reduced tuber size and yield, tuber necrosis (NTN strain), plant death in severe infections.",
            favorableConditions: "Presence of aphid vectors (Myzus persicae and others), infected seed tubers, volunteer potato plants, susceptible varieties, warm conditions favoring aphid activity.",
            prevention: "Use certified virus-free seed tubers, plant resistant varieties, control aphid vectors, remove volunteer potato plants.",
            culturalManagement: "Remove volunteer potato plants, control aphid populations, rogue out infected plants early, field sanitation, use healthy seed from certified sources.",
            biologicalManagement: "Biological control of aphid vectors using natural predators (ladybirds, lacewings).",
            chemicalManagement: "No chemical control for virus; insecticide application for vector control: Mineral oils, Imidacloprid (limited efficacy due to non-persistent transmission).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Reported presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 20-80% reported depending on variety and virus strain, significant impact on seed potato quality.",
            detailedDescription: "Potato virus Y (PVY) is one of the most economically important viral diseases of potato worldwide, causing yield reductions and quality losses through both direct effects on plant growth and necrotic symptoms that affect tuber marketability. The virus is transmitted by aphids in a non-persistent manner (meaning aphids acquire and transmit the virus quickly during brief feeding probes) and through infected seed tubers. PVY has a wide host range including potato, tomato, pepper, and tobacco, making management complicated in diverse cropping systems. In Ethiopia, PVY is present in seed potato production systems and represents a significant constraint to potato production, particularly for seed producers who must meet certification standards. Yield losses of 20-80% have been reported depending on variety and virus strain, with necrotic strains causing additional quality losses. Management is challenging because non-persistent transmission means that insecticide application has limited efficacy for controlling virus spread. Effective management relies on certified virus-free seed, resistant varieties, cultural practices that reduce aphid activity, and isolation from infection sources.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potatovirusy.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potatovirusy.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potatovirusy.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/45901",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Multiple PVY strains exist; NTN strain causes necrotic rings on tubers affecting marketability."
        },
        {
            id: "PD029",
            name: "Sweet Potato Virus Disease",
            localName: "",
            scientific: "Sweet potato feathery mottle virus (SPFMV) + Sweet potato chlorotic stunt virus (SPCSV)",
            type: "disease",
            affectedCrops: ["Sweet Potato"],
            partsAffected: ["Leaf", "Root", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Sweet potato virus disease (SPVD) is caused by co-infection of Sweet potato feathery mottle virus and Sweet potato chlorotic stunt virus. The synergistic interaction causes severe symptoms and significant yield losses.",
            symptoms: "Early: Mild leaf mottling, slight stunting. Advanced: Severe stunting, leaf distortion and curling, chlorosis, vein clearing, reduced root yield, poor root quality, complete crop failure in severe infections.",
            favorableConditions: "Presence of whitefly vectors (Bemisia tabaci), use of infected planting material (vines), continuous sweet potato cropping, susceptible varieties, warm conditions favoring vector activity.",
            prevention: "Use virus-free planting material (tissue culture or certified vines), plant resistant varieties, control whitefly vectors, practice crop rotation.",
            culturalManagement: "Crop rotation, remove and destroy infected plants, use healthy planting material from reliable sources, control whitefly populations, field sanitation.",
            biologicalManagement: "Biological control of whitefly vectors using natural enemies (Encarsia species, predatory mites).",
            chemicalManagement: "No chemical control for virus; insecticide application for vector control: Imidacloprid, Thiamethoxam (limited efficacy).",
            ethiopianDistribution: "Oromia — Confirmed presence; SNNPR — Confirmed presence; Amhara — Reported presence.",
            economicImpact: "Yield losses of 50-90% reported in susceptible varieties, significant impact on food security.",
            detailedDescription: "Sweet potato virus disease (SPVD) is the most important viral disease of sweet potato in Africa, caused by co-infection of Sweet potato feathery mottle virus (SPFMV) and Sweet potato chlorotic stunt virus (SPCSV). The synergistic interaction between these two viruses produces symptoms far more severe than either virus alone, including severe stunting, leaf distortion, and yield losses of 50-90% in susceptible varieties. Sweet potato is an important food security crop in Ethiopia, particularly in southern and southwestern regions where it provides food during periods of scarcity and serves as a buffer against crop failures of other staples. The disease is transmitted by whiteflies and through infected planting material (vines), making it difficult to manage in smallholder systems where farmers typically save planting material from previous crops. The importance of SPVD is increasing as sweet potato production expands to meet food security needs. Management focuses on virus-free planting material (produced through tissue culture or certified programs), resistant varieties, and control of whitefly vectors.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Sweet%20potato%20virus%20disease.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Sweet%20potato%20virus%20disease.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Sweet%20potato%20virus%20disease.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/45890",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Synergistic interaction between the two viruses is required for severe symptoms."
        },
        {
            id: "PD030",
            name: "Banana Bunchy Top Virus",
            localName: "",
            scientific: "Banana bunchy top virus (BBTV)",
            type: "disease",
            affectedCrops: ["Banana"],
            partsAffected: ["Leaf", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Banana bunchy top virus is one of the most devastating viral diseases of banana worldwide. The virus is transmitted by banana aphids (Pentalonia nigronervosa) and through infected planting material.",
            symptoms: "Early: Dark green streaks on leaf veins, narrow leaves, slight stunting. Advanced: Leaves become narrow and upright, bunchy appearance at top of plant (rosette), severe stunting, failure to produce fruit, plant death, spread to entire plantation through aphids.",
            favorableConditions: "Presence of banana aphid vector, infected planting material, movement of infected suckers, warm humid conditions favoring aphid populations.",
            prevention: "Use certified virus-free planting material, quarantine new planting material, control aphid vectors, avoid movement of plant material from infected areas.",
            culturalManagement: "Remove and destroy infected plants (including rhizomes), control aphid populations, use disease-free planting material, field sanitation.",
            biologicalManagement: "Biological control of aphid vectors using natural predators (ladybirds, lacewings).",
            chemicalManagement: "No chemical control for virus; insecticide application for vector control: Imidacloprid, Thiamethoxam (limited efficacy).",
            ethiopianDistribution: "Not confirmed in Ethiopia from verified source; present in some African countries.",
            economicImpact: "Potential catastrophic losses if introduced; disease can destroy entire plantations.",
            detailedDescription: "Banana bunchy top virus (BBTV) is one of the most devastating viral diseases of banana worldwide, causing stunting, leaf distortion, and complete yield loss in infected plants. The virus is transmitted by banana aphids (Pentalonia nigronervosa) and through infected planting material, making it difficult to control once established. Infected plants develop a characteristic 'bunchy top' appearance with narrow, upright leaves clustered at the top of the plant, and fail to produce fruit. BBTV is present in several African countries and poses a threat to banana production in Ethiopia, where banana is an important food and income crop in many regions. The disease spreads relatively slowly but persistently, and once a field becomes infected, elimination requires destruction of all infected plants and strict aphid control. Prevention through quarantine and use of certified virus-free planting material is critical, as no chemical control exists for the virus. The potential impact of BBTV introduction into Ethiopia would be severe, particularly for smallholder farmers who depend on banana for food security and income.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/DSC06900%20Banana%20bunchy%20top%20Hilo.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/DSC06900%20Banana%20bunchy%20top%20Hilo.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/DSC06900%20Banana%20bunchy%20top%20Hilo.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/8177",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Strict quarantine measures essential to prevent introduction."
        },
        {
            id: "PD031",
            name: "Avocado Root Rot",
            localName: "",
            scientific: "Phytophthora cinnamomi",
            type: "disease",
            affectedCrops: ["Avocado"],
            partsAffected: ["Root", "Whole Plant"],
            growthStage: ["Seedling", "Vegetative", "Flowering", "Fruiting"],
            description: "Avocado root rot (Phytophthora root rot) is caused by the oomycete pathogen Phytophthora cinnamomi. The disease attacks the root system, causing decline and death of avocado trees.",
            symptoms: "Early: Reduced tree vigor, small pale green leaves, leaf drop, branch dieback. Advanced: Brown discoloration of roots, root rot, severe defoliation, complete tree death, tree falls over easily due to root loss.",
            favorableConditions: "Poor soil drainage, waterlogged conditions, warm soil temperatures (25-30°C), acidic soils, movement of contaminated soil, susceptible rootstocks.",
            prevention: "Plant resistant rootstocks, ensure proper drainage, avoid over-irrigation, use disease-free planting material.",
            culturalManagement: "Improve soil drainage, avoid damage to roots, apply organic matter to improve soil structure, plant on raised beds where drainage is poor, avoid movement of contaminated soil.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, mycorrhizal fungi (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Metalaxyl, Fosetyl-Aluminum (applied as soil drench or trunk injection; limited efficacy once trees are infected).",
            ethiopianDistribution: "Oromia — Reported presence; SNNPR — Reported presence; Amhara — Reported presence.",
            economicImpact: "Tree death and significant yield losses reported; major constraint to avocado production expansion.",
            detailedDescription: "Avocado root rot, caused by the oomycete pathogen Phytophthora cinnamomi, is the most serious disease of avocado worldwide and a major constraint to avocado production in Ethiopia. The pathogen attacks the root system, causing root decay and disrupting water and nutrient uptake, leading to tree decline and death. The disease is favored by poor soil drainage, waterlogged conditions, and warm soil temperatures, and is particularly problematic in areas with heavy soils or excessive irrigation. Avocado is an increasingly important crop in Ethiopia, with production expanding for both domestic consumption and export markets. The disease causes tree death and significant yield losses, threatening the economic viability of avocado production in affected areas. The pathogen survives in soil for many years and has an extremely wide host range, making crop rotation ineffective for disease management. Management focuses on resistant rootstocks, improved drainage, careful irrigation management, and preventative fungicide application. Biocontrol with Trichoderma species and mycorrhizal fungi has shown some promise in research trials.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Avocado%20root%20rot.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Avocado%20root%20rot.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Avocado%20root%20rot.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/40968",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Oomycete (water mold), not a true fungus; has extremely wide host range (>1000 plant species)."
        },
        {
            id: "PD032",
            name: "Mango Anthracnose",
            localName: "",
            scientific: "Colletotrichum gloeosporioides",
            type: "disease",
            affectedCrops: ["Mango"],
            partsAffected: ["Leaf", "Fruit", "Flower", "Stem"],
            growthStage: ["Flowering", "Fruiting"],
            description: "Mango anthracnose is a fungal disease caused by Colletotrichum gloeosporioides. It is one of the most important diseases of mango, causing blossom blight, leaf spots, and fruit rot.",
            symptoms: "Early: Small black spots on leaves, flowers, and young fruits; blossom blight. Advanced: Large black lesions on leaves, flower death and poor fruit set, fruit lesions develop into black sunken areas, fruit rot (pre- and post-harvest), premature fruit drop, significant post-harvest losses.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, frequent rainfall, prolonged leaf wetness, dense canopy, susceptible varieties.",
            prevention: "Plant resistant varieties, maintain proper spacing, prune to improve air circulation, practice field sanitation.",
            culturalManagement: "Regular pruning, remove and destroy infected plant parts, maintain balanced shade, proper harvesting and post-harvest handling, avoid fruit injury during harvest.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, Bacillus subtilis (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Copper-based fungicides, Azoxystrobin, Chlorothalonil, Mancozeb (applied at flowering and fruit development; post-harvest dips with hot water + fungicide).",
            ethiopianDistribution: "Oromia — Confirmed presence; SNNPR — Reported presence; Amhara — Reported presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 20-60% reported, significant post-harvest losses affecting marketability and export potential.",
            detailedDescription: "Mango anthracnose, caused by the fungal pathogen Colletotrichum gloeosporioides, is one of the most important diseases of mango worldwide, affecting leaves, flowers, and fruits. The disease causes blossom blight that reduces fruit set, leaf spots that reduce photosynthetic capacity, and fruit lesions that cause both pre-harvest and post-harvest losses. In Ethiopia, mango is an important fruit crop for domestic consumption and emerging export markets, and anthracnose represents a major constraint to production and marketing. The disease is favored by warm, humid conditions and is particularly severe during rainy seasons when conditions favor infection and spread. Post-harvest losses are especially significant, as latent infections that occur in the field develop into rot during storage and transport. Yield losses of 20-60% have been reported, with additional post-harvest losses that reduce marketability and export potential. Management integrates resistant varieties, cultural practices that reduce humidity, field sanitation, fungicide application at flowering and fruit development, and post-harvest treatments such as hot water dips.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Mango-anthracnose.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Mango-anthracnose.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Mango-anthracnose.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/14884",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "C. gloeosporioides is a species complex; multiple species cause mango anthracnose."
        },
        {
            id: "PD033",
            name: "Papaya Ring Spot Virus",
            localName: "",
            scientific: "Papaya ringspot virus (PRSV)",
            type: "disease",
            affectedCrops: ["Papaya"],
            partsAffected: ["Leaf", "Fruit", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Papaya ringspot virus is a devastating viral disease of papaya transmitted by aphids. The virus causes stunting, leaf distortion, and characteristic ring spots on fruits.",
            symptoms: "Early: Yellow mottling of young leaves, leaf distortion, oil streaks on stems. Advanced: Severe stunting, shoe-string leaves (narrow, distorted), characteristic ring spots on fruits, reduced fruit quality and marketability, premature fruit drop, plant death.",
            favorableConditions: "Presence of aphid vectors (Myzus persicae, Aphis gossypii), infected planting material, susceptible varieties, warm conditions favoring aphid activity.",
            prevention: "Use certified virus-free planting material, plant tolerant varieties where available, control aphid vectors, practice crop rotation.",
            culturalManagement: "Remove and destroy infected plants, control aphid populations, avoid intercropping with host plants, use barrier crops (e.g., maize) to reduce aphid movement.",
            biologicalManagement: "Biological control of aphid vectors using natural predators (ladybirds, lacewings).",
            chemicalManagement: "No chemical control for virus; insecticide application for vector control: Mineral oils, Imidacloprid (limited efficacy due to non-persistent transmission).",
            ethiopianDistribution: "Not confirmed in Ethiopia from verified source; present in other African countries.",
            economicImpact: "Potential severe yield losses if introduced; can destroy papaya production in affected areas.",
            detailedDescription: "Papaya ringspot virus (PRSV) is a devastating viral disease of papaya that has destroyed papaya industries in many countries and poses a threat to papaya production in Africa, including Ethiopia. The virus is transmitted by aphids in a non-persistent manner and causes stunting, leaf distortion, and characteristic ring spots on fruits that reduce marketability. Infected plants become unproductive within 1-2 years, and the disease can spread rapidly through papaya-growing areas. PRSV has not been confirmed in Ethiopia from verified sources, but it is present in other African countries, raising concerns about future introduction through movement of infected planting material or aphid vectors. The potential impact of PRSV introduction would be severe, particularly for smallholder farmers who grow papaya for food security and income. Prevention through quarantine and use of virus-free planting material is critical. Transgenic papaya resistant to PRSV has been successfully deployed in Hawaii, demonstrating the potential for genetic resistance as a management strategy, though public acceptance and regulatory barriers remain challenges.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Papaya%20%28Carica%20papaya%29-%20Ringspot%20caused%20by%20Papaya%20ringspot%20virus%20%28PRSV%29%20-%2014909752488.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Papaya%20%28Carica%20papaya%29-%20Ringspot%20caused%20by%20Papaya%20ringspot%20virus%20%28PRSV%29%20-%2014909752488.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Papaya%20%28Carica%20papaya%29-%20Ringspot%20caused%20by%20Papaya%20ringspot%20virus%20%28PRSV%29%20-%2014909752488.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/38637",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Transgenic papaya resistant to PRSV has been successfully deployed in Hawaii."
        },
        {
            id: "PD034",
            name: "Lentil Rust",
            localName: "",
            scientific: "Uromyces viciae-fabae",
            type: "disease",
            affectedCrops: ["Lentil", "Faba Bean", "Pea"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Lentil rust is a fungal disease caused by Uromyces viciae-fabae. The disease affects lentils and other legumes, causing leaf and stem lesions that reduce yield and quality.",
            symptoms: "Early: Small yellowish spots on leaves, developing into reddish-brown pustules. Advanced: Numerous rust pustules on leaves and stems, leaf yellowing and death, premature defoliation, reduced pod filling, shriveled seeds, significant yield reduction.",
            favorableConditions: "Moderate temperatures (20-25°C), high humidity, prolonged leaf wetness, dense canopy, susceptible varieties.",
            prevention: "Plant resistant varieties, use certified disease-free seed, practice crop rotation, avoid dense planting.",
            culturalManagement: "Crop rotation, remove and destroy crop residues, proper spacing for air circulation, avoid excessive nitrogen, balanced fertilization.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Propiconazole, Tebuconazole, Azoxystrobin (applied at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported in susceptible varieties, significant impact on lentil production and export.",
            detailedDescription: "Lentil rust, caused by the fungal pathogen Uromyces viciae-fabae, is a significant disease affecting lentil production in Ethiopia, one of Africa's largest lentil producers and exporters. The disease produces reddish-brown pustules on leaves and stems that reduce photosynthetic capacity, cause premature defoliation, and lead to yield losses of 20-50% in susceptible varieties. Lentil is an important crop for Ethiopian agriculture, providing protein-rich food for domestic consumption and generating export earnings that support rural livelihoods. Rust is favored by moderate temperatures, high humidity, and dense crop canopies, conditions that are common in Ethiopian lentil-growing areas during parts of the growing season. The pathogen can also affect other legumes including faba bean and pea, making management in mixed cropping systems more complex. Management focuses on resistant varieties, cultural practices that reduce humidity, and targeted fungicide application in high-value production. Research on rust-resistant lentil varieties is ongoing through Ethiopian and international agricultural research programs.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Lentil%20rust.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Lentil%20rust.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Lentil%20rust.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/55928",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Ethiopia is one of the largest lentil producers in Africa; rust management critical for export quality."
        },
        {
            id: "PD035",
            name: "Teff Head Smut",
            localName: "",
            scientific: "Tilletia asperifolia",
            type: "disease",
            affectedCrops: ["Tef"],
            partsAffected: ["Seed/Grain", "Flower"],
            growthStage: ["Flowering", "Grain Filling"],
            description: "Teff head smut is a fungal disease caused by Tilletia asperifolia. The disease affects teff heads, replacing grains with black spore masses. It causes yield and quality losses in teff, Ethiopia's most important cereal crop.",
            symptoms: "Early: Infected plants may appear normal until flowering. Advanced: Grains replaced by black spore masses, black powdery material released at harvest, contaminated grain, reduced yield and quality, black dust during threshing.",
            favorableConditions: "Cool soil temperatures at planting, presence of soil-borne spores, infected seed, susceptible varieties, continuous teff cropping.",
            prevention: "Use certified disease-free seed, treat seed with fungicide, practice crop rotation, avoid continuous teff cropping.",
            culturalManagement: "Crop rotation with non-host crops, use clean seed, remove and destroy infected plants, field sanitation, balanced fertilization.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Seed treatment: Thiram, Mancozeb, Carboxin (applied as seed treatment before planting).",
            ethiopianDistribution: "Oromia — Reported presence; Amhara — Reported presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 10-30% reported, quality losses due to grain contamination.",
            detailedDescription: "Teff head smut, caused by the fungal pathogen Tilletia asperifolia, is a seed-borne disease affecting tef, Ethiopia's most important cereal crop. The disease replaces grains with black spore masses, reducing yield and contaminating grain at harvest. While teff has historically shown good tolerance to many diseases, head smut can cause significant losses in areas where seed treatment is not practiced and soil-borne inoculum has accumulated. Yield losses of 10-30% have been reported, with additional quality losses due to grain contamination. The disease is particularly important in teff-growing areas where farmers save seed from previous harvests without proper cleaning or treatment. The black spores released during threshing contaminate grain and can spread the disease to future crops. Management focuses on certified disease-free seed, seed treatment with fungicides, crop rotation, and field sanitation. The importance of teff to Ethiopian food culture and food security makes head smut management important for both productivity and grain quality.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Teff%20head%20smut.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Teff%20head%20smut.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Teff%20head%20smut.jpg",
            source: "Ethiopian Institute of Agricultural Research (EIAR)",
            sourceUrl: "https://www.eiar.gov.et/",
            pubDate: "2018",
            lastUpdated: "2021",
            notes: "Smut diseases are difficult to control once established in soil."
        },
        {
            id: "PD036",
            name: "Onion Neck Rot",
            localName: "",
            scientific: "Botrytis allii",
            type: "disease",
            affectedCrops: ["Onion", "Garlic"],
            partsAffected: ["Stem", "Seed/Grain"],
            growthStage: ["Maturity", "Post-harvest"],
            description: "Onion neck rot is a fungal disease caused by Botrytis allii. The disease primarily affects stored onions, causing rot at the neck (top) of bulbs. It causes significant post-harvest losses in onion storage.",
            symptoms: "Early: Water-soaked lesions at neck of bulb, slight softening. Advanced: Gray mold growth at neck, bulbs become soft and water-logged, internal rot, shriveling of bulbs, significant post-harvest losses during storage.",
            favorableConditions: "Cool temperatures (15-20°C), high humidity in storage, improper curing before storage, bulb injury at harvest, susceptible varieties.",
            prevention: "Cure bulbs properly before storage, avoid nitrogen excess, practice crop rotation, harvest during dry conditions.",
            culturalManagement: "Proper curing, store in well-ventilated containers, maintain low humidity in storage, avoid bruising bulbs at harvest, remove infected bulbs from storage.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Azoxystrobin, Boscalid (limited post-harvest efficacy; focus on proper curing and storage).",
            ethiopianDistribution: "Oromia — Reported presence; Amhara — Reported presence.",
            economicImpact: "Post-harvest losses of 20-40% reported in poor storage conditions, significant economic impact.",
            detailedDescription: "Onion neck rot, caused by the fungal pathogen Botrytis allii, is primarily a post-harvest disease that causes significant losses during onion storage. The disease develops at the neck (top) of bulbs, causing softening and gray mold growth that can spread to the entire bulb during storage. While infection occurs in the field, symptoms typically develop during storage, making the disease difficult to detect until losses have occurred. Onion is an increasingly important crop in Ethiopia, and post-harvest losses are particularly costly because they affect marketable product that has already incurred production costs. Post-harvest losses of 20-40% have been reported under poor storage conditions. The disease is favored by improper curing before storage, high humidity in storage, and bulb injury during harvest and handling. Management focuses on proper curing, well-ventilated storage, careful handling to avoid bruising, and removal of infected bulbs. Fungicide application has limited post-harvest efficacy, making cultural management the primary strategy.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20neck%20rot.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20neck%20rot.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20neck%20rot.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/9748",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Proper curing (drying) of onions before storage is the most important management practice."
        },
        {
            id: "PD037",
            name: "Tomato Fusarium Wilt",
            localName: "",
            scientific: "Fusarium oxysporum f. sp. lycopersici",
            type: "disease",
            affectedCrops: ["Tomato"],
            partsAffected: ["Stem", "Root", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Tomato fusarium wilt is a soil-borne fungal disease caused by Fusarium oxysporum f. sp. lycopersici. The pathogen enters through roots and colonizes the vascular system, causing wilting and plant death.",
            symptoms: "Early: Yellowing of lower leaves, wilting during hot periods, recovery at night. Advanced: Permanent wilting of whole plant, yellowing progressing upward, brown discoloration of vascular tissue (visible in stem cross-section), leaf death, plant death.",
            favorableConditions: "Warm soil temperatures (25-30°C), acidic soils, poor drainage, presence of root-knot nematodes, continuous tomato cropping, susceptible varieties.",
            prevention: "Plant resistant varieties (F1 hybrids with resistance genes), practice crop rotation (4-5 years), control nematode populations, avoid planting in infested fields.",
            culturalManagement: "Crop rotation with non-solanaceous crops, improve soil drainage, maintain balanced soil pH, control root-knot nematodes, field sanitation, solarization where possible.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, non-pathogenic Fusarium, Pseudomonas fluorescens (limited field efficacy, research ongoing).",
            chemicalManagement: "Soil fumigation with Metam sodium (restricted use, not recommended for smallholders); No effective chemical control once infection occurs.",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Reported presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 30-60% reported in infested fields, significant impact on tomato production.",
            detailedDescription: "Tomato fusarium wilt, caused by the soil-borne fungus Fusarium oxysporum f. sp. lycopersici, is a devastating disease affecting tomato production in warm growing regions including Ethiopia. The pathogen enters through roots, colonizes the vascular system, and causes wilting and plant death. What makes fusarium wilt particularly challenging is the pathogen's ability to survive in soil for many years as durable resting structures (chlamydospores), making infested fields unsuitable for susceptible tomato varieties for extended periods. The disease is favored by warm soil temperatures, acidic soils, poor drainage, and the presence of root-knot nematodes, which create entry points for the pathogen. In Ethiopia, tomato production is expanding to meet growing urban demand, and fusarium wilt represents a significant constraint, particularly in areas where tomatoes are grown repeatedly in the same soil. Yield losses of 30-60% have been reported in infested fields. Management integrates resistant varieties (commercial hybrids with resistance genes), crop rotation with non-solanaceous crops, nematode control, soil solarization, and biocontrol agents.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20Fusarium%20wilt.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20Fusarium%20wilt.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20Fusarium%20wilt.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/24623",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Resistance genes (I, I-2, I-3) available in commercial varieties; race structure varies by region."
        },
        {
            id: "PD038",
            name: "Maize Ear Rot",
            localName: "",
            scientific: "Fusarium verticillioides, Aspergillus flavus, Stenocarpella maydis",
            type: "disease",
            affectedCrops: ["Maize"],
            partsAffected: ["Seed/Grain", "Fruit"],
            growthStage: ["Grain Filling", "Maturity"],
            description: "Maize ear rot is caused by multiple fungal pathogens including Fusarium verticillioides, Aspergillus flavus, and Stenocarpella maydis. The disease affects maize ears, causing grain rot and contamination with mycotoxins.",
            symptoms: "Early: White or pink mold growth on kernels, scattered infected kernels. Advanced: Extensive mold on ears, kernel discoloration and shriveling, mycotoxin contamination (fumonisins, aflatoxins), poor grain quality, reduced marketability, health risks.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity during grain filling, insect damage to ears, drought stress, delayed harvest, susceptible varieties.",
            prevention: "Plant resistant varieties, practice crop rotation, control insect pests that damage ears, harvest promptly at maturity.",
            culturalManagement: "Crop rotation, proper plant spacing, balanced fertilization, control ear-feeding insects, harvest at correct moisture, proper drying and storage (maintain <13% moisture).",
            biologicalManagement: "Biocontrol agents: Atoxigenic Aspergillus strains (aflatoxin biocontrol, research ongoing in Africa).",
            chemicalManagement: "Fungicide application not economically feasible for ear rot control; focus on prevention and proper storage.",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported, mycotoxin contamination poses serious health risks.",
            detailedDescription: "Maize ear rot is caused by multiple fungal pathogens, primarily Fusarium verticillioides, Aspergillus flavus, and Stenocarpella maydis, which infect maize ears and contaminate grain with mycotoxins. The disease is particularly important in Ethiopia due to food safety concerns, as maize is a staple food for millions of people and mycotoxin contamination poses serious health risks. Fumonisins (produced by Fusarium) and aflatoxins (produced by Aspergillus) are the main mycotoxins of concern, with chronic exposure linked to liver cancer, stunting in children, and immune suppression. Ear rot is favored by insect damage to ears, drought stress, and delayed harvest, all of which are common in Ethiopian maize production systems. Yield losses of 20-50% have been reported, but the food safety implications are equally or more important than direct yield losses. Management focuses on resistant varieties, insect control to reduce ear damage, proper harvest timing, and critical post-harvest practices including proper drying and storage to prevent mycotoxin development. Research on aflatoxin biocontrol using non-toxigenic Aspergillus strains is ongoing in Africa.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20ear%20rot.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20ear%20rot.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20ear%20rot.jpg",
            source: "Corteva Agriscience (Pioneer)",
            sourceUrl: "https://www.pioneer.com/us/agronomy/ear_rot.html",
            pubDate: "2020",
            lastUpdated: "2021",
            notes: "Aflatoxin contamination is a major food safety concern in Ethiopia; proper drying and storage essential."
        },
        {
            id: "PD039",
            name: "Barley Loose Smut",
            localName: "",
            scientific: "Ustilago nuda",
            type: "disease",
            affectedCrops: ["Barley"],
            partsAffected: ["Seed/Grain", "Flower"],
            growthStage: ["Flowering", "Grain Filling"],
            description: "Barley loose smut is a fungal disease caused by Ustilago nuda. The disease is seed-borne and replaces grain with black spore masses. It causes yield losses and reduces grain quality.",
            symptoms: "Early: Infected plants may appear normal until heading. Advanced: Grains replaced by black spore masses (smut), black powdery material released by wind, contaminated grain, reduced yield and quality, smutted heads emerge from boot earlier than healthy heads.",
            favorableConditions: "Cool temperatures during flowering, infected seed, susceptible varieties, lack of seed treatment.",
            prevention: "Use certified disease-free seed, treat seed with fungicide, plant resistant varieties where available.",
            culturalManagement: "Use certified seed, seed treatment with systemic fungicides, crop rotation, remove infected heads before spore release.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Seed treatment: Carboxin, Tebuconazole, Triadimenol (applied as seed treatment; highly effective).",
            ethiopianDistribution: "Oromia — Reported presence; Amhara — Reported presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 10-40% reported in untreated seed, significant quality losses.",
            detailedDescription: "Barley loose smut, caused by the fungal pathogen Ustilago nuda, is a seed-borne disease that replaces grain with black spore masses. The fungus survives inside the embryo of infected seed and grows systemically within the plant, producing smutted heads that release spores to infect developing grains of healthy plants. Yield losses of 10-40% have been reported in untreated seed, with additional quality losses due to grain contamination. In Ethiopia, barley is an important crop for food, beverages, and increasingly for the malting industry, making loose smut management important for both productivity and quality. The disease is particularly problematic where farmers save seed without proper treatment, which is common in smallholder systems. Management is straightforward and highly effective: systemic seed treatment fungicides (carboxin, tebuconazole) kill the fungus inside the seed and provide complete control. The challenge is ensuring that smallholder farmers have access to treated seed or seed treatment products. Certified seed programs and farmer education are critical for loose smut management in Ethiopia.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20loose%20smut.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20loose%20smut.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Barley%20loose%20smut.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56070",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Systemic seed treatment fungicides are highly effective for loose smut control."
        },
        {
            id: "PD040",
            name: "Soybean Rust",
            localName: "",
            scientific: "Phakopsora pachyrhizi",
            type: "disease",
            affectedCrops: ["Soybean"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Soybean rust is a devastating fungal disease caused by Phakopsora pachyrhizi. The disease causes rapid defoliation and yield losses. It is considered one of the most destructive soybean diseases globally.",
            symptoms: "Early: Small yellow spots on leaves, grayish pustules on leaf undersides. Advanced: Numerous brown pustules on leaves, rapid leaf yellowing and drop, severe defoliation, reduced pod fill, shriveled seeds, significant yield losses.",
            favorableConditions: "Warm temperatures (20-28°C), high humidity, prolonged leaf wetness, susceptible varieties, continuous soybean cropping.",
            prevention: "Plant resistant varieties, practice crop rotation, avoid dense planting, monitor fields regularly.",
            culturalManagement: "Crop rotation with non-host crops, remove volunteer soybean plants, proper spacing, balanced fertilization, avoid late planting.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Azoxystrobin, Tebuconazole, Propiconazole, Mancozeb (applied preventatively and at early disease onset; rotation recommended).",
            ethiopianDistribution: "Oromia — Reported presence; Benishangul-Gumuz — Reported presence; Amhara — Reported presence.",
            economicImpact: "Yield losses of 30-80% reported in susceptible varieties during epidemic years.",
            detailedDescription: "Soybean rust, caused by the fungal pathogen Phakopsora pachyrhizi, is one of the most destructive diseases of soybean globally, capable of causing rapid defoliation and yield losses of 30-80% in susceptible varieties during epidemic years. The pathogen produces wind-blown spores that can travel long distances, enabling rapid spread across regions. Soybean production in Ethiopia is expanding as the crop gains importance for food, feed, and export markets, and rust represents a potential constraint to sustainable production. The disease is favored by warm temperatures, high humidity, and prolonged leaf wetness, conditions that are common in Ethiopia's humid lowland and mid-altitude soybean-growing areas. The rapid progression of the disease requires timely management responses, which can be challenging for smallholder farmers with limited access to fungicides and extension services. Management integrates resistant varieties, crop rotation, monitoring for early detection, and fungicide application when disease is detected. Research on soybean rust management in African production systems is ongoing through international agricultural research programs.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Soybean%20rust.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Soybean%20rust.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Soybean%20rust.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/40096",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Wind-blown spores can travel long distances; disease can spread rapidly across regions."
        },
        {
            id: "PD041",
            name: "Groundnut Early Leaf Spot",
            localName: "",
            scientific: "Cercospora arachidicola",
            type: "disease",
            affectedCrops: ["Groundnut"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Groundnut early leaf spot is a fungal disease caused by Cercospora arachidicola. The disease affects leaves and stems, reducing photosynthetic area and causing defoliation.",
            symptoms: "Early: Small circular brown spots on leaves, lesions with yellow halos. Advanced: Lesions coalesce, leaf yellowing and drop, severe defoliation, reduced pod fill, poor yield and quality, stems affected in severe cases.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, frequent rainfall, prolonged leaf wetness, susceptible varieties, continuous groundnut cropping.",
            prevention: "Plant resistant varieties, practice crop rotation, use certified disease-free seed, avoid continuous groundnut cropping.",
            culturalManagement: "Crop rotation with cereals, remove and destroy crop residues, proper spacing for air circulation, balanced fertilization.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Chlorothalonil, Mancozeb, Azoxystrobin (applied preventatively and at early disease onset).",
            ethiopianDistribution: "Oromia — Reported presence; Benishangul-Gumuz — Reported presence; Amhara — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported in susceptible varieties, significant impact on groundnut production.",
            detailedDescription: "Groundnut early leaf spot, caused by the fungal pathogen Cercospora arachidicola, is a significant disease affecting groundnut (peanut) production in warm, humid growing regions including Ethiopia. The disease produces circular brown lesions on leaves that cause premature defoliation, reducing photosynthetic capacity and pod fill. Yield losses of 20-50% have been reported in susceptible varieties. Groundnut is an important crop in Ethiopia for both food (roasted peanuts, peanut sauce) and income, particularly in western regions where conditions favor production. Early leaf spot is favored by warm temperatures, high humidity, and prolonged leaf wetness, and is particularly severe in continuous groundnut systems with high residue levels. The pathogen survives on crop residues and volunteer plants, making disease pressure higher where rotation is not practiced. Management integrates resistant varieties, crop rotation with cereals, residue management, and fungicide application in high-value production. The importance of groundnut to Ethiopia's agricultural economy and nutrition makes leaf spot management important for both productivity and food security.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Peanut%20early%20leaf%20spot.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Peanut%20early%20leaf%20spot.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Peanut%20early%20leaf%20spot.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/13522",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Both early and late leaf spot affect groundnut; early leaf spot appears earlier in season."
        },
        {
            id: "PD042",
            name: "Onion Purple Blotch",
            localName: "",
            scientific: "Alternaria porri",
            type: "disease",
            affectedCrops: ["Onion", "Garlic"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Onion purple blotch is a fungal disease caused by Alternaria porri. The disease causes characteristic purple lesions on leaves and can cause significant yield losses.",
            symptoms: "Early: Small water-soaked spots on leaves, developing into purple-brown lesions. Advanced: Large purple lesions with yellow halos, concentric rings in lesions, leaf death, reduced bulb development, poor bulb quality, premature leaf senescence.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, prolonged leaf wetness, dense canopy, susceptible varieties, plant stress.",
            prevention: "Plant resistant varieties, use certified disease-free bulbs, practice crop rotation, avoid dense planting.",
            culturalManagement: "Crop rotation with non-allium crops, remove and destroy crop residues, proper spacing for air circulation, avoid overhead irrigation, balanced fertilization.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Chlorothalonil, Mancozeb, Azoxystrobin, Copper-based fungicides (applied preventatively and at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Reported presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 30-60% reported in susceptible varieties, significant impact on onion production.",
            detailedDescription: "Onion purple blotch, caused by the fungal pathogen Alternaria porri, is a significant disease affecting onions in Ethiopia's expanding onion production systems. The disease produces characteristic purple lesions with concentric rings on leaves, reducing photosynthetic area and leading to premature leaf death and reduced bulb development. Yield losses of 30-60% have been reported in susceptible varieties under favorable conditions. Purple blotch is favored by warm temperatures, high humidity, and prolonged leaf wetness, and is particularly severe in dense canopies where air circulation is poor. The disease often follows other stresses such as downy mildew or thrips damage, highlighting the importance of integrated pest and disease management. Onion production in Ethiopia has expanded significantly in recent decades to meet growing urban demand, and disease management is critical for achieving sustainable productivity. Management integrates resistant varieties, crop rotation, cultural practices that reduce humidity, and fungicide application in high-value production.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20purple%20blotch.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20purple%20blotch.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Onion%20purple%20blotch.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/4519",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Purple blotch often follows onion downy mildew or thrips damage."
        },
        {
            id: "PD043",
            name: "Tomato Bacterial Wilt",
            localName: "",
            scientific: "Ralstonia solanacearum",
            type: "disease",
            affectedCrops: ["Tomato", "Potato", "Pepper"],
            partsAffected: ["Stem", "Root", "Whole Plant"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Tomato bacterial wilt is caused by the soil-borne bacterium Ralstonia solanacearum. The disease affects the vascular system, causing rapid wilting and death of plants.",
            symptoms: "Early: Wilting of upper leaves during hot periods, recovery at night. Advanced: Permanent wilting of entire plant, yellowing of leaves, brown discoloration of vascular tissue, bacterial ooze from cut stems, plant death.",
            favorableConditions: "Warm temperatures (25-35°C), high soil moisture, acidic soils, presence of nematodes, continuous cropping of susceptible hosts.",
            prevention: "Plant resistant varieties, use certified disease-free transplants, practice crop rotation, avoid planting in infested fields.",
            culturalManagement: "Crop rotation with non-host crops (3-5 years), improve soil drainage, maintain balanced soil pH, control nematode populations, field sanitation, remove and destroy infected plants.",
            biologicalManagement: "Biocontrol agents: Pseudomonas fluorescens, Bacillus species (limited field efficacy, research ongoing).",
            chemicalManagement: "No effective chemical control available; soil fumigation with Metam sodium (restricted use, not recommended for smallholders).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 30-100% reported in infested fields, severe impact on smallholder tomato production.",
            detailedDescription: "Tomato bacterial wilt, caused by the soil-borne bacterium Ralstonia solanacearum, is a devastating disease affecting tomato production in warm, humid growing regions including Ethiopia. The pathogen enters through roots, colonizes the vascular system, and causes rapid wilting and death of infected plants. What makes bacterial wilt particularly challenging is the pathogen's ability to survive in soil for many years, its extremely wide host range (over 200 plant species), and its capacity to spread through contaminated soil, water, and planting material. The disease is favored by warm soil temperatures, high soil moisture, and acidic soils, conditions that are common in Ethiopian tomato-growing areas. Yield losses of 30-100% have been reported in infested fields, with severe impacts on smallholder farmers who may lose entire crops. Management is extremely challenging because no effective chemical control exists, and crop rotation is difficult due to the pathogen's wide host range. Integrated management combines resistant varieties, certified disease-free transplants, long rotation with non-host crops (primarily cereals), improved drainage, and biocontrol agents.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20bacterial%20wilt.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20bacterial%20wilt.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Tomato%20bacterial%20wilt.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/46860",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Same pathogen as potato bacterial wilt; wide host range makes rotation challenging."
        },
        {
            id: "PD044",
            name: "Cabbage Black Rot",
            localName: "",
            scientific: "Xanthomonas campestris pv. campestris",
            type: "disease",
            affectedCrops: ["Cabbage", "Kale", "Other Brassicas"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Black rot is a bacterial disease caused by Xanthomonas campestris pv. campestris that affects cabbage and other brassica crops. The disease causes characteristic V-shaped lesions on leaves.",
            symptoms: "Early: Yellow V-shaped lesions at leaf margins, blackened veins. Advanced: Lesions expand along veins, black veins visible, leaf death, head rot, reduced head quality and marketability, secondary soft rot infections.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, prolonged leaf wetness, contaminated seed, overhead irrigation, susceptible varieties.",
            prevention: "Use certified disease-free seed, practice crop rotation (3-4 years), avoid overhead irrigation, plant resistant varieties where available.",
            culturalManagement: "Crop rotation with non-brassica crops, remove and destroy infected plants, field sanitation, avoid working in wet fields, proper spacing for air circulation.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Copper-based fungicides (limited efficacy); Hot water seed treatment (50°C for 25 minutes); No effective chemical control once infection occurs.",
            ethiopianDistribution: "Oromia — Reported presence; Amhara — Reported presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported, quality losses due to head damage.",
            detailedDescription: "Cabbage black rot, caused by the bacterium Xanthomonas campestris pv. campestris, is a significant disease affecting cabbage and other brassica crops in vegetable-growing regions including Ethiopia. The disease produces characteristic V-shaped yellow lesions at leaf margins with blackened veins, reducing yield and head quality. Black rot is seed-borne and spreads through water splash, contaminated tools, and overhead irrigation, making disease management challenging in intensive vegetable production systems. Yield losses of 20-50% have been reported, with additional quality losses due to head damage. Cabbage production in Ethiopia has expanded with growing urban demand, and black rot represents an important constraint to sustainable production. The disease is favored by warm temperatures, high humidity, and prolonged leaf wetness. Management focuses on certified disease-free seed, hot water seed treatment, crop rotation with non-brassica crops, cultural practices that reduce humidity and spread, and copper-based bactericide application where economically feasible.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cabbage%20black%20rot.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cabbage%20black%20rot.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cabbage%20black%20rot.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56923",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Seed-borne disease; use of clean seed and hot water treatment important for management."
        },
        {
            id: "PD045",
            name: "Potato Early Blight",
            localName: "",
            scientific: "Alternaria solani",
            type: "disease",
            affectedCrops: ["Potato", "Tomato"],
            partsAffected: ["Leaf", "Stem"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Potato early blight is a fungal disease caused by Alternaria solani. It affects leaves and stems, causing target-shaped lesions and premature defoliation. The disease reduces tuber yield.",
            symptoms: "Early: Small brown spots on older leaves, concentric rings in lesions. Advanced: Target-shaped lesions with concentric rings, leaf yellowing and death, stem lesions, premature defoliation, reduced tuber size and yield.",
            favorableConditions: "Warm temperatures (24-29°C), high humidity, frequent rainfall, plant stress, poor nutrition, susceptible varieties, prolonged leaf wetness.",
            prevention: "Plant resistant varieties, use certified disease-free seed tubers, practice crop rotation, avoid plant stress, maintain balanced nutrition.",
            culturalManagement: "Crop rotation with non-solanaceous crops, remove and destroy infected plant material, proper spacing for air circulation, balanced fertilization, avoid overhead irrigation.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, Bacillus subtilis (limited field efficacy, research ongoing).",
            chemicalManagement: "Fungicide application: Chlorothalonil, Mancozeb, Azoxystrobin (applied preventatively and at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 20-40% reported in susceptible varieties, significant impact on potato production.",
            detailedDescription: "Potato early blight, caused by the fungal pathogen Alternaria solani, is a common disease affecting potato production in Ethiopia and globally. The disease produces characteristic target-shaped lesions with concentric rings on leaves and stems, reducing photosynthetic area and tuber yield. Early blight is favored by warm temperatures, high humidity, and plant stress, and is particularly severe when plants are weakened by poor nutrition, water stress, or other diseases. Yield losses of 20-40% have been reported in susceptible varieties. In Ethiopia, potato is an important food and income crop, particularly in highland areas where conditions are favorable for production. Early blight is often less severe than late blight but can cause significant losses, especially in seasons with favorable conditions or when late blight management diverts attention from other diseases. Management integrates resistant varieties, crop rotation, cultural practices that reduce plant stress, and fungicide application in high-value production. The same pathogen also causes early blight of tomato, highlighting the importance of rotation between these solanaceous crops.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potato%20early%20blight.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potato%20early%20blight.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Potato%20early%20blight.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/4490",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Same pathogen as tomato early blight; affects both crops."
        },
        {
            id: "PD046",
            name: "Haricot Bean Common Bacterial Blight",
            localName: "",
            scientific: "Xanthomonas axonopodis pv. phaseoli",
            type: "disease",
            affectedCrops: ["Common Bean"],
            partsAffected: ["Leaf", "Stem", "Seed/Grain"],
            growthStage: ["Vegetative", "Flowering", "Fruiting"],
            description: "Common bacterial blight is a bacterial disease caused by Xanthomonas axonopodis pv. phaseoli affecting common beans. The disease causes leaf, stem, and pod lesions, reducing yield and quality.",
            symptoms: "Early: Water-soaked spots on leaves, yellow halos around lesions. Advanced: Brown necrotic lesions, leaf death, stem lesions, pod lesions with seed infection, seed discoloration, reduced yield and quality.",
            favorableConditions: "Warm temperatures (25-30°C), high humidity, frequent rainfall, overhead irrigation, contaminated seed, susceptible varieties.",
            prevention: "Use certified disease-free seed, practice crop rotation, avoid overhead irrigation, plant resistant varieties where available.",
            culturalManagement: "Crop rotation with non-legume crops, remove and destroy infected plants, proper spacing for air circulation, field sanitation, avoid working in wet fields.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Seed treatment: Copper-based compounds; Foliar application: Copper-based fungicides (limited efficacy).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Reported presence; SNNPR — Reported presence.",
            economicImpact: "Yield losses of 20-40% reported, significant impact on bean production and quality.",
            detailedDescription: "Common bacterial blight, caused by Xanthomonas axonopodis pv. phaseoli, is a significant disease affecting common beans (haricot beans) in Ethiopia, where beans are a major source of dietary protein and an important export crop. The disease produces water-soaked spots that develop into brown necrotic lesions on leaves, stems, and pods, reducing yield and seed quality. The pathogen is seed-borne and spreads through water splash, making disease management challenging in humid growing conditions. Yield losses of 20-40% have been reported in susceptible varieties, with additional quality losses due to seed discoloration. Ethiopia is one of Africa's largest producers and exporters of common beans, with white pea beans being particularly important for export markets. The quality requirements of export markets make disease management critical, as diseased beans are downgraded or rejected. Management focuses on certified disease-free seed, crop rotation with non-legume crops, cultural practices that reduce humidity and spread, and copper-based bactericide application where economically feasible.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Bean%20common%20bacterial%20blight.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Bean%20common%20bacterial%20blight.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Bean%20common%20bacterial%20blight.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56956",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Seed-borne disease; clean seed is critical for management."
        },
        {
            id: "PD047",
            name: "Maize Common Smut",
            localName: "",
            scientific: "Ustilago maydis",
            type: "disease",
            affectedCrops: ["Maize"],
            partsAffected: ["Seed/Grain", "Flower", "Stem", "Leaf"],
            growthStage: ["Vegetative", "Flowering", "Grain Filling"],
            description: "Maize common smut is a fungal disease caused by Ustilago maydis. The disease causes large galls (tumors) on ears, stems, and leaves. While considered a delicacy in some cultures, it causes yield and quality losses.",
            symptoms: "Early: Small white to gray swellings on plant parts. Advanced: Large galls filled with black spore mass, galls on ears, stems, and leaves, ear deformation, reduced yield and quality, black spores released at maturity.",
            favorableConditions: "Moderate temperatures (26-34°C), plant injury (hail, insect damage), high soil nitrogen, susceptible varieties, dry conditions followed by wet periods.",
            prevention: "Plant resistant varieties, avoid mechanical damage, balanced fertilization (avoid excess nitrogen), practice crop rotation.",
            culturalManagement: "Crop rotation, remove and destroy galls before spore release, balanced fertilization, avoid mechanical injury during cultivation.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "No effective chemical control; focus on prevention and cultural management.",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Benishangul-Gumuz — Reported presence.",
            economicImpact: "Yield losses of 10-30% reported in susceptible varieties, quality losses due to ear deformation.",
            detailedDescription: "Maize common smut, caused by the fungal pathogen Ustilago maydis, is a distinctive disease that produces large galls (tumors) on maize ears, stems, and leaves. While the galls are considered a delicacy (huitlacoche) in Mexican cuisine and can be more valuable than maize itself in some markets, the disease generally causes yield and quality losses in commercial maize production. Yield losses of 10-30% have been reported in susceptible varieties, with additional quality losses due to ear deformation. Common smut is favored by plant injury (from hail, insects, or mechanical damage), high soil nitrogen, and dry conditions followed by wet periods. In Ethiopia, maize is the most important cereal crop, and common smut is present in maize-growing regions, though it typically causes less damage than other diseases like gray leaf spot or northern leaf blight. The pathogen survives in soil for years, making crop rotation less effective than for other diseases. Management focuses on resistant varieties, avoiding mechanical injury during cultivation, balanced fertilization, and removal of galls before spore release.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20common%20smut.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20common%20smut.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Maize%20common%20smut.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56068",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Galls (huitlacoche) are considered a delicacy in Mexican cuisine; spores can survive in soil for years."
        },
        {
            id: "PD048",
            name: "Wheat Septoria Leaf Blotch",
            localName: "",
            scientific: "Zymoseptoria tritici (Septoria tritici)",
            type: "disease",
            affectedCrops: ["Wheat"],
            partsAffected: ["Leaf"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Septoria leaf blotch is a fungal disease caused by Zymoseptoria tritici. The disease causes characteristic lesions on wheat leaves and can cause significant yield losses.",
            symptoms: "Early: Small chlorotic spots on leaves, developing into brown lesions. Advanced: Irregular brown lesions with black specks (pycnidia), leaf yellowing and death, premature senescence, reduced grain filling, shriveled grains.",
            favorableConditions: "Cool temperatures (15-20°C), high humidity, prolonged leaf wetness, frequent rainfall, susceptible varieties, dense canopy.",
            prevention: "Plant resistant varieties, practice crop rotation, avoid dense planting, use certified disease-free seed.",
            culturalManagement: "Crop rotation, remove and incorporate crop residues, proper spacing for air circulation, balanced fertilization, avoid excessive nitrogen.",
            biologicalManagement: "Not available from verified source.",
            chemicalManagement: "Fungicide application: Azoxystrobin, Propiconazole, Tebuconazole (applied preventatively and at early disease onset).",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 20-50% reported in susceptible varieties, significant in high-rainfall wheat areas.",
            detailedDescription: "Septoria leaf blotch, caused by the fungal pathogen Zymoseptoria tritici (formerly Septoria tritici), is an important disease of wheat in cool, humid growing regions including the Ethiopian highlands. The disease produces irregular brown lesions with black specks (pycnidia) on leaves, reducing photosynthetic area and causing premature senescence. Yield losses of 20-50% have been reported in susceptible varieties under favorable conditions. Septoria is favored by cool temperatures, high humidity, and prolonged leaf wetness, conditions that are common in Ethiopian highland wheat-growing areas. The pathogen has a long latent period (14-28 days) between infection and symptom development, making early detection and timely management difficult. The pathogen survives on crop residues, making disease pressure higher in continuous wheat systems with limited residue management. Management integrates resistant varieties, crop rotation, residue management, and fungicide application in high-value production. The importance of wheat to Ethiopian food security makes Septoria management a priority for sustainable production.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Septoria%20leaf%20blotch%20of%20wheat.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Septoria%20leaf%20blotch%20of%20wheat.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Septoria%20leaf%20blotch%20of%20wheat.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/56757",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "Pathogen has long latent period (14-28 days); symptoms may appear long after infection."
        },
        {
            id: "PD049",
            name: "Chickpea Fusarium Wilt",
            localName: "",
            scientific: "Fusarium oxysporum f. sp. ciceris",
            type: "disease",
            affectedCrops: ["Chickpea"],
            partsAffected: ["Root", "Stem", "Whole Plant"],
            growthStage: ["Seedling", "Vegetative", "Flowering"],
            description: "Chickpea fusarium wilt is a soil-borne fungal disease caused by Fusarium oxysporum f. sp. ciceris. The disease causes vascular wilt and plant death, and can persist in soil for many years.",
            symptoms: "Early: Yellowing of lower leaves, wilting during hot periods. Advanced: Brown discoloration of vascular tissue, permanent wilting, leaf death, plant death, scattered dead plants in field.",
            favorableConditions: "Warm soil temperatures (25-30°C), acidic soils, poor drainage, presence of nematodes, continuous chickpea cropping, susceptible varieties.",
            prevention: "Plant resistant varieties, practice crop rotation (4-6 years), use certified disease-free seed, avoid planting in infested fields.",
            culturalManagement: "Crop rotation with cereals, improve soil drainage, maintain balanced soil pH, control nematode populations, field sanitation, solarization where possible.",
            biologicalManagement: "Biocontrol agents: Trichoderma species, Pseudomonas fluorescens, non-pathogenic Fusarium (limited field efficacy, research ongoing).",
            chemicalManagement: "Seed treatment: Carbendazim, Thiram; No effective chemical control once infection occurs.",
            ethiopianDistribution: "Oromia — Confirmed presence; Amhara — Confirmed presence; Tigray — Reported presence.",
            economicImpact: "Yield losses of 30-80% reported in infested fields, major constraint to chickpea production.",
            detailedDescription: "Chickpea fusarium wilt, caused by the soil-borne fungus Fusarium oxysporum f. sp. ciceris, is a devastating disease affecting chickpea production in Ethiopia and globally. The pathogen enters through roots, colonizes the vascular system, and causes wilting and plant death. The disease is particularly severe in warm growing areas, where soil temperatures favor pathogen activity. Yield losses of 30-80% have been reported in infested fields, with severe impacts on smallholder farmers. Ethiopia is one of Africa's largest chickpea producers and exporters, with the crop being particularly important in the highlands where it is grown in rotation with cereals and provides both food and income. The pathogen survives in soil for many years as durable resting structures, making infested fields unsuitable for susceptible chickpea varieties for extended periods. Multiple races of the pathogen exist, complicating resistance breeding. Management integrates resistant varieties, long crop rotation with cereals, improved drainage, and biocontrol agents. Research on resistant varieties adapted to Ethiopian conditions is ongoing through national and international agricultural research programs.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chickpea%20Fusarium%20wilt.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chickpea%20Fusarium%20wilt.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chickpea%20Fusarium%20wilt.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/24619",
            pubDate: "2019",
            lastUpdated: "2021",
            notes: "Multiple races exist; race structure varies by region and affects resistance breeding."
        },
        {
            id: "PD050",
            name: "Cassava Mosaic Disease",
            localName: "",
            scientific: "African cassava mosaic virus (ACMV) and East African cassava mosaic virus (EACMV)",
            type: "disease",
            affectedCrops: ["Cassava"],
            partsAffected: ["Leaf", "Whole Plant", "Root"],
            growthStage: ["Vegetative", "Flowering"],
            description: "Cassava mosaic disease is a devastating viral disease complex caused by geminiviruses and transmitted by whiteflies. It causes leaf distortion, stunting, and severe yield losses in cassava.",
            symptoms: "Early: Yellow mosaic pattern on leaves, leaf distortion. Advanced: Severe leaf distortion and curling, stunted growth, reduced root yield, poor root quality, complete crop failure in susceptible varieties.",
            favorableConditions: "Presence of whitefly vectors (Bemisia tabaci), use of infected planting material (cuttings), continuous cassava cropping, susceptible varieties, warm conditions favoring whitefly activity.",
            prevention: "Use virus-free planting material (tissue culture or certified cuttings), plant resistant varieties, control whitefly vectors, practice crop rotation.",
            culturalManagement: "Crop rotation, remove and destroy infected plants, use healthy planting material from reliable sources, control whitefly populations, field sanitation.",
            biologicalManagement: "Biological control of whitefly vectors using natural enemies (Encarsia species, predatory mites).",
            chemicalManagement: "No chemical control for virus; insecticide application for vector control: Imidacloprid, Thiamethoxam (limited efficacy).",
            ethiopianDistribution: "SNNPR — Confirmed presence; Gambella — Reported presence; Oromia — Reported presence.",
            economicImpact: "Yield losses of 50-90% reported in susceptible varieties, significant impact on food security.",
            detailedDescription: "Cassava mosaic disease (CMD) is a devastating viral disease complex caused by geminiviruses (primarily African cassava mosaic virus and East African cassava mosaic virus) and transmitted by whiteflies. The disease causes leaf distortion, stunting, and severe yield losses, and has caused major food insecurity in East and Central Africa during pandemic outbreaks. In Ethiopia, cassava is an emerging food security crop, particularly in southern and southwestern regions, and CMD poses a threat to sustainable production. The disease is transmitted by whiteflies and through infected planting material (cuttings), making it difficult to manage in smallholder systems where farmers typically save planting material from previous crops. Yield losses of 50-90% have been reported in susceptible varieties during epidemics. The pandemic that swept through East and Central Africa in the 1990s-2000s demonstrated the devastating potential of CMD, causing widespread food shortages and economic losses. Management focuses on virus-free planting material (produced through tissue culture or certified programs), resistant varieties, and control of whitefly vectors. Research on CMD management in Ethiopian production systems is ongoing through national and international agricultural research programs.",
            image1: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cassava%20mosaic%20disease.jpg",
            image2: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cassava%20mosaic%20disease.jpg",
            image3: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cassava%20mosaic%20disease.jpg",
            source: "CABI (Centre for Agriculture and Bioscience International)",
            sourceUrl: "https://www.cabi.org/isc/datasheet/17988",
            pubDate: "2019",
            lastUpdated: "2022",
            notes: "CMD pandemic in East and Central Africa caused severe food insecurity in 1990s-2000s."
        }
    ];

    // ----- 2. DOM REFS -----
    const grid = document.getElementById('libraryGrid');
    const emptyState = document.getElementById('emptyState');
    const resultCount = document.getElementById('resultCount');
    const searchInput = document.getElementById('pdlSearch');
    const searchBtn = document.getElementById('searchBtn');
    const filterToggle = document.getElementById('filterToggle');
    const filterPanel = document.getElementById('filterPanel');
    const filterClose = document.getElementById('filterClose');
    const clearFiltersBtn = document.getElementById('clearFilters');
    const detailView = document.getElementById('pdlDetail');
    const detailContent = document.getElementById('detailContent');
    const detailBack = document.getElementById('detailBack');

    // ----- 3. STATE -----
    let currentType = 'all';
    let currentCrop = 'all';
    let currentFilterType = 'all';
    let searchQuery = '';
    let selectedEntry = null;

    // ----- 4. FILTER FUNCTIONS -----
    function getFilteredEntries() {
        let filtered = entries;

        // Type filter (from quick buttons)
        if (currentType !== 'all') {
            filtered = filtered.filter(e => e.type === currentType);
        }

        // Type filter (from filter panel)
        if (currentFilterType !== 'all') {
            filtered = filtered.filter(e => e.type === currentFilterType);
        }

        // Crop filter
        if (currentCrop !== 'all') {
            filtered = filtered.filter(e =>
                e.affectedCrops.some(c => c.toLowerCase() === currentCrop)
            );
        }

        // Search filter
        if (searchQuery.trim() !== '') {
            const query = searchQuery.toLowerCase().trim();
            filtered = filtered.filter(e =>
                e.name.toLowerCase().includes(query) ||
                e.scientific.toLowerCase().includes(query) ||
                e.affectedCrops.some(c => c.toLowerCase().includes(query)) ||
                e.description.toLowerCase().includes(query)
            );
        }

        return filtered;
    }

    // ----- 5. RENDER CARDS -----
    function renderCards() {
        const filtered = getFilteredEntries();

        if (filtered.length === 0) {
            grid.innerHTML = '';
            emptyState.style.display = 'block';
            resultCount.textContent = '0 entries';
            return;
        }

        emptyState.style.display = 'none';
        resultCount.textContent = `${filtered.length} entries`;

        grid.innerHTML = '';
        filtered.forEach(entry => {
            const card = document.createElement('div');
            card.className = 'pest-card';

            const image = entry.image1 || 'https://via.placeholder.com/400x160/e0e4e0/7a8f7a?text=No+Image';

            card.innerHTML = `
                <div class="card-image" style="background-image: url('${image}');"></div>
                <div class="card-body">
                    <span class="card-type ${entry.type}">${entry.type}</span>
                    <div class="card-name">${entry.name}</div>
                    <div class="card-crop">Affects: ${entry.affectedCrops.join(', ')}</div>
                    <div class="card-desc">${entry.description.substring(0, 100)}${entry.description.length > 100 ? '...' : ''}</div>
                    <button class="card-btn" data-id="${entry.id}">View Details</button>
                </div>
            `;

            const btn = card.querySelector('.card-btn');
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const id = this.dataset.id;
                showDetail(id);
            });

            card.addEventListener('click', function() {
                const id = this.querySelector('.card-btn').dataset.id;
                showDetail(id);
            });

            grid.appendChild(card);
        });
    }

    // ----- 6. SHOW DETAIL -----
    function showDetail(id) {
        const entry = entries.find(e => e.id === id);
        if (!entry) return;

        selectedEntry = entry;

        const image = entry.image1 || 'https://via.placeholder.com/400x220/e0e4e0/7a8f7a?text=No+Image';

        // Build symptoms as list
        const symptomsList = entry.symptoms.split('.').filter(s => s.trim()).map(s => `<li>${s.trim()}.</li>`).join('');

        // Build management sections
        let managementHTML = '';
        if (entry.culturalManagement && entry.culturalManagement !== 'Not available from verified source.') {
            managementHTML += `
                <div class="detail-section">
                    <h4>Cultural Management</h4>
                    <p>${entry.culturalManagement}</p>
                </div>
            `;
        }
        if (entry.biologicalManagement && entry.biologicalManagement !== 'Not available from verified source.') {
            managementHTML += `
                <div class="detail-section">
                    <h4>Biological Management</h4>
                    <p>${entry.biologicalManagement}</p>
                </div>
            `;
        }
        if (entry.chemicalManagement && entry.chemicalManagement !== 'No verified chemical management information available for the viral complex; insecticide application for vector management only.') {
            managementHTML += `
                <div class="detail-section">
                    <h4>Chemical Management</h4>
                    <p>${entry.chemicalManagement}</p>
                </div>
            `;
        }

        // Use detailedDescription if available, otherwise use description
        const fullDescription = entry.detailedDescription || entry.description;

        detailContent.innerHTML = `
            <div class="detail-header-section">
                <div class="detail-image" style="background-image: url('${image}');"></div>
                <div class="detail-info">
                    <span class="detail-type ${entry.type}">${entry.type}</span>
                    <h2>${entry.name}</h2>
                    ${entry.scientific ? `<div class="detail-scientific">${entry.scientific}</div>` : ''}
                    <div class="detail-crops"><strong>Affected Crops:</strong> ${entry.affectedCrops.join(', ')}</div>
                    ${entry.localName ? `<div class="detail-crops"><strong>Local Name:</strong> ${entry.localName}</div>` : ''}
                    <div class="detail-crops"><strong>Plant Parts Affected:</strong> ${entry.partsAffected.join(', ')}</div>
                    ${entry.growthStage ? `<div class="detail-crops"><strong>Growth Stage:</strong> ${entry.growthStage.join(', ')}</div>` : ''}
                </div>
            </div>

            <div class="detail-sections">
                <div class="detail-section full">
                    <h4>Description</h4>
                    <p>${fullDescription}</p>
                </div>

                <div class="detail-section full">
                    <h4>Symptoms</h4>
                    <ul>${symptomsList}</ul>
                </div>

                ${entry.favorableConditions ? `
                <div class="detail-section">
                    <h4>Favorable Conditions</h4>
                    <p>${entry.favorableConditions}</p>
                </div>
                ` : ''}

                ${entry.prevention ? `
                <div class="detail-section">
                    <h4>Prevention</h4>
                    <p>${entry.prevention}</p>
                </div>
                ` : ''}

                ${managementHTML}

                ${entry.ethiopianDistribution ? `
                <div class="detail-section full">
                    <h4>Distribution in Ethiopia</h4>
                    <p>${entry.ethiopianDistribution}</p>
                </div>
                ` : ''}

                ${entry.economicImpact ? `
                <div class="detail-section">
                    <h4>Economic Impact</h4>
                    <p>${entry.economicImpact}</p>
                </div>
                ` : ''}

                <div class="detail-section full">
                    <h4>Information Source</h4>
                    <div class="source">
                        <p><strong>Source:</strong> ${entry.source}</p>
                        ${entry.sourceUrl ? `<p><strong>URL:</strong> <a href="${entry.sourceUrl}" target="_blank">${entry.sourceUrl}</a></p>` : ''}
                        ${entry.pubDate ? `<p><strong>Publication Date:</strong> ${entry.pubDate}</p>` : ''}
                        ${entry.lastUpdated ? `<p><strong>Last Updated:</strong> ${entry.lastUpdated}</p>` : ''}
                        ${entry.notes ? `<p><strong>Notes:</strong> ${entry.notes}</p>` : ''}
                    </div>
                </div>
            </div>

            <div class="detail-disclaimer">
                <p><strong>Educational Disclaimer:</strong> This information is provided for agricultural education and reference. Accurate field diagnosis may require qualified agricultural or plant-health expertise.</p>
            </div>
        `;

        detailView.style.display = 'block';
        detailView.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // ----- 7. BACK TO LIBRARY -----
    function backToLibrary() {
        detailView.style.display = 'none';
        selectedEntry = null;
        renderCards();
        document.querySelector('.pdl-library').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    detailBack.addEventListener('click', backToLibrary);

    // ----- 8. QUICK SELECTION -----
    document.querySelectorAll('.quick-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.quick-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentType = this.dataset.type;
            // Sync filter panel
            document.querySelectorAll('#typeFilters .filter-tag').forEach(t => {
                t.classList.toggle('active', t.dataset.type === currentType);
            });
            currentFilterType = currentType;
            renderCards();
        });
    });

    // ----- 9. FILTER PANEL -----
    filterToggle.addEventListener('click', function() {
        filterPanel.classList.toggle('open');
    });

    filterClose.addEventListener('click', function() {
        filterPanel.classList.remove('open');
    });

    // Crop filter tags
    document.querySelectorAll('#cropFilters .filter-tag').forEach(tag => {
        tag.addEventListener('click', function() {
            document.querySelectorAll('#cropFilters .filter-tag').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            currentCrop = this.dataset.crop;
            renderCards();
        });
    });

    // Type filter tags (in panel)
    document.querySelectorAll('#typeFilters .filter-tag').forEach(tag => {
        tag.addEventListener('click', function() {
            document.querySelectorAll('#typeFilters .filter-tag').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            currentFilterType = this.dataset.type;
            // Sync quick buttons
            document.querySelectorAll('.quick-btn').forEach(b => {
                b.classList.toggle('active', b.dataset.type === currentFilterType);
            });
            currentType = currentFilterType;
            renderCards();
        });
    });

    // ----- 10. CLEAR FILTERS -----
    clearFiltersBtn.addEventListener('click', function() {
        currentType = 'all';
        currentCrop = 'all';
        currentFilterType = 'all';
        searchQuery = '';
        searchInput.value = '';

        document.querySelectorAll('.quick-btn').forEach(b => b.classList.toggle('active', b.dataset.type === 'all'));
        document.querySelectorAll('#cropFilters .filter-tag').forEach(t => t.classList.toggle('active', t.dataset.crop === 'all'));
        document.querySelectorAll('#typeFilters .filter-tag').forEach(t => t.classList.toggle('active', t.dataset.type === 'all'));

        renderCards();
        filterPanel.classList.remove('open');
    });

    // ----- 11. SEARCH -----
    function performSearch() {
        searchQuery = searchInput.value;
        renderCards();
    }

    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });

    // ----- 12. INITIALIZE -----
    renderCards();

    console.log('🌿 Pest & Disease Library loaded successfully!');
    console.log(`📄 Total entries: ${entries.length}`);

})();