/**
 * AgriNova — Agriculture News
 * Full articles with image, opens in new page
 */

// ============================================================
// 1. CONFIGURATION
// ============================================================

const CONFIG = {
    NEWS_API_URL: 'https://api.thenewsapi.com/v1/news/top',
    FALLBACK_URL: 'https://api.thenewsapi.com/v1/news/all'
};

// ============================================================
// 2. APPLICATION STATE
// ============================================================

const state = {
    news: [],
    filtered: [],
    currentPage: 1,
    loading: false,
    hasMore: true,
    totalItems: 0,
    activeFilters: {
        categories: [],
        crops: [],
        locations: []
    },
    searchTerm: ''
};

// ============================================================
// 3. DOM REFERENCES
// ============================================================

const dom = {
    grid: document.getElementById('newsGrid'),
    search: document.getElementById('searchInput'),
    resultsCount: document.getElementById('resultsCount'),
    filterToggle: document.getElementById('filterToggleBtn'),
    filterPanel: document.getElementById('filterPanel'),
    filterCount: document.getElementById('filterCount'),
    clearFilters: document.getElementById('clearFiltersBtn'),
    applyFilters: document.getElementById('applyFiltersBtn'),
    categoryFilterOptions: document.getElementById('categoryFilterOptions'),
    cropFilterOptions: document.getElementById('cropFilterOptions'),
    locationFilterOptions: document.getElementById('locationFilterOptions'),
    loadingState: document.getElementById('loadingState'),
    errorState: document.getElementById('errorState'),
    errorDetail: document.getElementById('errorDetail'),
    emptyState: document.getElementById('emptyState'),
    retryBtn: document.getElementById('retryBtn'),
    refreshBtn: document.getElementById('refreshBtn'),
    loadMoreContainer: document.getElementById('loadMoreContainer'),
    loadMoreBtn: document.getElementById('loadMoreBtn')
};

// ============================================================
// 4. API FUNCTIONS
// ============================================================

async function fetchNewsFromAPI(page = 1, searchQuery = '') {
    const itemsPerPage = 15;
    const offset = (page - 1) * itemsPerPage;
    
    try {
        const url = `${CONFIG.NEWS_API_URL}?locale=et&categories=agriculture,agribusiness,farming&limit=${itemsPerPage}`;
        const response = await fetch(url);
        
        if (response.ok) {
            const data = await response.json();
            if (data && data.data && data.data.length > 0) {
                const articles = data.data.map((article, index) => {
                    const text = (article.title || '') + ' ' + (article.description || '');
                    const crops = extractCrops(text);
                    const location = extractLocation(article);
                    const category = extractCategory(article);
                    
                    // Build full content from available data
                    let fullContent = article.description || '';
                    if (article.snippet) fullContent += ' ' + article.snippet;
                    if (article.body) fullContent = article.body;
                    
                    return {
                        id: `AN${String(index + 1).padStart(3, '0')}`,
                        title: article.title || 'Agriculture News Update',
                        summary: article.description || article.snippet || 'Read the full article for more details.',
                        fullContent: fullContent || article.description || article.snippet || 'Full article content available at the source.',
                        category: category,
                        crops: crops,
                        location: location,
                        date: article.published_at || article.date || new Date().toISOString(),
                        source: article.source || article.source_name || 'News Source',
                        sourceName: article.source || article.source_name || 'News Source',
                        sourceUrl: article.url || article.source_url || '#',
                        image: article.image_url || article.image || null,
                        url: article.url || article.source_url || '#'
                    };
                });
                
                return {
                    articles: articles,
                    total: data.meta?.found || articles.length,
                    hasMore: articles.length >= itemsPerPage
                };
            }
        }
    } catch (error) {
        console.warn('API fetch failed:', error);
    }
    
    // Fallback to sample data
    return getSampleNewsData(page);
}

function getSampleNewsData(page) {
    const allArticles = [
        {
            id: 'AN001',
            title: 'Ethiopian Farmers Embrace Climate-Smart Agriculture',
            summary: 'Farmers across Ethiopia are adopting climate-smart agricultural practices to improve crop yields and build resilience against climate change.',
            fullContent: 'Farmers across Ethiopia are adopting climate-smart agricultural practices to improve crop yields and build resilience against climate change. The initiative, supported by the Ethiopian Ministry of Agriculture and the FAO, focuses on sustainable farming techniques including conservation agriculture, agroforestry, and improved water management. Over 500,000 farmers have been trained in the past year, with early results showing yield increases of 20-30% in participating communities. The program also promotes the use of drought-resistant crop varieties and improved soil conservation methods.',
            category: 'Climate & Agriculture',
            crops: ['Teff', 'Wheat', 'Maize'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800',
            url: '#'
        },
        {
            id: 'AN002',
            title: 'Teff Production Increases with New Fertilizer Program',
            summary: 'The Ethiopian Agricultural Transformation Agency reports a significant increase in Teff production following the introduction of a new fertilizer program.',
            fullContent: 'The Ethiopian Agricultural Transformation Agency reports a significant increase in Teff production following the introduction of a new fertilizer program. Farmers in Oromia and Amhara regions have seen yield improvements of up to 30% after adopting the recommended NPSB fertilizer blends. The program, which began in 2025, has distributed over 2 million bags of fertilizer to smallholder farmers. Early harvest reports indicate that average Teff yields have increased from 1.2 tons per hectare to 1.6 tons per hectare, with some farmers achieving over 2 tons per hectare.',
            category: 'Crop Production',
            crops: ['Teff'],
            location: 'Oromia, Ethiopia',
            date: new Date().toISOString(),
            source: 'ATA Ethiopia',
            sourceName: 'ATA Ethiopia',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1590090269573-a741d6bea6ef?w=800',
            url: '#'
        },
        {
            id: 'AN003',
            title: 'Ethiopia Launches National Irrigation Development Program',
            summary: 'The Ethiopian government has launched a comprehensive irrigation development program aimed at expanding irrigated agriculture across the country.',
            fullContent: 'The Ethiopian government has launched a comprehensive irrigation development program aimed at expanding irrigated agriculture across the country. The program targets 5 million hectares of new irrigated land by 2030, focusing on small-scale irrigation schemes and modern water management technologies. The initiative includes the construction of new dams, rehabilitation of existing irrigation infrastructure, and training for farmers on efficient water use. Over 50,000 farmers have already been connected to irrigation systems in the first phase of the program, with an additional 100,000 expected to benefit by 2027.',
            category: 'Irrigation',
            crops: ['Maize', 'Wheat', 'Vegetables'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1573995101240-cb37b974802c?w=800',
            url: '#'
        },
        {
            id: 'AN004',
            title: 'Coffee Farmers in Ethiopia Benefit from EU Partnership',
            summary: 'Ethiopian coffee farmers are benefiting from a new partnership with the European Union aimed at improving coffee quality and accessing premium markets.',
            fullContent: 'Ethiopian coffee farmers are benefiting from a new partnership with the European Union aimed at improving coffee quality and accessing premium markets. The program provides training and certification for sustainable coffee production, with a focus on organic farming and fair trade standards. Over 10,000 coffee farmers have been certified under the program, gaining access to premium coffee markets in Europe and North America. The initiative also includes support for coffee processing facilities and improved drying techniques to enhance bean quality. Early results show that certified farmers are receiving 40% higher prices for their coffee.',
            category: 'Agricultural Trade',
            crops: ['Coffee'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'FAO',
            sourceName: 'FAO',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=800',
            url: '#'
        },
        {
            id: 'AN005',
            title: 'Drought Preparedness Program Launched in Somali Region',
            summary: 'The Ethiopian Disaster Risk Management Commission has launched a drought preparedness program in the Somali Region.',
            fullContent: 'The Ethiopian Disaster Risk Management Commission has launched a drought preparedness program in the Somali Region. The initiative aims to protect livestock and ensure food security for pastoral communities through early warning systems, water conservation, and emergency feed distribution. Over 200,000 pastoralists are expected to benefit from the program, which includes training on drought-resistant livestock management and sustainable grazing practices. The program also establishes emergency water points and hay reserves in strategic locations to support communities during dry seasons.',
            category: 'Climate & Agriculture',
            crops: ['Sorghum', 'Livestock'],
            location: 'Somali Region, Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Disaster Risk Management Commission',
            sourceName: 'Ethiopian Disaster Risk Management Commission',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1598503176737-70af76232a9e?w=800',
            url: '#'
        },
        {
            id: 'AN006',
            title: 'Agricultural Technology Innovation Hub Opens in Addis Ababa',
            summary: 'A new agricultural technology innovation hub has opened in Addis Ababa, bringing together startups, researchers, and farmers.',
            fullContent: 'A new agricultural technology innovation hub has opened in Addis Ababa, bringing together startups, researchers, and farmers to develop digital solutions for Ethiopian agriculture. The hub, supported by the Ethiopian government and international partners, provides co-working space, mentorship, and funding for agtech startups. Early projects include a mobile app for pest identification, a satellite-based crop monitoring system, and a digital marketplace connecting farmers with buyers. The hub aims to incubate 100 agtech startups by 2030 and create digital jobs for young Ethiopians in the agricultural sector.',
            category: 'Agricultural Technology',
            crops: ['Maize', 'Wheat', 'Coffee'],
            location: 'Addis Ababa, Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1574726100531-e7dfd0ca80e6?w=800',
            url: '#'
        },
        {
            id: 'AN007',
            title: 'Ethiopia and IFAD Launch Rural Development Project',
            summary: 'The International Fund for Agricultural Development (IFAD) has launched a new rural development project in Ethiopia.',
            fullContent: 'The International Fund for Agricultural Development (IFAD) has launched a new rural development project in Ethiopia focused on improving agricultural productivity and market access for smallholder farmers. The $200 million project targets 500,000 rural households across 150 districts. Activities include farmer training, provision of improved seeds and tools, and development of rural infrastructure such as feeder roads and storage facilities. The project aims to increase household incomes by 40% and improve food security for participating families over its five-year implementation period.',
            category: 'Rural Development',
            crops: ['Teff', 'Maize', 'Wheat'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'IFAD',
            sourceName: 'IFAD',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800',
            url: '#'
        },
        {
            id: 'AN008',
            title: 'New Wheat Varieties Released for Ethiopian Farmers',
            summary: 'The Ethiopian Institute of Agricultural Research has released three new high-yield wheat varieties resistant to common diseases.',
            fullContent: 'The Ethiopian Institute of Agricultural Research has released three new high-yield wheat varieties resistant to common diseases and drought conditions, benefiting farmers across the highlands. The varieties, named Arama, Bora, and Chala, have been tested extensively in different agro-ecological zones. They show resistance to stem rust and yellow rust, two major wheat diseases, and have average yields of 3.5 tons per hectare compared to 1.8 tons for traditional varieties. The institute has produced over 10,000 quintals of certified seed for distribution to farmers in the upcoming planting season.',
            category: 'Research & Innovation',
            crops: ['Wheat'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'EIAR',
            sourceName: 'EIAR',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800',
            url: '#'
        },
        {
            id: 'AN009',
            title: 'Fertilizer Distribution Program Reaches Ethiopian Farmers',
            summary: 'The Ethiopian Agricultural Transformation Agency has successfully distributed over 1 million bags of fertilizer to farmers across the country.',
            fullContent: 'The Ethiopian Agricultural Transformation Agency has successfully distributed over 1 million bags of fertilizer to farmers across the country, supporting the current planting season. The distribution includes DAP, Urea, NPSB, and other blended fertilizers, reaching over 3 million smallholder farmers. The program includes training on proper fertilizer application rates and timing, as well as integration with soil testing services. Farmers in Oromia, Amhara, Tigray, and SNNP regions have reported improved crop conditions, with many expecting record harvests this season.',
            category: 'Fertilizer',
            crops: ['Teff', 'Maize', 'Wheat', 'Barley'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'ATA Ethiopia',
            sourceName: 'ATA Ethiopia',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?w=800',
            url: '#'
        },
        {
            id: 'AN010',
            title: 'Ethiopia Strengthens Food Security with Strategic Reserves',
            summary: 'The Ethiopian government is strengthening national food security through the expansion of strategic grain reserves.',
            fullContent: 'The Ethiopian government is strengthening national food security through the expansion of strategic grain reserves and improved market monitoring systems. The program has increased the strategic reserve capacity to 500,000 tons, with plans to reach 1 million tons by 2028. New storage facilities have been constructed in key grain-producing regions, and a digital monitoring system has been implemented to track grain stocks and market prices. The reserve system has successfully stabilized prices during the recent harvest period, ensuring affordable food for urban consumers.',
            category: 'Food Security',
            crops: ['Maize', 'Wheat', 'Sorghum'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1535431234501-4cfe3b88ed6e?w=800',
            url: '#'
        },
        {
            id: 'AN011',
            title: 'Livestock Productivity Program Launched in Afar Region',
            summary: 'A new program aimed at improving livestock productivity and pastoral livelihoods has been launched in the Afar Region.',
            fullContent: 'A new program aimed at improving livestock productivity and pastoral livelihoods has been launched in the Afar Region, focusing on animal health and sustainable grazing practices. The program includes mobile veterinary services, vaccination campaigns, and training on improved animal husbandry. Early interventions have reduced livestock mortality rates by 50% in pilot areas, with over 100,000 cattle, goats, and sheep receiving vaccinations. The program also supports the development of fodder production and water point development to improve animal nutrition and reduce conflicts over resources.',
            category: 'Livestock',
            crops: ['Livestock'],
            location: 'Afar Region, Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1579922194901-6008c0a12909?w=800',
            url: '#'
        },
        {
            id: 'AN012',
            title: 'Ethiopia Hosts Regional Agricultural Research Conference',
            summary: 'Addis Ababa is hosting a major regional agricultural research conference this week.',
            fullContent: 'Addis Ababa is hosting a major regional agricultural research conference this week, bringing together scientists and policymakers from across East Africa to discuss food security and climate resilience. The conference, organized by the Ethiopian Institute of Agricultural Research and the Association for Strengthening Agricultural Research in Eastern and Central Africa, features presentations on climate-smart agriculture, biotechnology, and digital farming. Over 300 delegates from 15 countries are attending the conference, which aims to strengthen research collaboration and share best practices for sustainable agricultural development.',
            category: 'Research & Innovation',
            crops: ['Maize', 'Wheat', 'Teff'],
            location: 'Addis Ababa, Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Institute of Agricultural Research',
            sourceName: 'Ethiopian Institute of Agricultural Research',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800',
            url: '#'
        },
        {
            id: 'AN013',
            title: 'Ethiopian Farmers Embrace Digital Agriculture Platforms',
            summary: 'Digital agriculture platforms are transforming farming in Ethiopia, connecting farmers with markets and information.',
            category: 'Agricultural Technology',
            crops: ['All crops'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1597177085512-2f8a763d80c5?w=800',
            url: '#'
        },
        {
            id: 'AN014',
            title: 'Improved Seed Distribution Program Expands in Ethiopia',
            summary: 'The Ethiopian government has expanded its improved seed distribution program to reach more farmers across the country.',
            fullContent: 'The Ethiopian government has expanded its improved seed distribution program to reach more farmers across the country. The program now provides high-yielding, disease-resistant seeds for teff, wheat, maize, and barley to over 2 million farmers. The seeds, developed by the Ethiopian Institute of Agricultural Research, have shown yield increases of 30-50% compared to local varieties. The expansion has been supported by development partners including the World Bank and USAID, who have contributed resources for seed multiplication and distribution infrastructure.',
            category: 'Crop Production',
            crops: ['Teff', 'Wheat', 'Maize', 'Barley'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Institute of Agricultural Research',
            sourceName: 'Ethiopian Institute of Agricultural Research',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1570110164243-71edb7d08c94?w=800',
            url: '#'
        },
        {
            id: 'AN015',
            title: 'Climate Change Adaptation Program Launched for Ethiopian Farmers',
            summary: 'A new climate change adaptation program has been launched to help Ethiopian farmers cope with changing weather patterns.',
            fullContent: 'A new climate change adaptation program has been launched to help Ethiopian farmers cope with changing weather patterns. The program, supported by the Green Climate Fund, provides farmers with training on climate-resilient farming techniques, including conservation agriculture, water harvesting, and use of drought-resistant crop varieties. Over 300,000 farmers will participate in the program across 50 districts, with a focus on smallholder farmers in climate-vulnerable areas. The program also includes early warning systems and climate information services to help farmers make informed decisions.',
            category: 'Climate & Agriculture',
            crops: ['Teff', 'Maize', 'Sorghum'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Green Climate Fund',
            sourceName: 'Green Climate Fund',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800',
            url: '#'
        },
        {
            id: 'AN016',
            title: 'Ethiopian Poultry Sector Gets Major Investment Boost',
            summary: 'Ethiopia\'s poultry sector is receiving a major investment boost to improve production and food security.',
            fullContent: 'Ethiopia\'s poultry sector is receiving a major investment boost to improve production and food security. The government has allocated $50 million to support poultry development, including the construction of modern hatcheries, vaccination programs, and training for smallholder poultry farmers. The investment aims to increase poultry meat production by 50% and egg production by 100% over the next five years. The sector currently provides livelihoods for over 1 million households, with significant potential for growth to meet the country\'s rising demand for poultry products.',
            category: 'Livestock',
            crops: ['Livestock'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1566896964826-d3f0b31b4936?w=800',
            url: '#'
        },
        {
            id: 'AN017',
            title: 'New Agricultural Policy Framework Adopted by Ethiopia',
            summary: 'Ethiopia has adopted a new agricultural policy framework aimed at transforming the sector and achieving food sovereignty.',
            fullContent: 'Ethiopia has adopted a new agricultural policy framework aimed at transforming the sector and achieving food sovereignty. The policy emphasizes sustainable intensification, value chain development, and private sector investment. Key targets include doubling agricultural productivity, increasing agricultural exports by 50%, and reducing post-harvest losses by 30% by 2030. The policy also includes provisions for climate-smart agriculture, digital transformation, and support for youth and women in agriculture. Implementation will be supported by a $500 million investment fund and technical assistance from development partners.',
            category: 'Agricultural Policy',
            crops: ['All crops'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Agriculture',
            sourceName: 'Ethiopian Ministry of Agriculture',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800',
            url: '#'
        },
        {
            id: 'AN018',
            title: 'Oromia Region Reports Record Harvest for 2026',
            summary: 'The Oromia Region in Ethiopia has reported a record harvest for the 2026 season, boosting national food security.',
            fullContent: 'The Oromia Region in Ethiopia has reported a record harvest for the 2026 season, boosting national food security. The region produced over 40 million quintals of cereals, including teff, wheat, maize, and barley, representing a 25% increase from the previous year. The record harvest was attributed to favorable weather conditions, improved seed varieties, and expanded fertilizer use. The surplus production has helped stabilize food prices and increase the country\'s strategic grain reserves. The government has allocated funds for additional storage facilities to accommodate the bumper harvest.',
            category: 'Crop Production',
            crops: ['Teff', 'Wheat', 'Maize', 'Barley'],
            location: 'Oromia, Ethiopia',
            date: new Date().toISOString(),
            source: 'ATA Ethiopia',
            sourceName: 'ATA Ethiopia',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1560492018-942d1271c23f?w=800',
            url: '#'
        },
        {
            id: 'AN019',
            title: 'Ethiopia Expands Agricultural Export Markets',
            summary: 'Ethiopia is expanding its agricultural export markets, with new agreements signed with several countries in the Middle East and Asia.',
            fullContent: 'Ethiopia is expanding its agricultural export markets, with new agreements signed with several countries in the Middle East and Asia. The agreements cover exports of coffee, sesame, pulses, and horticultural products. The new markets are expected to generate an additional $200 million in export earnings annually. The government has also invested in export infrastructure, including upgraded port facilities and cold chain logistics for perishable products. The expansion is part of a broader strategy to double agricultural exports by 2030 and reduce dependence on traditional markets.',
            category: 'Agricultural Trade',
            crops: ['Coffee', 'Sesame', 'Pulses'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'Ethiopian Ministry of Trade',
            sourceName: 'Ethiopian Ministry of Trade',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1516721860983-dcbc7d1f3e5e?w=800',
            url: '#'
        },
        {
            id: 'AN020',
            title: 'Ethiopian Scientists Develop Disease-Resistant Sorghum Variety',
            summary: 'Ethiopian scientists have developed a new sorghum variety resistant to the devastating Striga weed and other diseases.',
            fullContent: 'Ethiopian scientists have developed a new sorghum variety resistant to the devastating Striga weed and other diseases. The variety, named Shire-1, has been field-tested across multiple regions and shows resistance to both striga and anthracnose. Farmers testing the variety reported yields of 3 tons per hectare, compared to 1.5 tons for traditional varieties. The research team is now working on seed multiplication to make the variety available to farmers across the country. The development is expected to benefit over 5 million sorghum farmers in Ethiopia.',
            category: 'Research & Innovation',
            crops: ['Sorghum'],
            location: 'Ethiopia',
            date: new Date().toISOString(),
            source: 'EIAR',
            sourceName: 'EIAR',
            sourceUrl: '#',
            image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800',
            url: '#'
        }
    ];
    
    const itemsPerPage = 15;
    const offset = (page - 1) * itemsPerPage;
    const paginated = allArticles.slice(offset, offset + itemsPerPage);
    
    return {
        articles: paginated,
        total: allArticles.length,
        hasMore: offset + itemsPerPage < allArticles.length
    };
}

// ============================================================
// 5. HELPER FUNCTIONS
// ============================================================

function formatDate(dateString) {
    if (!dateString) return 'Date not available';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

function getTimeAgo(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '';
    const now = new Date();
    const diffMs = now - date;
    const diffMin = Math.floor(diffMs / (1000 * 60));
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    const diffWeek = Math.floor(diffDay / 7);
    
    if (diffMin < 1) return 'Just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHour < 24) return `${diffHour}h ago`;
    if (diffDay < 7) return `${diffDay}d ago`;
    if (diffWeek < 4) return `${diffWeek}w ago`;
    return formatDate(dateString);
}

function extractCategory(article) {
    const text = (article.title || '') + ' ' + (article.description || article.body || '');
    const lowerText = text.toLowerCase();
    if (lowerText.includes('fertilizer')) return 'Fertilizer';
    if (lowerText.includes('market') || lowerText.includes('price') || lowerText.includes('trade')) return 'Agricultural Markets';
    if (lowerText.includes('climate') || lowerText.includes('weather') || lowerText.includes('rain') || lowerText.includes('drought')) return 'Climate & Agriculture';
    if (lowerText.includes('research') || lowerText.includes('study') || lowerText.includes('scientist') || lowerText.includes('innovation')) return 'Research & Innovation';
    if (lowerText.includes('policy') || lowerText.includes('government') || lowerText.includes('ministry') || lowerText.includes('program')) return 'Agricultural Policy';
    if (lowerText.includes('food') && lowerText.includes('security')) return 'Food Security';
    if (lowerText.includes('crop') || lowerText.includes('harvest') || lowerText.includes('yield') || lowerText.includes('production')) return 'Crop Production';
    if (lowerText.includes('livestock') || lowerText.includes('cattle') || lowerText.includes('animal') || lowerText.includes('pastoral')) return 'Livestock';
    if (lowerText.includes('irrigation') || lowerText.includes('water')) return 'Irrigation';
    if (lowerText.includes('tech') || lowerText.includes('digital') || lowerText.includes('app') || lowerText.includes('innovation')) return 'Agricultural Technology';
    if (lowerText.includes('export') || lowerText.includes('import')) return 'Agricultural Trade';
    if (lowerText.includes('pest') || lowerText.includes('disease')) return 'Pest & Disease';
    if (lowerText.includes('rural') || lowerText.includes('development') || lowerText.includes('community')) return 'Rural Development';
    return 'Ethiopian Agriculture';
}

function extractCrops(text) {
    const cropList = [
        'Teff', 'Maize', 'Wheat', 'Barley', 'Sorghum', 'Coffee', 
        'Faba bean', 'Chickpea', 'Lentil', 'Soybean', 'Rice',
        'Millet', 'Peanut', 'Sesame', 'Cotton', 'Sugarcane',
        'Vegetable', 'Fruit', 'Potato', 'Onion', 'Tomato',
        'Livestock', 'Cattle', 'Goat', 'Sheep', 'All crops'
    ];
    const found = [];
    const lowerText = text.toLowerCase();
    for (const crop of cropList) {
        if (lowerText.includes(crop.toLowerCase())) {
            found.push(crop);
        }
    }
    return found;
}

function extractLocation(article) {
    const text = (article.title || '') + ' ' + (article.description || article.body || '');
    const regions = ['Addis Ababa', 'Oromia', 'Amhara', 'Tigray', 'Somali', 'Afar', 
                     'Benishangul', 'Gambela', 'Harari', 'Sidama', 'South Ethiopia',
                     'Ethiopia', 'Kenya', 'Uganda', 'Sudan', 'Eritrea', 'Djibouti',
                     'Africa', 'East Africa'];
    for (const region of regions) {
        if (text.includes(region)) {
            return region;
        }
    }
    return 'Ethiopia';
}

// ============================================================
// 6. RENDER FUNCTIONS
// ============================================================

function renderCard(article, index) {
    const category = article.category || 'Agriculture News';
    const crops = article.crops || [];
    const location = article.location || 'Ethiopia';
    const summary = article.summary || article.description || 'Read the full article for more details.';
    const source = article.source || article.sourceName || 'News Source';
    const date = article.date || article.publishedDate || '';
    const timeAgo = getTimeAgo(date);
    const imageUrl = article.image || article.imageUrl || null;
    
    // Crop tags HTML
    let cropHtml = '';
    if (crops.length > 0) {
        cropHtml = `
            <div class="news-card-crops">
                ${crops.slice(0, 4).map(crop => `<span class="crop-tag">${crop}</span>`).join('')}
                ${crops.length > 4 ? `<span class="crop-tag">+${crops.length - 4}</span>` : ''}
            </div>
        `;
    }
    
    return `
        <div class="news-card" data-index="${index}">
            <div class="news-card-image">
                ${imageUrl ? 
                    `<img src="${imageUrl}" alt="${article.title || 'News article'}" loading="lazy" onerror="this.parentElement.innerHTML='<span class=\\'placeholder-text\\'>Agricultural News</span>'">` :
                    `<span class="placeholder-text">Agricultural News</span>`
                }
            </div>
            <div class="news-card-body">
                <span class="news-card-category">${category}</span>
                <h3 class="news-card-title">${article.title || 'Agriculture News Update'}</h3>
                <p class="news-card-summary">${summary}</p>
                ${cropHtml}
                <div class="news-card-meta">
                    <span class="source">${source}</span>
                    <span class="date">${timeAgo}</span>
                    ${location ? `<span class="location">${location}</span>` : ''}
                </div>
                <button class="read-more-btn" data-index="${index}">Read Full Article</button>
            </div>
        </div>
    `;
}

function renderGrid(articles) {
    if (articles.length === 0) {
        dom.grid.innerHTML = '';
        dom.emptyState.style.display = 'block';
        dom.loadingState.style.display = 'none';
        dom.errorState.style.display = 'none';
        dom.resultsCount.textContent = '0';
        dom.loadMoreContainer.style.display = 'none';
        return;
    }
    
    dom.emptyState.style.display = 'none';
    dom.loadingState.style.display = 'none';
    dom.errorState.style.display = 'none';
    dom.grid.innerHTML = articles.map((article, index) => renderCard(article, index)).join('');
    dom.resultsCount.textContent = state.totalItems > 0 ? state.totalItems : articles.length;
    
    if (state.hasMore && articles.length >= 15) {
        dom.loadMoreContainer.style.display = 'block';
    } else {
        dom.loadMoreContainer.style.display = 'none';
    }
    
    // Attach click events to Read More buttons
    document.querySelectorAll('.read-more-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const index = parseInt(this.getAttribute('data-index'));
            const article = state.filtered[index] || state.news[index];
            if (article) {
                openFullArticle(article);
            }
        });
    });
    
    // Also make the whole card clickable
    document.querySelectorAll('.news-card').forEach(card => {
        card.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            const article = state.filtered[index] || state.news[index];
            if (article) {
                openFullArticle(article);
            }
        });
    });
}

function renderFilterOptions() {
    const categories = new Set();
    const crops = new Set();
    const locations = new Set();
    
    state.news.forEach(article => {
        if (article.category) categories.add(article.category);
        if (article.crops) {
            article.crops.forEach(c => crops.add(c));
        }
        if (article.location) locations.add(article.location);
    });
    
    dom.categoryFilterOptions.innerHTML = Array.from(categories).sort().map(cat => `
        <label class="filter-option ${state.activeFilters.categories.includes(cat) ? 'checked' : ''}">
            <input type="checkbox" value="${cat}" ${state.activeFilters.categories.includes(cat) ? 'checked' : ''}>
            ${cat}
        </label>
    `).join('');
    
    dom.cropFilterOptions.innerHTML = Array.from(crops).sort().map(crop => `
        <label class="filter-option ${state.activeFilters.crops.includes(crop) ? 'checked' : ''}">
            <input type="checkbox" value="${crop}" ${state.activeFilters.crops.includes(crop) ? 'checked' : ''}>
            ${crop}
        </label>
    `).join('');
    
    dom.locationFilterOptions.innerHTML = Array.from(locations).sort().map(loc => `
        <label class="filter-option ${state.activeFilters.locations.includes(loc) ? 'checked' : ''}">
            <input type="checkbox" value="${loc}" ${state.activeFilters.locations.includes(loc) ? 'checked' : ''}>
            ${loc}
        </label>
    `).join('');
    
    updateFilterCount();
}

// ============================================================
// 7. FULL ARTICLE PAGE (Opens in New Page)
// ============================================================

function openFullArticle(article) {
    // Build the full article HTML
    const crops = article.crops || [];
    const imageUrl = article.image || article.imageUrl || null;
    const source = article.source || article.sourceName || 'Source not available';
    const sourceUrl = article.sourceUrl || article.url || '#';
    const date = formatDate(article.date || article.publishedDate);
    const fullContent = article.fullContent || article.body || article.description || article.summary || 'Full article content not available.';
    
    // Create crop tags HTML
    let cropHtml = '';
    if (crops.length > 0) {
        cropHtml = `
            <div class="detail-section">
                <h4 class="detail-section-title">Related Crops</h4>
                <div class="detail-section-content">
                    ${crops.map(crop => `<span class="tag highlight">${crop}</span>`).join('')}
                </div>
            </div>
        `;
    }
    
    const html = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>${article.title || 'Agriculture News'} - AgriNova</title>
            <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
            <style>
                /* Copy the article detail styles from CSS */
                * { margin:0; padding:0; box-sizing:border-box; }
                body { font-family:'Inter',sans-serif; background:#F7F4EA; color:#26332A; line-height:1.6; }
                .article-page { max-width:900px; margin:0 auto; padding:40px 32px 60px; background:#FFFFFF; border-radius:16px; box-shadow:0 2px 20px rgba(0,0,0,0.06); min-height:80vh; margin-top:20px; margin-bottom:20px; }
                .back-link { display:inline-block; color:#2E7D32; font-weight:600; text-decoration:none; margin-bottom:24px; padding:8px 16px; border:1px solid #2E7D32; border-radius:30px; transition:all 0.2s ease; font-size:14px; }
                .back-link:hover { background:#2E7D32; color:#FFFFFF; }
                .detail-image { width:100%; height:400px; background:#EDEBE2; border-radius:16px; overflow:hidden; margin-bottom:28px; }
                .detail-image img { width:100%; height:100%; object-fit:cover; }
                .detail-image .placeholder-text { display:flex; align-items:center; justify-content:center; width:100%; height:100%; font-size:16px; color:#8A9A8E; }
                .detail-title { font-family:'Playfair Display',serif; font-size:34px; font-weight:700; color:#164A2A; margin-bottom:12px; line-height:1.2; }
                .detail-meta { display:flex; flex-wrap:wrap; gap:16px 28px; font-size:15px; color:#7A8A7E; margin-bottom:24px; padding-bottom:18px; border-bottom:2px solid #E8E5DC; }
                .detail-meta .meta-source { color:#2E7D32; font-weight:600; }
                .detail-meta .meta-category { background:#E8F5E9; color:#2E7D32; padding:2px 16px; border-radius:20px; font-size:13px; font-weight:600; }
                .detail-full-content { font-size:17px; color:#3A4A3E; line-height:1.9; margin-bottom:28px; }
                .detail-full-content p { margin-bottom:16px; }
                .detail-section { margin-bottom:20px; }
                .detail-section-title { font-size:16px; font-weight:700; color:#164A2A; border-bottom:2px solid #E8E5DC; padding-bottom:6px; margin-bottom:10px; }
                .detail-section-content .tag { display:inline-block; background:#F7F4EA; color:#26332A; padding:4px 16px; border-radius:20px; font-size:13px; font-weight:500; margin:3px 6px 3px 0; border:1px solid #E8E5DC; }
                .detail-section-content .tag.highlight { background:#E8F5E9; border-color:#66BB6A; color:#2E7D32; }
                .detail-source-link { display:inline-block; margin-top:8px; color:#2E7D32; font-weight:600; text-decoration:none; border-bottom:2px solid #2E7D32; padding-bottom:2px; transition:all 0.2s ease; }
                .detail-source-link:hover { color:#164A2A; border-color:#164A2A; }
                @media (max-width:768px) { 
                    .article-page { padding:20px 16px 40px; margin:0 8px; }
                    .detail-title { font-size:26px; }
                    .detail-image { height:220px; }
                    .detail-full-content { font-size:16px; }
                }
                @media (max-width:400px) {
                    .detail-title { font-size:22px; }
                }
            </style>
        </head>
        <body>
            <div class="article-page">
                <a href="javascript:history.back()" class="back-link">← Back to News</a>
                
                <div class="detail-image">
                    ${imageUrl ? 
                        `<img src="${imageUrl}" alt="${article.title || 'News article'}" onerror="this.parentElement.innerHTML='<span class=\\'placeholder-text\\'>Image not available</span>'">` :
                        `<span class="placeholder-text">Image not available</span>`
                    }
                </div>
                
                <h1 class="detail-title">${article.title || 'Agriculture News Update'}</h1>
                
                <div class="detail-meta">
                    ${source ? `<span class="meta-source">${source}</span>` : ''}
                    ${date ? `<span>${date}</span>` : ''}
                    ${article.location ? `<span>${article.location}</span>` : ''}
                    ${article.category ? `<span class="meta-category">${article.category}</span>` : ''}
                </div>
                
                <div class="detail-full-content">
                    ${fullContent.split('\n').map(para => para.trim() ? `<p>${para}</p>` : '').join('')}
                </div>
                
                ${cropHtml}
                
                ${sourceUrl && sourceUrl !== '#' ? `
                    <div class="detail-section">
                        <h4 class="detail-section-title">Source</h4>
                        <div class="detail-section-content">
                            <a href="${sourceUrl}" target="_blank" class="detail-source-link" rel="noopener">
                                Read original article →
                            </a>
                        </div>
                    </div>
                ` : ''}
            </div>
        </body>
        </html>
    `;
    
    // Open in new window/tab
    const newWindow = window.open('', '_blank');
    if (newWindow) {
        newWindow.document.write(html);
        newWindow.document.close();
    } else {
        // Fallback if popup is blocked
        alert('Please allow popups to view the full article.');
    }
}

// ============================================================
// 8. FILTER & SEARCH FUNCTIONS
// ============================================================

function applyFilters() {
    const searchTerm = dom.search.value.toLowerCase().trim();
    const activeCategories = state.activeFilters.categories;
    const activeCrops = state.activeFilters.crops;
    const activeLocations = state.activeFilters.locations;
    
    let results = state.news.filter(article => {
        if (searchTerm) {
            const searchText = (article.title || '') + ' ' + 
                             (article.summary || article.description || article.fullContent || '') + ' ' +
                             (article.category || '') + ' ' +
                             (article.location || '') + ' ' +
                             ((article.crops || []).join(' '));
            if (!searchText.toLowerCase().includes(searchTerm)) return false;
        }
        
        if (activeCategories.length > 0) {
            if (!article.category || !activeCategories.includes(article.category)) return false;
        }
        
        if (activeCrops.length > 0) {
            const articleCrops = article.crops || [];
            const hasCrop = activeCrops.some(c => articleCrops.includes(c));
            if (!hasCrop) return false;
        }
        
        if (activeLocations.length > 0) {
            if (!article.location || !activeLocations.includes(article.location)) return false;
        }
        
        return true;
    });
    
    state.filtered = results;
    renderGrid(results);
    updateFilterCount();
}

function updateFilterCount() {
    const total = state.activeFilters.categories.length + 
                  state.activeFilters.crops.length + 
                  state.activeFilters.locations.length;
    dom.filterCount.textContent = total;
    dom.filterCount.style.display = total > 0 ? 'inline' : 'none';
}

function gatherFilterSelections() {
    const categories = [];
    dom.categoryFilterOptions.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => categories.push(cb.value));
    
    const crops = [];
    dom.cropFilterOptions.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => crops.push(cb.value));
    
    const locations = [];
    dom.locationFilterOptions.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => locations.push(cb.value));
    
    state.activeFilters.categories = categories;
    state.activeFilters.crops = crops;
    state.activeFilters.locations = locations;
    
    document.querySelectorAll('.filter-option').forEach(opt => {
        const cb = opt.querySelector('input[type="checkbox"]');
        opt.classList.toggle('checked', cb && cb.checked);
    });
}

// ============================================================
// 9. DATA LOADING FUNCTIONS
// ============================================================

async function loadNews(append = false) {
    if (state.loading) return;
    state.loading = true;
    
    dom.loadingState.style.display = 'block';
    dom.errorState.style.display = 'none';
    dom.emptyState.style.display = 'none';
    
    if (!append) {
        dom.grid.innerHTML = '';
    }
    
    try {
        const result = await fetchNewsFromAPI(state.currentPage, state.searchTerm);
        
        if (result.articles && result.articles.length > 0) {
            if (append) {
                state.news = [...state.news, ...result.articles];
            } else {
                state.news = result.articles;
            }
            
            state.totalItems = result.total || state.news.length;
            state.hasMore = result.hasMore || false;
            state.filtered = [...state.news];
            
            dom.loadingState.style.display = 'none';
            renderGrid(state.filtered);
            renderFilterOptions();
            
        } else if (!append) {
            state.news = [];
            state.filtered = [];
            dom.loadingState.style.display = 'none';
            dom.emptyState.style.display = 'block';
            dom.resultsCount.textContent = '0';
        }
        
    } catch (error) {
        console.error('Error loading news:', error);
        dom.loadingState.style.display = 'none';
        dom.errorState.style.display = 'block';
        dom.errorDetail.textContent = error.message || 'Unable to fetch news. Please try again.';
    }
    
    state.loading = false;
}

async function loadMoreNews() {
    state.currentPage++;
    await loadNews(true);
}

async function refreshNews() {
    state.currentPage = 1;
    state.hasMore = true;
    dom.refreshBtn.disabled = true;
    dom.refreshBtn.innerHTML = 'Loading...';
    
    await loadNews(false);
    
    dom.refreshBtn.disabled = false;
    dom.refreshBtn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"/>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
        </svg>
        Refresh News
    `;
}

// ============================================================
// 10. INITIALIZATION
// ============================================================

function init() {
    loadNews(false);
}

// ============================================================
// 11. EVENT LISTENERS
// ============================================================

dom.search.addEventListener('input', function() {
    state.searchTerm = this.value;
    state.currentPage = 1;
    applyFilters();
});

dom.filterToggle.addEventListener('click', function() {
    dom.filterPanel.classList.toggle('active');
});

dom.applyFilters.addEventListener('click', function() {
    gatherFilterSelections();
    applyFilters();
    dom.filterPanel.classList.remove('active');
});

dom.clearFilters.addEventListener('click', function() {
    dom.categoryFilterOptions.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
    dom.cropFilterOptions.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
    dom.locationFilterOptions.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
    document.querySelectorAll('.filter-option').forEach(opt => opt.classList.remove('checked'));
    
    state.activeFilters = { categories: [], crops: [], locations: [] };
    dom.search.value = '';
    state.searchTerm = '';
    state.currentPage = 1;
    updateFilterCount();
    loadNews(false);
    dom.filterPanel.classList.remove('active');
});

document.addEventListener('change', function(e) {
    if (e.target.closest('.filter-options')) {
        const opt = e.target.closest('.filter-option');
        if (opt) {
            opt.classList.toggle('checked', e.target.checked);
        }
    }
});

dom.refreshBtn.addEventListener('click', refreshNews);
dom.loadMoreBtn.addEventListener('click', loadMoreNews);
dom.retryBtn.addEventListener('click', function() {
    init();
});

// ============================================================
// 12. START APPLICATION
// ============================================================

document.addEventListener('DOMContentLoaded', init);