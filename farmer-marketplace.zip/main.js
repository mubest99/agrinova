// main.js – AgriNova interactivity

(function() {
  // ----- DOM refs -----
  const landingPage = document.getElementById('page-landing');
  const selectionPage = document.getElementById('page-selection');
  const authPage = document.getElementById('page-auth');

  const btnStart = document.getElementById('btnStartJourney');
  const farmerSelect = document.getElementById('farmerSelect');
  document.getElementById('visitorSelect').addEventListener('click', function() {
    window.location.href = 'visitor-dashboard.html';
});

  // Auth sections
  const registerSection = document.getElementById('registerSection');
  const loginSection = document.getElementById('loginSection');
  const dashboardSection = document.getElementById('dashboardSection');

  const goToLoginLink = document.getElementById('goToLoginLink');
  const goToRegisterLink = document.getElementById('goToRegisterLink');

  const farmerForm = document.getElementById('farmerForm');
  const loginForm = document.getElementById('loginForm');
  const logoutBtn = document.getElementById('logoutBtn');

  // ----- Helper: show auth section -----
  function showAuthSection(section) {
    registerSection.style.display = 'none';
    loginSection.style.display = 'none';
    dashboardSection.style.display = 'none';
    if (section === 'register') registerSection.style.display = 'block';
    else if (section === 'login') loginSection.style.display = 'block';
    else if (section === 'dashboard') dashboardSection.style.display = 'block';
  }

  // ----- Helper: switch page -----
  function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById(pageId);
    if (target) target.classList.add('active');
  }

  // 1. Start journey -> go to selection
  btnStart.addEventListener('click', () => {
    showPage('page-selection');
  });

  // 2. Farmer selection -> go to auth (registration)
  farmerSelect.addEventListener('click', () => {
    showPage('page-auth');
    showAuthSection('register');
  });

  // 3. Visitor selection -> alert
  visitorSelect.addEventListener('click', () => {
    alert('🌾 You enter AgriNova as a visitor.\nExplore interactive learning, crop map, weather, farm simulator, and more!');
  });

  // 4. Toggle between register and login
  goToLoginLink.addEventListener('click', (e) => {
    e.preventDefault();
    showAuthSection('login');
  });

  goToRegisterLink.addEventListener('click', (e) => {
    e.preventDefault();
    showAuthSection('register');
  });

  // 5. Registration form submit
  farmerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value.trim();

    if (!name || !email || !password) {
      alert('Please fill in name, email and password.');
      return;
    }

    // Store user data in localStorage (simulate account creation)
    const userData = {
      name: name,
      email: email,
      password: password,
      phone: document.getElementById('regPhone').value,
      region: document.getElementById('regRegion').value,
      city: document.getElementById('regCity').value,
      hectares: document.getElementById('regHectares').value
    };
    localStorage.setItem('agrinova_user', JSON.stringify(userData));

    alert('✅ Account created successfully! Please login.');
    showAuthSection('login');
    // Pre-fill login email
    document.getElementById('loginEmail').value = email;
    document.getElementById('loginPassword').value = '';
  });

  // 6. Login form submit
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const loginEmail = document.getElementById('loginEmail').value.trim();
    const loginPassword = document.getElementById('loginPassword').value.trim();

    if (!loginEmail || !loginPassword) {
      alert('Please enter email and password.');
      return;
    }

    // Check against stored user data
    const storedUser = localStorage.getItem('agrinova_user');
    if (!storedUser) {
      alert('❌ No account found. Please create an account first.');
      showAuthSection('register');
      return;
    }

    const user = JSON.parse(storedUser);
    if (loginEmail === user.email && loginPassword === user.password) {
      localStorage.setItem('agrinova_logged_in', 'true');
      window.location.href = 'farmer-dashboard.html';
    } else {
      alert('❌ Invalid email or password. Please try again.');
    }
  });

  // 7. Logout
  logoutBtn.addEventListener('click', () => {
    showAuthSection('register');
    // Clear login fields
    document.getElementById('loginEmail').value = '';
    document.getElementById('loginPassword').value = '';
  });

  // 8. If user goes back to auth page, default to register
  // (but if they were on dashboard, keep dashboard)
  // We'll handle this via navigation.

  // Initialize: show landing
  showPage('page-landing');
})();