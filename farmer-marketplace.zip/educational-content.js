/**
 * AgriNova — Educational Agriculture Content
 * Complete JavaScript with sample data structure
 */

// ============================================================
// 1. SAMPLE DATA (Replace with API/Database data later)
// ============================================================

const educationalData = [
    {
        id: "ED001",
        title: "Understanding Soil Types and Properties",
        category: "Soil",
        difficulty: "Beginner",
        description: "Learn about different soil types, their properties, and how they affect crop growth.",
        estimatedTime: "15 min",
        image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800",
        introduction: "Soil is the foundation of agriculture. Understanding soil types and their properties is essential for successful farming. This lesson introduces the basic concepts of soil science and how different soils affect crop production.",
        sections: [
            {
                title: "What is Soil?",
                content: "Soil is a complex mixture of minerals, organic matter, water, air, and living organisms. It forms the upper layer of the earth's surface and provides the medium for plant growth. Soil is formed through the weathering of rocks and the decomposition of organic matter over thousands of years."
            },
            {
                title: "Why Soil is Important in Agriculture",
                content: "Soil provides essential nutrients, water, and support for plant roots. Healthy soil is the foundation of productive agriculture. It stores water, recycles nutrients, and supports a diverse ecosystem of beneficial organisms. Poor soil health leads to reduced crop yields and increased vulnerability to pests and diseases."
            },
            {
                title: "Important Soil Properties",
                content: "Key soil properties include texture, structure, pH, organic matter content, and nutrient availability. Soil texture refers to the proportion of sand, silt, and clay particles. Soil structure describes how these particles are arranged. Soil pH affects nutrient availability and microbial activity."
            },
            {
                title: "Major Soil Types",
                content: "Major soil types include sandy soils, clay soils, loamy soils, and silty soils. Sandy soils drain quickly but have low nutrient retention. Clay soils retain water and nutrients but can be poorly drained. Loamy soils are considered ideal for agriculture as they balance drainage and nutrient retention. Silty soils are fertile but prone to erosion."
            },
            {
                title: "How Soil Affects Crops",
                content: "Different crops have different soil requirements. Maize and wheat prefer well-drained loamy soils. Rice grows well in water-retaining clay soils. Coffee thrives in volcanic soils with good drainage. Understanding soil-crop relationships helps farmers select appropriate crops and management practices."
            },
            {
                title: "Basic Soil Management",
                content: "Soil management practices include regular soil testing, appropriate fertilization, crop rotation, conservation tillage, and organic matter addition. Maintaining soil health requires balanced nutrient management, erosion prevention, and careful water management. Healthy soils produce healthy crops."
            }
        ],
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publicationDate: "2026-07-20",
        featured: true
    },
    {
        id: "ED002",
        title: "Irrigation Methods for Smallholder Farmers",
        category: "Irrigation",
        difficulty: "Intermediate",
        description: "Explore practical irrigation methods suitable for smallholder farmers in water-scarce regions.",
        estimatedTime: "20 min",
        image: "https://images.unsplash.com/photo-1573995101240-cb37b974802c?w=800",
        introduction: "Water is essential for crop production, but many farmers face water scarcity. This lesson explores irrigation methods that are practical, affordable, and effective for smallholder farmers.",
        sections: [
            {
                title: "Understanding Irrigation",
                content: "Irrigation is the artificial application of water to soil to support crop growth. It is essential in areas with inadequate or unreliable rainfall. Efficient irrigation can significantly increase crop yields and improve food security."
            },
            {
                title: "Drip Irrigation Systems",
                content: "Drip irrigation delivers water directly to plant roots through a network of tubes and emitters. This method can save up to 60% water compared to traditional irrigation. It is suitable for vegetables, fruits, and high-value crops. Drip irrigation kits are available for smallholder farmers."
            },
            {
                title: "Sprinkler Irrigation",
                content: "Sprinkler systems distribute water through overhead sprinklers, simulating rainfall. This method is suitable for a wide range of crops and terrains. It requires more water than drip irrigation but is less labor-intensive."
            },
            {
                title: "Manual Irrigation",
                content: "Manual irrigation includes methods like watering cans, buckets, and small pumps. These are simple and affordable but labor-intensive. They are suitable for small plots and home gardens."
            },
            {
                title: "Water Harvesting Techniques",
                content: "Water harvesting involves collecting and storing rainwater for irrigation. Techniques include roof catchment, ponds, and check dams. These methods are particularly valuable in semi-arid areas where water is scarce."
            },
            {
                title: "Choosing the Right Irrigation Method",
                content: "The choice of irrigation method depends on crop type, water availability, farm size, and budget. Smallholder farmers should consider affordable, efficient systems that suit their specific conditions."
            }
        ],
        source: "International Water Management Institute",
        sourceUrl: "#",
        publicationDate: "2026-07-18",
        featured: false
    },
    {
        id: "ED003",
        title: "Fertilizer Types and Application",
        category: "Fertilizers",
        difficulty: "Intermediate",
        description: "Learn about different fertilizer types, their nutrient content, and how to apply them effectively.",
        estimatedTime: "20 min",
        image: "https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?w=800",
        introduction: "Fertilizers provide essential nutrients that crops need for growth and development. Understanding fertilizer types and proper application is crucial for maximizing yields and protecting the environment.",
        sections: [
            {
                title: "What are Fertilizers?",
                content: "Fertilizers are materials added to soil to supply essential nutrients for plant growth. They can be organic (from natural sources) or inorganic (manufactured). The main nutrients are nitrogen (N), phosphorus (P), and potassium (K)."
            },
            {
                title: "Types of Fertilizers",
                content: "Common fertilizers include Urea (46% nitrogen), DAP (18% nitrogen, 46% phosphorus), NPK blends, and organic fertilizers like compost and manure. Each type has different nutrient compositions and release characteristics."
            },
            {
                title: "Understanding Nutrient Labels",
                content: "Fertilizer labels show the N-P-K ratio, indicating the percentage of nitrogen, phosphorus, and potassium. For example, NPK 15-15-15 contains 15% each. Understanding these numbers helps farmers choose the right fertilizer for their crops."
            },
            {
                title: "Fertilizer Application Methods",
                content: "Methods include broadcasting (spreading over the soil), banding (placing near seeds), and foliar (spraying on leaves). The choice depends on crop type, fertilizer type, and farming system."
            },
            {
                title: "Application Timing",
                content: "Fertilizer should be applied at the right time to maximize crop uptake. Basal application occurs at planting. Top-dressing is done during the growing season. Split applications provide nutrients throughout the growth cycle."
            },
            {
                title: "Soil Testing and Fertilizer Management",
                content: "Soil testing helps determine nutrient needs and prevents over-fertilization. Regular testing ensures that fertilizers are used efficiently, saving costs and protecting the environment."
            }
        ],
        source: "IFDC",
        sourceUrl: "#",
        publicationDate: "2026-07-15",
        featured: false
    },
    {
        id: "ED004",
        title: "Crop Pest and Disease Identification",
        category: "Pest & Disease",
        difficulty: "Beginner",
        description: "Identify common crop pests and diseases and learn basic management strategies.",
        estimatedTime: "15 min",
        image: "https://images.unsplash.com/photo-1535431234501-4cfe3b88ed6e?w=800",
        introduction: "Pests and diseases can significantly reduce crop yields. Early identification and proper management are essential for protecting crops. This lesson covers common pests and diseases in Ethiopian agriculture.",
        sections: [
            {
                title: "Common Crop Pests",
                content: "Common crop pests include insects (armyworms, aphids, beetles), rodents, and birds. Each pest causes characteristic damage to crops. Early detection helps prevent major outbreaks."
            },
            {
                title: "Common Crop Diseases",
                content: "Crop diseases are caused by fungi, bacteria, viruses, and nematodes. Examples include rust diseases (wheat), leaf spot (vegetables), and wilt diseases (tomatoes). Symptoms include discoloration, wilting, spots, and stunted growth."
            },
            {
                title: "Signs of Pest and Disease Damage",
                content: "Look for holes in leaves, chewed edges, wilting, yellowing, spots, mold growth, and stunted growth. Regular monitoring of fields helps detect problems early."
            },
            {
                title: "Integrated Pest Management (IPM)",
                content: "IPM combines biological, cultural, and chemical methods to manage pests sustainably. It includes crop rotation, natural predators, resistant varieties, and judicious pesticide use."
            },
            {
                title: "Preventive Measures",
                content: "Prevention is better than cure. Use clean seeds, practice crop rotation, maintain field hygiene, and monitor fields regularly. These practices reduce pest and disease pressure."
            },
            {
                title: "When and How to Seek Help",
                content: "Contact agricultural extension services or research institutions when facing severe outbreaks. Early intervention prevents widespread damage."
            }
        ],
        source: "Ethiopian Plant Protection Agency",
        sourceUrl: "#",
        publicationDate: "2026-07-12",
        featured: false
    },
    {
        id: "ED005",
        title: "Climate-Smart Agriculture Practices",
        category: "Climate",
        difficulty: "Intermediate",
        description: "Discover agricultural practices that help farmers adapt to climate change and reduce environmental impact.",
        estimatedTime: "20 min",
        image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800",
        introduction: "Climate change is affecting agriculture worldwide. Climate-smart agriculture helps farmers adapt to changing conditions while reducing environmental impact. This lesson explores practical strategies.",
        sections: [
            {
                title: "What is Climate-Smart Agriculture?",
                content: "Climate-smart agriculture is an approach that addresses food security and climate change challenges. It focuses on increasing productivity, building resilience, and reducing greenhouse gas emissions."
            },
            {
                title: "Conservation Agriculture",
                content: "This approach involves minimum soil disturbance, permanent soil cover, and crop diversity. It improves soil health, reduces erosion, and enhances water conservation."
            },
            {
                title: "Drought-Tolerant Crop Varieties",
                content: "Scientists have developed crop varieties that tolerate drought conditions. These varieties maintain yields even with limited rainfall, helping farmers in dry areas."
            },
            {
                title: "Water Harvesting and Management",
                content: "Techniques include rainwater harvesting, constructing ponds, and using efficient irrigation. These methods ensure water availability during dry periods."
            },
            {
                title: "Agroforestry",
                content: "Agroforestry integrates trees into farming systems. Trees provide shade, improve soil fertility, and offer additional income sources."
            },
            {
                title: "Adapting to Climate Variability",
                content: "Diversify crops, use weather information, and adjust planting dates. These practices help farmers manage climate risks and maintain production."
            }
        ],
        source: "CGIAR",
        sourceUrl: "#",
        publicationDate: "2026-07-10",
        featured: false
    },
    {
        id: "ED006",
        title: "Understanding Ethiopian Agricultural Systems",
        category: "Ethiopian Agriculture",
        difficulty: "Beginner",
        description: "Learn about Ethiopia's diverse agricultural systems and their importance to the economy and food security.",
        estimatedTime: "15 min",
        image: "https://images.unsplash.com/photo-1590090269573-a741d6bea6ef?w=800",
        introduction: "Agriculture is the backbone of Ethiopia's economy. Understanding the country's diverse agricultural systems helps farmers, researchers, and policymakers improve productivity and food security.",
        sections: [
            {
                title: "Overview of Ethiopian Agriculture",
                content: "Agriculture employs 70% of Ethiopia's population and contributes 40% to the GDP. Major crops include teff, wheat, maize, barley, sorghum, coffee, and pulses. Livestock production is also important."
            },
            {
                title: "Major Crop Production Systems",
                content: "Ethiopia has diverse farming systems including the cereal-based highland system, agroforestry systems, pastoral systems, and irrigated systems. Each system has unique challenges and opportunities."
            },
            {
                title: "Key Crops in Ethiopian Agriculture",
                content: "Teff is Ethiopia's staple crop. Coffee is the main export crop. Other important crops include wheat, maize, barley, sorghum, and chickpeas. Understanding these crops is essential for food security."
            },
            {
                title: "Challenges Facing Ethiopian Farmers",
                content: "Challenges include land degradation, climate variability, limited access to inputs, inadequate extension services, and market constraints. Addressing these challenges requires coordinated efforts."
            },
            {
                title: "Government Programs and Support",
                content: "The government has implemented various programs including the Agricultural Transformation Agency, extension services, and input distribution programs. These support farmers and improve productivity."
            },
            {
                title: "Future of Ethiopian Agriculture",
                content: "The future depends on sustainable intensification, climate adaptation, technology adoption, and improved market access. Investments in research, education, and infrastructure are crucial."
            }
        ],
        source: "Ethiopian Ministry of Agriculture",
        sourceUrl: "#",
        publicationDate: "2026-07-08",
        featured: false
    },
    {
        id: "ED007",
        title: "Post-Harvest Management Techniques",
        category: "Post-Harvest",
        difficulty: "Intermediate",
        description: "Learn techniques to reduce post-harvest losses and maintain crop quality from field to storage.",
        estimatedTime: "20 min",
        image: "https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?w=800",
        introduction: "Post-harvest losses can significantly reduce farmer incomes. Proper harvesting, handling, and storage techniques help maintain crop quality and reduce waste.",
        sections: [
            {
                title: "Understanding Post-Harvest Losses",
                content: "Post-harvest losses occur between harvest and consumption. They include damage from insects, fungi, rodents, and improper handling. In Ethiopia, losses can reach 20-30% for some crops."
            },
            {
                title: "Harvesting Best Practices",
                content: "Harvest at the right time, use appropriate tools, and minimize damage. Proper harvesting reduces losses and maintains crop quality."
            },
            {
                title: "Drying and Threshing",
                content: "Proper drying reduces moisture content and prevents spoilage. Threshing should be done carefully to avoid grain damage."
            },
            {
                title: "Storage Techniques",
                content: "Store crops in clean, dry, and pest-proof facilities. Use hermetic storage, good ventilation, and appropriate containers. Traditional storage methods can be improved with modern techniques."
            },
            {
                title: "Processing and Value Addition",
                content: "Processing adds value to crops and reduces waste. Examples include milling, shelling, and packaging. Processing can increase farmer incomes."
            },
            {
                title: "Marketing Post-Harvest",
                content: "Good post-harvest practices improve market quality and prices. Farmers should understand market requirements and grade their produce accordingly."
            }
        ],
        source: "Ethiopian Agricultural Transformation Agency",
        sourceUrl: "#",
        publicationDate: "2026-07-05",
        featured: false
    },
    {
        id: "ED008",
        title: "Introduction to Agricultural Technology",
        category: "Agricultural Technology",
        difficulty: "Beginner",
        description: "Explore how technology is transforming agriculture through precision farming, sensors, and digital tools.",
        estimatedTime: "15 min",
        image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800",
        introduction: "Technology is transforming agriculture, making it more efficient and productive. This lesson introduces key agricultural technologies and their applications.",
        sections: [
            {
                title: "What is Agricultural Technology?",
                content: "Agricultural technology includes tools, equipment, and digital solutions that improve farming efficiency. Technologies include sensors, drones, mobile apps, and precision farming tools."
            },
            {
                title: "Precision Agriculture",
                content: "Precision agriculture uses data to optimize farming practices. It involves GPS, soil sensors, and variable rate application of inputs. This approach reduces waste and increases yields."
            },
            {
                title: "Digital Tools for Farmers",
                content: "Mobile apps provide market information, weather forecasts, and agricultural advice. Digital platforms connect farmers with buyers and extension services."
            },
            {
                title: "Sensors and Monitoring",
                content: "Soil sensors, weather stations, and crop monitoring tools provide real-time data. This information helps farmers make informed decisions about irrigation, fertilization, and pest management."
            },
            {
                title: "Agricultural Machinery",
                content: "Modern machinery improves efficiency in planting, harvesting, and processing. Appropriate technology for smallholders includes affordable, practical equipment."
            },
            {
                title: "Future of Agricultural Technology",
                content: "Emerging technologies include AI, robotics, and smart farming systems. These will further transform agriculture, making it more sustainable and productive."
            }
        ],
        source: "FAO",
        sourceUrl: "#",
        publicationDate: "2026-07-03",
        featured: false
    },
    {
        id: "ED009",
        title: "Sustainable Farming Systems",
        category: "Sustainable Agriculture",
        difficulty: "Intermediate",
        description: "Learn about farming systems that protect the environment while maintaining productivity.",
        estimatedTime: "20 min",
        image: "https://images.unsplash.com/photo-1535431234501-4cfe3b88ed6e?w=800",
        introduction: "Sustainable farming balances productivity with environmental protection. This lesson explores systems that maintain soil health, conserve water, and protect biodiversity.",
        sections: [
            {
                title: "What is Sustainable Agriculture?",
                content: "Sustainable agriculture meets current food needs without compromising future generations. It involves practices that protect soil, water, and biodiversity."
            },
            {
                title: "Organic Farming Practices",
                content: "Organic farming avoids synthetic chemicals, using natural methods for fertility and pest management. It builds soil health and produces food with minimal environmental impact."
            },
            {
                title: "Crop Rotation and Diversity",
                content: "Crop rotation improves soil health and reduces pest pressure. Diverse farming systems are more resilient than monocultures."
            },
            {
                title: "Integrated Nutrient Management",
                content: "Combines organic and inorganic sources of nutrients. This approach optimizes nutrient availability while maintaining soil health."
            },
            {
                title: "Conservation Agriculture",
                content: "Minimum soil disturbance, permanent soil cover, and crop diversity characterize conservation agriculture. It improves soil health and reduces erosion."
            },
            {
                title: "Biodiversity and Ecosystem Services",
                content: "Sustainable farming protects biodiversity and ecosystem services. Healthy ecosystems provide pollination, pest control, and soil fertility."
            }
        ],
        source: "FAO",
        sourceUrl: "#",
        publicationDate: "2026-07-01",
        featured: false
    },
    {
        id: "ED010",
        title: "Farm Management Basics for Smallholders",
        category: "Farm Management",
        difficulty: "Beginner",
        description: "Learn essential farm management principles for smallholder farmers to improve productivity and profitability.",
        estimatedTime: "15 min",
        image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800",
        introduction: "Good farm management is essential for productivity and profitability. This lesson covers basic principles for smallholder farmers.",
        sections: [
            {
                title: "What is Farm Management?",
                content: "Farm management involves planning, organizing, and controlling farm operations. It includes decisions about crops, inputs, labor, and marketing."
            },
            {
                title: "Planning and Goal Setting",
                content: "Set clear goals for production and income. Plan planting, fertilization, and harvesting activities. Good planning saves time and resources."
            },
            {
                title: "Financial Management",
                content: "Track costs, income, and profits. Budget for inputs and equipment. Maintain records to understand farm performance."
            },
            {
                title: "Resource Management",
                content: "Manage land, water, labor, and capital efficiently. Use resources sustainably to maintain productivity."
            },
            {
                title: "Marketing and Selling",
                content: "Understand market requirements and timing. Choose appropriate marketing channels. Good marketing improves farmer incomes."
            },
            {
                title: "Record Keeping and Evaluation",
                content: "Maintain records of all farm activities. Evaluate performance and learn from experience. Continuous improvement is essential."
            }
        ],
        source: "Ethiopian Agricultural Transformation Agency",
        sourceUrl: "#",
        publicationDate: "2026-06-28",
        featured: false
    },
    {
        id: "ED011",
        title: "Maize Production Guide",
        category: "Crop Production",
        difficulty: "Intermediate",
        description: "A comprehensive guide to maize production, from land preparation to harvest and storage.",
        estimatedTime: "25 min",
        image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800",
        introduction: "Maize is a major food and feed crop in Ethiopia. This guide covers all aspects of maize production, from variety selection to post-harvest management.",
        sections: [
            {
                title: "Variety Selection",
                content: "Choose improved maize varieties suited to your area. Consider maturity period, yield potential, and resistance to diseases. The Ethiopian Institute of Agricultural Research has released several improved varieties."
            },
            {
                title: "Land Preparation",
                content: "Prepare land well in advance. Plow and harrow to create a fine seedbed. This ensures good seed-to-soil contact and reduces weed pressure."
            },
            {
                title: "Planting",
                content: "Plant at the right time, usually at the start of the rainy season. Use appropriate spacing and depth. Apply starter fertilizer for early growth."
            },
            {
                title: "Fertilizer Application",
                content: "Apply recommended fertilizers based on soil test results. Split applications ensure nutrients are available throughout the growth cycle."
            },
            {
                title: "Weed Management",
                content: "Control weeds through cultivation, herbicides, and timely weeding. Weeds compete with maize for nutrients, water, and light."
            },
            {
                title: "Harvesting and Storage",
                content: "Harvest when grain moisture is low. Dry thoroughly and store in pest-proof containers. Proper storage maintains quality and reduces losses."
            }
        ],
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publicationDate: "2026-06-25",
        featured: false
    },
    {
        id: "ED012",
        title: "Coffee Production and Quality",
        category: "Crop Production",
        difficulty: "Intermediate",
        description: "Learn about coffee production practices that improve both yield and cup quality.",
        estimatedTime: "20 min",
        image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=800",
        introduction: "Coffee is Ethiopia's most important export crop. Quality production practices can significantly increase farmer incomes. This lesson covers essential coffee production techniques.",
        sections: [
            {
                title: "Coffee Varieties",
                content: "Ethiopia is the center of coffee diversity. Major varieties include Heirloom, Wild Arabica, and improved hybrids. Variety selection affects yield and quality."
            },
            {
                title: "Planting and Establishment",
                content: "Plant coffee in well-prepared soil, using shade trees for optimal growth. Spacing and planting depth affect plant development."
            },
            {
                title: "Nutrition and Fertilization",
                content: "Coffee requires balanced nutrition for optimal production. Use organic and inorganic fertilizers based on soil analysis and plant needs."
            },
            {
                title: "Pest and Disease Management",
                content: "Major coffee pests include coffee berry borer and leaf rust. Integrated pest management strategies protect coffee crops sustainably."
            },
            {
                title: "Harvesting and Processing",
                content: "Harvest coffee cherries at peak ripeness. Processing methods (wet or dry) affect cup quality. Proper processing maintains bean quality."
            },
            {
                title: "Quality Management",
                content: "Quality management involves selection, processing, sorting, and grading. High-quality coffee commands premium prices."
            }
        ],
        source: "Ethiopian Coffee and Tea Authority",
        sourceUrl: "#",
        publicationDate: "2026-06-22",
        featured: false
    },
    {
        id: "ED013",
        title: "Teff Production and Management",
        category: "Ethiopian Agriculture",
        difficulty: "Beginner",
        description: "A guide to teff production, Ethiopia's most important staple crop.",
        estimatedTime: "15 min",
        image: "https://images.unsplash.com/photo-1590090269573-a741d6bea6ef?w=800",
        introduction: "Teff is Ethiopia's staple crop and a source of national pride. Understanding teff production is essential for food security and farmer livelihoods.",
        sections: [
            {
                title: "Teff Varieties",
                content: "Teff has many varieties adapted to different conditions. Varieties differ in color, yield, and maturity. Choose improved varieties for better yields."
            },
            {
                title: "Growing Conditions",
                content: "Teff grows well in a wide range of conditions, from 1,500 to 3,000 meters. It is drought-tolerant and adapts to various soil types."
            },
            {
                title: "Fertilization",
                content: "Teff requires balanced nutrition. Apply fertilizer based on soil tests and recommended rates. Nitrogen is particularly important for leaf growth."
            },
            {
                title: "Weed Management",
                content: "Teff is a small-seeded crop that requires careful weed management. Early weeding is essential for establishing a good stand."
            },
            {
                title: "Harvesting",
                content: "Teff matures in 2-4 months. Harvest when the heads turn golden. Cut, dry, and thresh carefully to preserve grain quality."
            },
            {
                title: "Storage and Marketing",
                content: "Store teff in clean, dry conditions. Market at appropriate times for the best prices. Storage pests should be controlled to reduce losses."
            }
        ],
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publicationDate: "2026-06-20",
        featured: false
    }
];

// ============================================================
// 2. APPLICATION STATE
// ============================================================

const state = {
    allResources: [...educationalData],
    filteredResources: [],
    currentCategory: 'all',
    currentDifficulty: 'all',
    searchTerm: '',
    currentPage: 1,
    itemsPerPage: 9,
    lessonOpen: false
};

// ============================================================
// 3. DOM REFERENCES
// ============================================================

const dom = {
    grid: document.getElementById('resourcesGrid'),
    search: document.getElementById('searchInput'),
    resultsCount: document.getElementById('resultsCount'),
    filterContainer: document.getElementById('filterContainer'),
    difficultyButtons: document.querySelectorAll('.difficulty-btn'),
    featuredCard: document.getElementById('featuredCard'),
    loadMoreBtn: document.getElementById('loadMoreBtn'),
    loadMoreContainer: document.getElementById('loadMoreContainer'),
    emptyState: document.getElementById('emptyState'),
    lessonView: document.getElementById('lessonView'),
    lessonOverlay: document.getElementById('lessonOverlay'),
    lessonPanel: document.getElementById('lessonPanel'),
    lessonContent: document.getElementById('lessonContent'),
    lessonClose: document.getElementById('lessonCloseBtn')
};

// ============================================================
// 4. HELPER FUNCTIONS
// ============================================================

function formatDate(dateString) {
    if (!dateString) return 'Date not available';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

function getTimeAgo(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '';
    const now = new Date();
    const diffMs = now - date;
    const diffMin = Math.floor(diffMs / (1000 * 60));
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    
    if (diffMin < 1) return 'Just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHour < 24) return `${diffHour}h ago`;
    if (diffDay < 7) return `${diffDay}d ago`;
    return formatDate(dateString);
}

function getCategorySlug(category) {
    return category.toLowerCase().replace(/\s+/g, '-');
}

// ============================================================
// 5. RENDER FUNCTIONS
// ============================================================

function renderFeatured(resources) {
    const featured = resources.find(r => r.featured === true) || resources[0];
    if (!featured) {
        dom.featuredCard.innerHTML = '';
        return;
    }
    
    const difficultyClass = featured.difficulty.toLowerCase();
    
    dom.featuredCard.innerHTML = `
        <img class="featured-bg" src="${featured.image}" alt="${featured.title}" onerror="this.style.display='none'">
        <div class="featured-overlay"></div>
        <div class="featured-content">
            <span class="featured-tag">Featured Learning</span>
            <h2 class="featured-title">${featured.title}</h2>
            <div class="featured-meta">
                <span>${featured.category}</span>
                <span class="difficulty-badge">${featured.difficulty}</span>
                <span>${featured.estimatedTime}</span>
            </div>
            <p class="featured-summary">${featured.description}</p>
            <button class="featured-btn" data-id="${featured.id}">Start Learning</button>
        </div>
    `;
    
    dom.featuredCard.querySelector('.featured-btn').addEventListener('click', function(e) {
        e.stopPropagation();
        const id = this.getAttribute('data-id');
        openLesson(id);
    });
    
    dom.featuredCard.addEventListener('click', function() {
        const id = featured.id;
        openLesson(id);
    });
}

function renderCard(resource) {
    const difficultyClass = resource.difficulty.toLowerCase();
    const imageUrl = resource.image || null;
    
    return `
        <div class="resource-card" data-id="${resource.id}">
            <div class="resource-card-image">
                ${imageUrl ? 
                    `<img src="${imageUrl}" alt="${resource.title}" loading="lazy" onerror="this.parentElement.innerHTML='<span class=\\'placeholder-text\\'>Educational photograph</span>'">` :
                    `<span class="placeholder-text">Educational photograph</span>`
                }
            </div>
            <div class="resource-card-body">
                <div class="resource-card-tags">
                    <span class="category-tag">${resource.category}</span>
                    <span class="difficulty-tag ${difficultyClass}">${resource.difficulty}</span>
                </div>
                <h3 class="resource-card-title">${resource.title}</h3>
                <div class="resource-card-time">${resource.estimatedTime}</div>
                <p class="resource-card-summary">${resource.description}</p>
                <div class="resource-card-meta">
                    <span class="source">${resource.source}</span>
                </div>
                <button class="start-btn" data-id="${resource.id}">Start Learning</button>
            </div>
        </div>
    `;
}

function renderGrid(resources) {
    if (resources.length === 0) {
        dom.grid.innerHTML = '';
        dom.emptyState.style.display = 'block';
        dom.resultsCount.textContent = 'Showing 0 resources';
        dom.loadMoreContainer.style.display = 'none';
        return;
    }
    
    dom.emptyState.style.display = 'none';
    
    const start = 0;
    const end = state.currentPage * state.itemsPerPage;
    const visibleResources = resources.slice(start, end);
    
    if (state.currentPage === 1) {
        dom.grid.innerHTML = visibleResources.map(r => renderCard(r)).join('');
    } else {
        const newCards = visibleResources.slice(-state.itemsPerPage).map(r => renderCard(r)).join('');
        dom.grid.insertAdjacentHTML('beforeend', newCards);
    }
    
    dom.resultsCount.textContent = `Showing ${visibleResources.length} of ${resources.length} resources`;
    
    if (resources.length > visibleResources.length) {
        dom.loadMoreContainer.style.display = 'block';
        dom.loadMoreBtn.disabled = false;
    } else {
        dom.loadMoreContainer.style.display = 'none';
    }
    
    document.querySelectorAll('.start-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            openLesson(id);
        });
    });
    
    document.querySelectorAll('.resource-card').forEach(card => {
        card.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            openLesson(id);
        });
    });
}

// ============================================================
// 6. FILTER & SEARCH FUNCTIONS
// ============================================================

function applyFilters() {
    const searchTerm = state.searchTerm.toLowerCase().trim();
    const category = state.currentCategory;
    const difficulty = state.currentDifficulty;
    
    let results = state.allResources.filter(resource => {
        // Search filter
        if (searchTerm) {
            const searchText = (resource.title || '') + ' ' + 
                             (resource.description || '') + ' ' +
                             (resource.introduction || '') + ' ' +
                             (resource.category || '') + ' ' +
                             (resource.difficulty || '') + ' ' +
                             (resource.source || '');
            // Also search section content
            let sectionText = '';
            if (resource.sections) {
                resource.sections.forEach(s => {
                    sectionText += (s.title || '') + ' ' + (s.content || '');
                });
            }
            const fullText = searchText + ' ' + sectionText;
            if (!fullText.toLowerCase().includes(searchTerm)) return false;
        }
        
        // Category filter
        if (category !== 'all') {
            const categorySlug = getCategorySlug(resource.category);
            if (categorySlug !== category) return false;
        }
        
        // Difficulty filter
        if (difficulty !== 'all') {
            if (resource.difficulty.toLowerCase() !== difficulty) return false;
        }
        
        return true;
    });
    
    state.filteredResources = results;
    state.currentPage = 1;
    renderGrid(results);
    renderFeatured(results);
}

function updateActiveFilter(selectedFilter) {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-filter') === selectedFilter);
    });
}

function updateActiveDifficulty(selectedDifficulty) {
    dom.difficultyButtons.forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-difficulty') === selectedDifficulty);
    });
}

// ============================================================
// 7. LESSON VIEW FUNCTIONS
// ============================================================

function openLesson(id) {
    const resource = state.allResources.find(r => r.id === id);
    if (!resource) return;
    
    state.lessonOpen = true;
    
    const date = formatDate(resource.publicationDate);
    const difficultyClass = resource.difficulty.toLowerCase();
    const imageUrl = resource.image || null;
    const sections = resource.sections || [];
    
    let sectionsHtml = '';
    sections.forEach((section, index) => {
        sectionsHtml += `
            <div class="lesson-section">
                <h4 class="lesson-section-title">${index + 1}. ${section.title}</h4>
                <div class="lesson-section-content">${section.content}</div>
            </div>
        `;
    });
    
    dom.lessonContent.innerHTML = `
        <div class="lesson-image">
            ${imageUrl ? 
                `<img src="${imageUrl}" alt="${resource.title}" onerror="this.parentElement.innerHTML='<span class=\\'placeholder-text\\'>Image not available</span>'">` :
                `<span class="placeholder-text">Image not available</span>`
            }
        </div>
        
        <div class="lesson-meta">
            ${resource.category ? `<span class="meta-category">${resource.category}</span>` : ''}
            ${resource.difficulty ? `<span class="meta-difficulty ${difficultyClass}">${resource.difficulty}</span>` : ''}
            ${resource.estimatedTime ? `<span>${resource.estimatedTime}</span>` : ''}
            ${resource.source ? `<span class="meta-source">${resource.source}</span>` : ''}
        </div>
        
        <h2 class="lesson-title">${resource.title}</h2>
        
        ${resource.introduction ? `
            <div class="lesson-introduction">
                ${resource.introduction}
            </div>
        ` : ''}
        
        ${sectionsHtml ? `
            <div class="lesson-sections">
                ${sectionsHtml}
            </div>
        ` : ''}
        
        <button class="lesson-back-btn" id="lessonBackBtn">← Back to Learning Resources</button>
    `;
    
    dom.lessonView.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    
    document.getElementById('lessonBackBtn').addEventListener('click', closeLesson);
}

function closeLesson() {
    state.lessonOpen = false;
    dom.lessonView.style.display = 'none';
    document.body.style.overflow = '';
}

// ============================================================
// 8. LOAD MORE FUNCTION
// ============================================================

function loadMore() {
    state.currentPage++;
    renderGrid(state.filteredResources);
}

// ============================================================
// 9. INITIALIZATION
// ============================================================

function init() {
    state.filteredResources = [...state.allResources];
    renderFeatured(state.filteredResources);
    renderGrid(state.filteredResources);
}

// ============================================================
// 10. EVENT LISTENERS
// ============================================================

// Search
dom.search.addEventListener('input', function() {
    state.searchTerm = this.value;
    applyFilters();
});

// Category filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const filter = this.getAttribute('data-filter');
        state.currentCategory = filter;
        updateActiveFilter(filter);
        applyFilters();
    });
});

// Difficulty filter buttons
dom.difficultyButtons.forEach(btn => {
    btn.addEventListener('click', function() {
        const difficulty = this.getAttribute('data-difficulty');
        state.currentDifficulty = difficulty;
        updateActiveDifficulty(difficulty);
        applyFilters();
    });
});

// Load more
dom.loadMoreBtn.addEventListener('click', loadMore);

// Lesson close
dom.lessonClose.addEventListener('click', closeLesson);
dom.lessonOverlay.addEventListener('click', closeLesson);

// Keyboard shortcut
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (state.lessonOpen) closeLesson();
    }
});

// ============================================================
// 11. START APPLICATION
// ============================================================

document.addEventListener('DOMContentLoaded', init);