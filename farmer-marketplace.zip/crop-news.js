/**
 * AgriNova — Crop News
 * Complete JavaScript with sample data structure for API replacement later
 */

// ============================================================
// 1. SAMPLE DATA (Replace with API data later)
// ============================================================

const cropNewsData = [
    {
        id: "CN001",
        title: "Ethiopian Maize Farmers Report Record Harvest",
        summary: "Farmers across Oromia and Amhara regions report record maize harvests this season due to improved seed varieties and favorable weather conditions.",
        content: "Farmers across the Oromia and Amhara regions of Ethiopia are celebrating record maize harvests this season. The Ethiopian Institute of Agricultural Research reports that the adoption of improved seed varieties, combined with favorable weather conditions and timely fertilizer application, has led to average yields of 4.5 tons per hectare, up from 3.2 tons last year. The surplus production has helped stabilize maize prices in local markets and increased the country's strategic grain reserves.",
        crop: "Maize",
        cropCategory: "Cereals",
        category: "Production",
        location: "Oromia & Amhara, Ethiopia",
        image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800",
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publishedDate: "2026-08-18",
        featured: true
    },
    {
        id: "CN002",
        title: "Coffee Exports Surge as Global Demand Rises",
        summary: "Ethiopian coffee exports have surged by 25% in the past quarter, driven by rising global demand and improved quality from recent harvests.",
        content: "Ethiopian coffee exports have surged by 25% in the past quarter, driven by rising global demand and improved quality from recent harvests. The Ethiopian Coffee and Tea Authority reports that the country exported over 100,000 tons of coffee, generating $400 million in revenue. The increase is attributed to improved processing techniques and expanded market access in Asia and the Middle East. Smallholder coffee farmers have benefited from higher prices, with the premium for specialty coffee reaching record levels.",
        crop: "Coffee",
        cropCategory: "Coffee",
        category: "Export & Import",
        location: "Ethiopia",
        image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=800",
        source: "Ethiopian Coffee and Tea Authority",
        sourceUrl: "#",
        publishedDate: "2026-08-16",
        featured: false
    },
    {
        id: "CN003",
        title: "New Wheat Disease Detected in Tigray Region",
        summary: "Agricultural researchers have detected a new strain of wheat rust in the Tigray region, prompting immediate containment measures.",
        content: "Agricultural researchers from the Ethiopian Institute of Agricultural Research have detected a new strain of wheat rust (Puccinia graminis) in the Tigray region. The disease, which can cause significant yield losses if left unchecked, has been identified in three districts. The Ministry of Agriculture has deployed rapid response teams to contain the outbreak, distributing resistant seed varieties and fungicides to affected farmers. Farmers are advised to report any suspicious symptoms to local agricultural extension officers.",
        crop: "Wheat",
        cropCategory: "Cereals",
        category: "Pest & Disease",
        location: "Tigray, Ethiopia",
        image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800",
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publishedDate: "2026-08-15",
        featured: false
    },
    {
        id: "CN004",
        title: "Teff Farmers Benefit from Improved Seed Distribution",
        summary: "The Ethiopian Agricultural Transformation Agency has distributed improved teff seeds to over 500,000 farmers, boosting production across the highlands.",
        content: "The Ethiopian Agricultural Transformation Agency has distributed improved teff seeds to over 500,000 farmers across the highlands of Ethiopia. The new teff varieties, which are more drought-resistant and higher-yielding, have contributed to a 20% increase in teff production this season. Farmers in Amhara, Oromia, and SNNP regions report better grain quality and improved market prices for their teff. The seed distribution program is part of the government's initiative to boost teff production and ensure food security.",
        crop: "Teff",
        cropCategory: "Cereals",
        category: "Production",
        location: "Amhara, Oromia, SNNP, Ethiopia",
        image: "https://images.unsplash.com/photo-1590090269573-a741d6bea6ef?w=800",
        source: "Ethiopian Agricultural Transformation Agency",
        sourceUrl: "#",
        publishedDate: "2026-08-14",
        featured: false
    },
    {
        id: "CN005",
        title: "Potato Prices Rise as Demand Outstrips Supply",
        summary: "Potato prices in Addis Ababa markets have risen by 30% due to increased demand from processing industries and reduced supply from recent planting delays.",
        content: "Potato prices in Addis Ababa markets have risen by 30% in the past month due to increased demand from processing industries and reduced supply from recent planting delays caused by unseasonal rainfall. The Ethiopian Agricultural Transformation Agency reports that potato production in the central highlands is expected to recover in the coming months as farmers plant a second crop. The price increase has benefited farmers, with many receiving double the price they got at the same time last year.",
        crop: "Potato",
        cropCategory: "Roots",
        category: "Market & Price",
        location: "Addis Ababa, Ethiopia",
        image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800",
        source: "Ethiopian Agricultural Transformation Agency",
        sourceUrl: "#",
        publishedDate: "2026-08-13",
        featured: false
    },
    {
        id: "CN006",
        title: "Pulse Farmers Adopt New Planting Techniques",
        summary: "Ethiopian pulse farmers are adopting new planting techniques that have increased yields by up to 40%, according to recent field trials.",
        content: "Ethiopian pulse farmers are adopting new planting techniques that have increased yields by up to 40%, according to recent field trials conducted by the Ethiopian Institute of Agricultural Research. The techniques include improved row spacing, optimized fertilizer application, and integrated pest management. Faba bean and chickpea farmers in the highlands have reported particularly strong results, with some achieving yields of 3 tons per hectare. The Ministry of Agriculture is now scaling up training programs to reach more farmers.",
        crop: "Faba Bean",
        cropCategory: "Pulses",
        category: "Research",
        location: "Ethiopia",
        image: "https://images.unsplash.com/photo-1590090269573-a741d6bea6ef?w=800",
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publishedDate: "2026-08-12",
        featured: false
    },
    {
        id: "CN007",
        title: "Sorghum Production Boosted by Drought-Resistant Varieties",
        summary: "Farmers in drought-prone areas of Ethiopia are benefiting from new drought-resistant sorghum varieties that maintain yields even with limited rainfall.",
        content: "Farmers in drought-prone areas of Ethiopia are benefiting from new drought-resistant sorghum varieties that maintain yields even with limited rainfall. The Ethiopian Institute of Agricultural Research has released two new varieties, Gibe-1 and Gibe-2, which have shown remarkable performance in the Somali and Afar regions. The varieties require 30% less water than traditional sorghum while producing comparable yields. Over 200,000 farmers have already adopted the new varieties, significantly improving food security in vulnerable areas.",
        crop: "Sorghum",
        cropCategory: "Cereals",
        category: "Research",
        location: "Somali & Afar, Ethiopia",
        image: "https://images.unsplash.com/photo-1598503176737-70af76232a9e?w=800",
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publishedDate: "2026-08-11",
        featured: false
    },
    {
        id: "CN008",
        title: "Barley Farmers Prepare for Planting Season",
        summary: "Barley farmers across the Ethiopian highlands are preparing for the upcoming planting season with improved seed varieties and fertilizer recommendations.",
        content: "Barley farmers across the Ethiopian highlands are preparing for the upcoming planting season with improved seed varieties and fertilizer recommendations from the Ethiopian Institute of Agricultural Research. The new barley varieties, which are resistant to common diseases and have a shorter growing period, are expected to boost production in the face of changing climate patterns. The Ministry of Agriculture has distributed over 10,000 quintals of certified seed to farmers, with training programs underway in all major barley-producing areas.",
        crop: "Barley",
        cropCategory: "Cereals",
        category: "Planting",
        location: "Ethiopian Highlands",
        image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800",
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publishedDate: "2026-08-10",
        featured: false
    },
    {
        id: "CN009",
        title: "Ethiopia Expands Vegetable Export Program",
        summary: "The Ethiopian government has expanded its vegetable export program, targeting new markets in the Middle East and Europe.",
        content: "The Ethiopian government has expanded its vegetable export program, targeting new markets in the Middle East and Europe. The program, which focuses on high-value vegetables such as tomatoes, onions, and peppers, has been successful in establishing quality assurance systems and cold chain logistics. Over 50,000 farmers have been trained in export-quality production, with exports expected to reach $100 million in the current fiscal year. The program is part of the government's strategy to diversify agricultural exports beyond coffee.",
        crop: "Vegetables",
        cropCategory: "Vegetables",
        category: "Export & Import",
        location: "Ethiopia",
        image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800",
        source: "Ethiopian Ministry of Agriculture",
        sourceUrl: "#",
        publishedDate: "2026-08-09",
        featured: false
    },
    {
        id: "CN010",
        title: "Chickpea Market Shows Strong Growth",
        summary: "The chickpea market in Ethiopia is showing strong growth with exports increasing by 35% due to rising international demand.",
        content: "The chickpea market in Ethiopia is showing strong growth with exports increasing by 35% due to rising international demand. Ethiopian chickpeas, known for their quality and taste, have gained popularity in India, Pakistan, and the Middle East. Farmers in the highlands have expanded chickpea production, with area planted increasing by 25% this season. The Ethiopian Pulses Exporters Association reports that chickpea prices have remained stable, providing farmers with reliable income.",
        crop: "Chickpea",
        cropCategory: "Pulses",
        category: "Market & Price",
        location: "Ethiopia",
        image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800",
        source: "Ethiopian Pulses Exporters Association",
        sourceUrl: "#",
        publishedDate: "2026-08-08",
        featured: false
    },
    {
        id: "CN011",
        title: "Climate Adaptation Fund Launched for Farmers",
        summary: "The Ethiopian government has launched a $50 million climate adaptation fund to help farmers cope with changing weather patterns.",
        content: "The Ethiopian government has launched a $50 million climate adaptation fund to help farmers cope with changing weather patterns. The fund will provide financial support for farmers adopting climate-smart agriculture practices, including conservation tillage, water harvesting, and drought-resistant crop varieties. Smallholder farmers in vulnerable areas will receive grants for implementing adaptation measures, with initial disbursements expected to reach 100,000 farmers in the first year. The program is supported by international partners.",
        crop: "All Crops",
        cropCategory: "Other",
        category: "Government",
        location: "Ethiopia",
        image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800",
        source: "Ethiopian Ministry of Agriculture",
        sourceUrl: "#",
        publishedDate: "2026-08-07",
        featured: false
    },
    {
        id: "CN012",
        title: "Sesame Production Faces Challenges from Climate Change",
        summary: "Sesame production in Ethiopia is facing challenges from changing rainfall patterns and increasing pest pressure.",
        content: "Sesame production in Ethiopia is facing challenges from changing rainfall patterns and increasing pest pressure. Farmers in the lowlands report delayed planting and reduced yields due to erratic rainfall. The Ethiopian Institute of Agricultural Research is working on developing drought-tolerant sesame varieties and integrated pest management strategies to address the challenges. Despite these difficulties, sesame remains an important export crop for Ethiopia, with over 1 million farmers relying on it for their livelihoods.",
        crop: "Sesame",
        cropCategory: "Oilseeds",
        category: "Weather & Climate",
        location: "Ethiopia",
        image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800",
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publishedDate: "2026-08-06",
        featured: false
    },
    {
        id: "CN013",
        title: "New Technology Improves Coffee Processing in Ethiopia",
        summary: "Innovative coffee processing technology is helping Ethiopian coffee farmers improve quality and access premium markets.",
        content: "Innovative coffee processing technology is helping Ethiopian coffee farmers improve quality and access premium markets. New equipment for washing, drying, and grading coffee has been installed at cooperative processing facilities across the country. The technology has reduced processing time and improved bean quality, with specialty coffee exports increasing by 30% this year. The program, supported by the Ethiopian Coffee and Tea Authority and the FAO, has trained over 5,000 coffee farmers in quality management.",
        crop: "Coffee",
        cropCategory: "Coffee",
        category: "Technology",
        location: "Ethiopia",
        image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=800",
        source: "FAO",
        sourceUrl: "#",
        publishedDate: "2026-08-05",
        featured: false
    },
    {
        id: "CN014",
        title: "Wheat Harvest Exceeds Expectations in Oromia",
        summary: "The wheat harvest in Oromia has exceeded expectations, with farmers reporting yields 25% above average.",
        content: "The wheat harvest in Oromia has exceeded expectations, with farmers reporting yields 25% above average. The Ethiopian Institute of Agricultural Research attributes the bumper harvest to improved seed varieties, timely fertilizer application, and favorable weather conditions. Farmers in the Arsi and Bale zones have reported particularly strong results, with some achieving yields of 5 tons per hectare. The surplus production has helped replenish the country's strategic grain reserves and stabilize wheat prices in local markets.",
        crop: "Wheat",
        cropCategory: "Cereals",
        category: "Harvest",
        location: "Oromia, Ethiopia",
        image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800",
        source: "Ethiopian Institute of Agricultural Research",
        sourceUrl: "#",
        publishedDate: "2026-08-04",
        featured: false
    },
    {
        id: "CN015",
        title: "Maize Disease Outbreak Contained in Southern Ethiopia",
        summary: "An outbreak of maize lethal necrosis has been successfully contained in southern Ethiopia through rapid response and farmer training.",
        content: "An outbreak of maize lethal necrosis has been successfully contained in the Southern Nations, Nationalities, and Peoples' Region through rapid response and farmer training. The Ethiopian Plant Protection Agency mobilized teams to affected areas, providing training on disease identification and management. Over 50,000 farmers participated in awareness campaigns, leading to early detection and management of the disease. The Ministry of Agriculture reports that only 5% of maize fields were affected, well below initial projections.",
        crop: "Maize",
        cropCategory: "Cereals",
        category: "Pest & Disease",
        location: "SNNP, Ethiopia",
        image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800",
        source: "Ethiopian Plant Protection Agency",
        sourceUrl: "#",
        publishedDate: "2026-08-03",
        featured: false
    }
];

// ============================================================
// 2. APPLICATION STATE
// ============================================================

const state = {
    allNews: [...cropNewsData],
    filteredNews: [],
    currentFilter: 'all',
    searchTerm: '',
    currentPage: 1,
    itemsPerPage: 9,
    detailOpen: false
};

// ============================================================
// 3. DOM REFERENCES
// ============================================================

const dom = {
    grid: document.getElementById('newsGrid'),
    search: document.getElementById('searchInput'),
    resultsCount: document.getElementById('resultsCount'),
    filterContainer: document.getElementById('filterContainer'),
    featuredCard: document.getElementById('featuredCard'),
    loadMoreBtn: document.getElementById('loadMoreBtn'),
    loadMoreContainer: document.getElementById('loadMoreContainer'),
    emptyState: document.getElementById('emptyState'),
    detailView: document.getElementById('detailView'),
    detailOverlay: document.getElementById('detailOverlay'),
    detailPanel: document.getElementById('detailPanel'),
    detailContent: document.getElementById('detailContent'),
    detailClose: document.getElementById('detailCloseBtn')
};

// ============================================================
// 4. HELPER FUNCTIONS
// ============================================================

function formatDate(dateString) {
    if (!dateString) return 'Date not available';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

function getTimeAgo(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '';
    const now = new Date();
    const diffMs = now - date;
    const diffMin = Math.floor(diffMs / (1000 * 60));
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    
    if (diffMin < 1) return 'Just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHour < 24) return `${diffHour}h ago`;
    if (diffDay < 7) return `${diffDay}d ago`;
    return formatDate(dateString);
}

function getCropCategoryClass(category) {
    const map = {
        'Cereals': 'cereals',
        'Pulses': 'pulses',
        'Oilseeds': 'oilseeds',
        'Coffee': 'coffee',
        'Fruits': 'fruits',
        'Vegetables': 'vegetables',
        'Roots': 'roots',
        'Other': 'other'
    };
    return map[category] || 'other';
}

// ============================================================
// 5. RENDER FUNCTIONS
// ============================================================

function renderFeatured(articles) {
    const featured = articles.find(a => a.featured === true) || articles[0];
    if (!featured) {
        dom.featuredCard.innerHTML = '';
        return;
    }
    
    dom.featuredCard.innerHTML = `
        <div class="featured-image">
            ${featured.image ? 
                `<img src="${featured.image}" alt="${featured.title}" loading="lazy" onerror="this.parentElement.innerHTML='<span class=\\'placeholder-text\\'>Agricultural photograph</span>'">` :
                `<span class="placeholder-text">Agricultural photograph</span>`
            }
        </div>
        <div class="featured-content">
            <span class="featured-tag">Featured Crop News</span>
            <span class="featured-crop">${featured.crop}</span>
            <h2 class="featured-title">${featured.title}</h2>
            <div class="featured-meta">
                ${featured.location ? `<span class="location">${featured.location}</span>` : ''}
                ${featured.publishedDate ? ` · ${formatDate(featured.publishedDate)}` : ''}
            </div>
            <p class="featured-summary">${featured.summary}</p>
            <button class="featured-btn" data-id="${featured.id}">Read More</button>
        </div>
    `;
    
    dom.featuredCard.querySelector('.featured-btn').addEventListener('click', function(e) {
        e.stopPropagation();
        const id = this.getAttribute('data-id');
        openDetail(id);
    });
    
    dom.featuredCard.addEventListener('click', function() {
        const id = featured.id;
        openDetail(id);
    });
}

function renderNewsCard(article) {
    const cropTag = article.crop.toUpperCase();
    const categoryTag = article.category || 'News';
    const date = getTimeAgo(article.publishedDate);
    
    return `
        <div class="news-card" data-id="${article.id}">
            <div class="news-card-image">
                ${article.image ? 
                    `<img src="${article.image}" alt="${article.title}" loading="lazy" onerror="this.parentElement.innerHTML='<span class=\\'placeholder-text\\'>Agricultural photograph</span>'">` :
                    `<span class="placeholder-text">Agricultural photograph</span>`
                }
            </div>
            <div class="news-card-body">
                <div class="news-card-tags">
                    <span class="crop-tag">${cropTag}</span>
                    <span class="category-tag">${categoryTag}</span>
                </div>
                <h3 class="news-card-title">${article.title}</h3>
                <p class="news-card-summary">${article.summary}</p>
                <div class="news-card-meta">
                    <span class="source">${article.source}</span>
                    <span class="date">${date}</span>
                </div>
                <button class="read-more-btn" data-id="${article.id}">Read More</button>
            </div>
        </div>
    `;
}

function renderGrid(articles) {
    if (articles.length === 0) {
        dom.grid.innerHTML = '';
        dom.emptyState.style.display = 'block';
        dom.resultsCount.textContent = 'Showing 0 articles';
        dom.loadMoreContainer.style.display = 'none';
        return;
    }
    
    dom.emptyState.style.display = 'none';
    
    const start = 0;
    const end = state.currentPage * state.itemsPerPage;
    const visibleArticles = articles.slice(start, end);
    
    // If first page, render all; else append
    if (state.currentPage === 1) {
        dom.grid.innerHTML = visibleArticles.map(a => renderNewsCard(a)).join('');
    } else {
        const newCards = visibleArticles.slice(-state.itemsPerPage).map(a => renderNewsCard(a)).join('');
        dom.grid.insertAdjacentHTML('beforeend', newCards);
    }
    
    dom.resultsCount.textContent = `Showing ${visibleArticles.length} of ${articles.length} articles`;
    
    // Show/hide load more
    if (articles.length > visibleArticles.length) {
        dom.loadMoreContainer.style.display = 'block';
        dom.loadMoreBtn.disabled = false;
    } else {
        dom.loadMoreContainer.style.display = 'none';
    }
    
    // Attach click events
    document.querySelectorAll('.read-more-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const id = this.getAttribute('data-id');
            openDetail(id);
        });
    });
    
    document.querySelectorAll('.news-card').forEach(card => {
        card.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            openDetail(id);
        });
    });
}

// ============================================================
// 6. FILTER & SEARCH FUNCTIONS
// ============================================================

function applyFilters() {
    const searchTerm = state.searchTerm.toLowerCase().trim();
    const filter = state.currentFilter;
    
    let results = state.allNews.filter(article => {
        // Search filter
        if (searchTerm) {
            const searchText = (article.title || '') + ' ' + 
                             (article.summary || '') + ' ' +
                             (article.content || '') + ' ' +
                             (article.crop || '') + ' ' +
                             (article.category || '') + ' ' +
                             (article.location || '');
            if (!searchText.toLowerCase().includes(searchTerm)) return false;
        }
        
        // Category filter
        if (filter !== 'all') {
            const categoryMap = {
                'cereals': 'Cereals',
                'pulses': 'Pulses',
                'oilseeds': 'Oilseeds',
                'coffee': 'Coffee',
                'fruits': 'Fruits',
                'vegetables': 'Vegetables',
                'roots': 'Roots',
                'other': 'Other'
            };
            const targetCategory = categoryMap[filter];
            if (article.cropCategory !== targetCategory) return false;
        }
        
        return true;
    });
    
    state.filteredNews = results;
    state.currentPage = 1;
    renderGrid(results);
    renderFeatured(results);
}

function updateActiveFilter(selectedFilter) {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-filter') === selectedFilter);
    });
}

// ============================================================
// 7. DETAIL VIEW FUNCTIONS
// ============================================================

function openDetail(id) {
    const article = state.allNews.find(a => a.id === id);
    if (!article) return;
    
    state.detailOpen = true;
    
    const crops = article.crop ? [article.crop] : [];
    const date = formatDate(article.publishedDate);
    
    dom.detailContent.innerHTML = `
        <div class="detail-image">
            ${article.image ? 
                `<img src="${article.image}" alt="${article.title}" onerror="this.parentElement.innerHTML='<span class=\\'placeholder-text\\'>Image not available</span>'">` :
                `<span class="placeholder-text">Image not available</span>`
            }
        </div>
        
        <div class="detail-meta">
            ${article.source ? `<span class="meta-source">${article.source}</span>` : ''}
            ${date ? `<span>${date}</span>` : ''}
            ${article.location ? `<span>${article.location}</span>` : ''}
            ${article.category ? `<span class="meta-category">${article.category}</span>` : ''}
        </div>
        
        <h2 class="detail-title">${article.title}</h2>
        
        ${article.crop ? `
            <div class="detail-section">
                <h4 class="detail-section-title">Crop</h4>
                <div class="detail-section-content">
                    <span class="tag highlight">${article.crop}</span>
                    ${article.cropCategory ? `<span class="tag">${article.cropCategory}</span>` : ''}
                </div>
            </div>
        ` : ''}
        
        <div class="detail-content-text">
            ${article.content ? article.content.split('\n').map(p => p.trim() ? `<p>${p}</p>` : '').join('') : article.summary}
        </div>
        
        <button class="detail-back-btn" id="detailBackBtn">← Back to Crop News</button>
    `;
    
    dom.detailView.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    
    document.getElementById('detailBackBtn').addEventListener('click', closeDetail);
}

function closeDetail() {
    state.detailOpen = false;
    dom.detailView.style.display = 'none';
    document.body.style.overflow = '';
}

// ============================================================
// 8. LOAD MORE FUNCTION
// ============================================================

function loadMore() {
    state.currentPage++;
    renderGrid(state.filteredNews);
}

// ============================================================
// 9. INITIALIZATION
// ============================================================

function init() {
    state.filteredNews = [...state.allNews];
    renderFeatured(state.filteredNews);
    renderGrid(state.filteredNews);
}

// ============================================================
// 10. EVENT LISTENERS
// ============================================================

// Search
dom.search.addEventListener('input', function() {
    state.searchTerm = this.value;
    applyFilters();
});

// Filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const filter = this.getAttribute('data-filter');
        state.currentFilter = filter;
        updateActiveFilter(filter);
        applyFilters();
    });
});

// Load more
dom.loadMoreBtn.addEventListener('click', loadMore);

// Detail close
dom.detailClose.addEventListener('click', closeDetail);
dom.detailOverlay.addEventListener('click', closeDetail);

// Keyboard shortcut
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (state.detailOpen) closeDetail();
    }
});

// ============================================================
// 11. START APPLICATION
// ============================================================

document.addEventListener('DOMContentLoaded', init);