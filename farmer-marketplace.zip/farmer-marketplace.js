(function() {
    "use strict";

    // ============================================================
    // STORAGE FUNCTIONS
    // ============================================================

    function getListings() {
        var raw = localStorage.getItem('agrinova_marketplace_listings');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveListings(listings) {
        localStorage.setItem('agrinova_marketplace_listings', JSON.stringify(listings));
    }

    function getCart() {
        var raw = localStorage.getItem('agrinova_marketplace_cart');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveCart(cart) {
        localStorage.setItem('agrinova_marketplace_cart', JSON.stringify(cart));
    }

    function getOrders() {
        var raw = localStorage.getItem('agrinova_marketplace_orders');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveOrders(orders) {
        localStorage.setItem('agrinova_marketplace_orders', JSON.stringify(orders));
    }

    function getSaved() {
        var raw = localStorage.getItem('agrinova_marketplace_saved');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveSaved(saved) {
        localStorage.setItem('agrinova_marketplace_saved', JSON.stringify(saved));
    }

    function getCommunityFollows() {
        var raw = localStorage.getItem('agrinova_community_follows');
        if (!raw) return { followers: {}, following: {} };
        try { return JSON.parse(raw); } catch { return { followers: {}, following: {} }; }
    }

    // ============================================================
    // FARMER DATA HELPERS
    // ============================================================

    function getFarmer() {
        var raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getCurrentUserId() {
        var farmer = getFarmer();
        if (!farmer) return null;
        return farmer.id || farmer.email || 'farmer_' + Date.now();
    }

    function getCommunityDisplayName() {
        var farmer = getFarmer();
        if (!farmer) return 'Farmer';
        var fullName = farmer.name || farmer.fullName || farmer.firstName || 'Farmer';
        var parts = fullName.trim().split(/\s+/);
        if (parts.length >= 2) {
            return parts[0] + ' ' + parts[1];
        }
        return parts[0] || 'Farmer';
    }

    function getProfilePicture() {
        var saved = localStorage.getItem('agrinova_profileImage');
        if (saved) return saved;
        var farmer = getFarmer();
        if (farmer && farmer.profileImage) return farmer.profileImage;
        return null;
    }

    function getFarmerNameById(userId) {
        var farmers = getFarmersList();
        if (farmers[userId]) return farmers[userId].displayName || 'Farmer';
        return 'Farmer';
    }

    function getFarmerProfilePicture(userId) {
        var farmers = getFarmersList();
        if (farmers[userId]) return farmers[userId].profilePicture || null;
        return null;
    }

    function getFarmersList() {
        var raw = localStorage.getItem('agrinova_farmers_list');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    // ============================================================
    // STATE
    // ============================================================

    var state = {
        currentTab: 'marketplace',
        editingListingId: null,
        tempPhotos: [],
        paymentProofData: null
    };

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova Farmer Marketplace Initializing...');

        var farmer = getFarmer();
        if (!farmer) {
            document.getElementById('productsContainer').innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-store"></i>
                    <h3>Welcome to the Marketplace</h3>
                    <p>Please log in to buy and sell agricultural products.</p>
                    <a href="index.html" class="btn-primary">Login</a>
                </div>
            `;
            return;
        }

        updateNav();
        renderProducts();
        updateCartBadge();

        console.log('AgriNova Farmer Marketplace Ready.');
    }

    // ============================================================
    // NAV
    // ============================================================

    function updateNav() {
        var name = getCommunityDisplayName();
        document.getElementById('navName').textContent = name;
        var pic = getProfilePicture();
        var avatar = document.getElementById('navAvatar');
        if (pic) {
            avatar.innerHTML = '<img src="' + pic + '" alt="Profile">';
        } else {
            avatar.innerHTML = '<i class="fas fa-user"></i>';
        }
    }

    window.switchTab = function(tab) {
        state.currentTab = tab;
        document.querySelectorAll('.nav-tab').forEach(function(el) {
            el.classList.toggle('active', el.dataset.tab === tab);
        });
        renderProducts();
    };

    // ============================================================
    // LISTING PHOTOS
    // ============================================================

    window.handleListingPhotos = function(input) {
        var files = input.files;
        if (!files.length) return;

        var preview = document.getElementById('listingPhotoPreview');

        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            if (file.size > 2 * 1024 * 1024) {
                showToast('Photo must be under 2MB.', 'error');
                continue;
            }
            if (!file.type.startsWith('image/')) {
                showToast('Please select an image file.', 'error');
                continue;
            }
            var reader = new FileReader();
            reader.onload = function(ev) {
                var dataUrl = ev.target.result;
                state.tempPhotos.push(dataUrl);
                var div = document.createElement('div');
                div.className = 'photo-preview-item';
                div.innerHTML = '<img src="' + dataUrl + '" alt="Product photo"><div class="remove-photo" onclick="this.parentElement.remove(); state.tempPhotos = state.tempPhotos.filter(function(p) { return p !== "' + dataUrl + '"; });">&times;</div>';
                preview.appendChild(div);
                preview.style.display = 'grid';
            };
            reader.readAsDataURL(file);
        }
        input.value = '';
    };

    // ============================================================
    // CREATE LISTING
    // ============================================================

    window.openCreateListing = function(editId) {
        state.editingListingId = editId || null;
        state.tempPhotos = [];
        document.getElementById('listingPhotoPreview').innerHTML = '';
        document.getElementById('listingPhotoPreview').style.display = 'none';

        if (editId) {
            var listings = getListings();
            var listing = listings.find(function(l) { return l.id === editId; });
            if (listing) {
                document.getElementById('listingModalTitle').textContent = 'Edit Listing';
                document.getElementById('listingProductName').value = listing.productName || '';
                document.getElementById('listingCategory').value = listing.category || 'grains';
                document.getElementById('listingUnit').value = listing.unit || 'kg';
                document.getElementById('listingQuantity').value = listing.quantityAvailable || '';
                document.getElementById('listingPrice').value = listing.pricePerUnit || '';
                document.getElementById('listingMinOrder').value = listing.minimumOrder || '';
                document.getElementById('listingDescription').value = listing.description || '';
                if (listing.images && listing.images.length > 0) {
                    state.tempPhotos = listing.images.slice();
                    var preview = document.getElementById('listingPhotoPreview');
                    state.tempPhotos.forEach(function(img) {
                        var div = document.createElement('div');
                        div.className = 'photo-preview-item';
                        div.innerHTML = '<img src="' + img + '" alt="Product photo"><div class="remove-photo" onclick="this.parentElement.remove(); state.tempPhotos = state.tempPhotos.filter(function(p) { return p !== "' + img + '"; });">&times;</div>';
                        preview.appendChild(div);
                    });
                    preview.style.display = 'grid';
                }
            }
        } else {
            document.getElementById('listingModalTitle').textContent = 'Create Listing';
            document.getElementById('listingProductName').value = '';
            document.getElementById('listingCategory').value = 'grains';
            document.getElementById('listingUnit').value = 'kg';
            document.getElementById('listingQuantity').value = '';
            document.getElementById('listingPrice').value = '';
            document.getElementById('listingMinOrder').value = '';
            document.getElementById('listingDescription').value = '';
        }

        openModal('createListingModal');
    };

    window.submitListing = function() {
        var name = document.getElementById('listingProductName').value.trim();
        var category = document.getElementById('listingCategory').value;
        var unit = document.getElementById('listingUnit').value;
        var quantity = parseFloat(document.getElementById('listingQuantity').value);
        var price = parseFloat(document.getElementById('listingPrice').value);
        var minOrder = parseFloat(document.getElementById('listingMinOrder').value) || 0;
        var description = document.getElementById('listingDescription').value.trim();

        if (!name) { showToast('Please enter a product name.', 'error'); return; }
        if (!quantity || quantity <= 0) { showToast('Please enter a valid quantity.', 'error'); return; }
        if (!price || price <= 0) { showToast('Please enter a valid price.', 'error'); return; }

        var userId = getCurrentUserId();
        if (!userId) { showToast('Please log in.', 'error'); return; }

        var listings = getListings();

        if (state.editingListingId) {
            var index = listings.findIndex(function(l) { return l.id === state.editingListingId; });
            if (index !== -1) {
                listings[index] = {
                    ...listings[index],
                    productName: name,
                    category: category,
                    unit: unit,
                    quantityAvailable: quantity,
                    pricePerUnit: price,
                    minimumOrder: minOrder,
                    description: description,
                    images: state.tempPhotos,
                    updatedAt: new Date().toISOString()
                };
                saveListings(listings);
                showToast('Listing updated!', 'success');
            }
        } else {
            var newListing = {
                id: 'listing_' + Date.now(),
                sellerId: userId,
                sellerName: getCommunityDisplayName(),
                sellerProfilePic: getProfilePicture(),
                productName: name,
                category: category,
                unit: unit,
                quantityAvailable: quantity,
                pricePerUnit: price,
                minimumOrder: minOrder || 0,
                description: description,
                images: state.tempPhotos,
                status: 'active',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            listings.unshift(newListing);
            saveListings(listings);
            showToast('Listing published!', 'success');
        }

        closeModal('createListingModal');
        renderProducts();
    };

    // ============================================================
    // RENDER PRODUCTS
    // ============================================================

    function renderProducts() {
        var container = document.getElementById('productsContainer');
        var listings = getListings();
        var userId = getCurrentUserId();
        var tab = state.currentTab;

        // Apply filters
        var search = document.getElementById('searchInput') ? document.getElementById('searchInput').value.toLowerCase() : '';
        var category = document.getElementById('filterCategory') ? document.getElementById('filterCategory').value : 'all';
        var sort = document.getElementById('filterSort') ? document.getElementById('filterSort').value : 'newest';

        var filtered = listings;

        // Tab filtering
        if (tab === 'listings') {
            filtered = filtered.filter(function(l) { return l.sellerId === userId; });
        } else if (tab === 'saved') {
            var saved = getSaved();
            filtered = filtered.filter(function(l) { return saved.indexOf(l.id) !== -1; });
        } else if (tab === 'orders' || tab === 'sales') {
            renderOrdersTab(tab);
            return;
        } else {
            // Marketplace - only show active listings from others
            filtered = filtered.filter(function(l) { 
                return l.status === 'active' && l.quantityAvailable > 0;
            });
        }

        // Search
        if (search) {
            filtered = filtered.filter(function(l) {
                return l.productName.toLowerCase().indexOf(search) !== -1 ||
                       l.sellerName.toLowerCase().indexOf(search) !== -1;
            });
        }

        // Category
        if (category !== 'all') {
            filtered = filtered.filter(function(l) { return l.category === category; });
        }

        // Sort
        if (sort === 'price_low') {
            filtered.sort(function(a, b) { return a.pricePerUnit - b.pricePerUnit; });
        } else if (sort === 'price_high') {
            filtered.sort(function(a, b) { return b.pricePerUnit - a.pricePerUnit; });
        } else {
            filtered.sort(function(a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
        }

        // Check if no results
        if (filtered.length === 0) {
            var msg = tab === 'listings' ? 'You have no active listings.' :
                      tab === 'saved' ? 'You haven\'t saved any products yet.' :
                      'No agricultural products match your search.';
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-store"></i>
                    <h3>${tab === 'listings' ? 'No Listings' : tab === 'saved' ? 'No Saved Products' : 'No Products Found'}</h3>
                    <p>${msg}</p>
                    ${tab === 'listings' ? '<button class="btn-primary" onclick="openCreateListing()"><i class="fas fa-plus"></i> Create Listing</button>' : ''}
                </div>
            `;
            return;
        }

        var html = '';
        var cart = getCart();

        for (var i = 0; i < filtered.length; i++) {
            var l = filtered[i];
            var isOwner = l.sellerId === userId;
            var inCart = cart.some(function(c) { return c.listingId === l.id; });
            var isSaved = getSaved().indexOf(l.id) !== -1;
            var img = l.images && l.images.length > 0 ? l.images[0] : null;

            html += `
                <div class="product-card" onclick="viewProduct('${l.id}')">
                    <img class="product-card-image" src="${img || 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'300\' height=\'200\'%3E%3Crect fill=\'%23EAE7DE\' width=\'300\' height=\'200\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' text-anchor=\'middle\' dy=\'.3em\' fill=\'%236B746E\' font-size=\'14\' font-family=\'Inter\'%3ENo Image%3C/text%3E%3C/svg%3E'}" alt="${l.productName}">
                    <div class="product-card-body">
                        <div class="product-card-name">${l.productName}</div>
                        <div class="product-card-seller" onclick="event.stopPropagation(); viewSellerProfile('${l.sellerId}')">${l.sellerName}</div>
                        <div class="product-card-details">
                            <span class="product-card-price">${l.pricePerUnit} ETB / ${l.unit}</span>
                            <span class="product-card-quantity">${l.quantityAvailable} ${l.unit}</span>
                        </div>
                        <div class="product-card-actions">
                            ${!isOwner && l.quantityAvailable > 0 ? `<button class="btn-primary btn-sm" onclick="event.stopPropagation(); addToCart('${l.id}')"><i class="fas fa-cart-plus"></i> Add</button>` : ''}
                            ${isOwner ? `<button class="btn-secondary btn-sm" onclick="event.stopPropagation(); openCreateListing('${l.id}')"><i class="fas fa-edit"></i></button>
                                        <button class="btn-danger btn-sm" onclick="event.stopPropagation(); deleteListing('${l.id}')"><i class="fas fa-trash"></i></button>` : ''}
                            <button class="btn-secondary btn-sm" onclick="event.stopPropagation(); toggleSaved('${l.id}')" style="${isSaved ? 'color:#B85C45;' : ''}">
                                <i class="fas ${isSaved ? 'fa-heart' : 'fa-heart'}"></i>
                            </button>
                        </div>
                        ${l.quantityAvailable <= 0 ? '<div class="sold-out">SOLD OUT</div>' : ''}
                    </div>
                </div>
            `;
        }

        container.innerHTML = html;
    }

    // ============================================================
    // VIEW PRODUCT
    // ============================================================

    window.viewProduct = function(listingId) {
        var listings = getListings();
        var listing = listings.find(function(l) { return l.id === listingId; });
        if (!listing) { showToast('Product not found.', 'error'); return; }

        document.getElementById('productDetailTitle').textContent = listing.productName;

        var img = listing.images && listing.images.length > 0 ? listing.images[0] : null;
        var additionalImages = listing.images && listing.images.length > 1 ? listing.images.slice(1) : [];

        var imagesHtml = '';
        if (img) {
            imagesHtml = `<img src="${img}" alt="${listing.productName}" style="width:100%; max-height:300px; object-fit:cover; border-radius:12px; cursor:pointer;" onclick="viewImage('${img}')">`;
            if (additionalImages.length > 0) {
                imagesHtml += '<div style="display:flex; gap:0.3rem; margin-top:0.3rem; flex-wrap:wrap;">';
                additionalImages.forEach(function(im) {
                    imagesHtml += `<img src="${im}" alt="Additional" style="width:60px; height:60px; object-fit:cover; border-radius:6px; cursor:pointer;" onclick="viewImage('${im}')">`;
                });
                imagesHtml += '</div>';
            }
        } else {
            imagesHtml = '<div style="background:#EAE7DE; height:200px; border-radius:12px; display:flex; align-items:center; justify-content:center; color:#6B746E;">No image available</div>';
        }

        var isOwner = listing.sellerId === getCurrentUserId();
        var cart = getCart();
        var inCart = cart.some(function(c) { return c.listingId === listing.id; });
        var isSaved = getSaved().indexOf(listing.id) !== -1;

        var html = `
            <div style="display:grid; gap:1rem;">
                ${imagesHtml}
                <div>
                    <div style="font-size:1.2rem; font-weight:600; color:#0B3D2E;">${listing.productName}</div>
                    <div style="color:#6B746E; cursor:pointer;" onclick="closeModal('productDetailModal'); viewSellerProfile('${listing.sellerId}')">
                        By: <span style="color:#2F7D4A;">${listing.sellerName}</span>
                    </div>
                </div>
                ${listing.description ? `<div style="color:#1F2D26;">${listing.description}</div>` : ''}
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.5rem; background:#F7F6F0; padding:1rem; border-radius:12px;">
                    <div><strong>Price:</strong> ${listing.pricePerUnit} ETB / ${listing.unit}</div>
                    <div><strong>Available:</strong> ${listing.quantityAvailable} ${listing.unit}</div>
                    ${listing.minimumOrder > 0 ? `<div><strong>Min Order:</strong> ${listing.minimumOrder} ${listing.unit}</div>` : ''}
                    <div><strong>Listed:</strong> ${new Date(listing.createdAt).toLocaleDateString()}</div>
                </div>
                <div style="display:flex; gap:0.8rem; flex-wrap:wrap;">
                    ${!isOwner && listing.quantityAvailable > 0 ? `
                        <div style="display:flex; align-items:center; gap:0.5rem;">
                            <label style="font-weight:500;">Qty:</label>
                            <div style="display:flex; align-items:center; gap:0.3rem;">
                                <button class="btn-secondary btn-sm" onclick="changeQty('${listing.id}', -1)">-</button>
                                <span id="qty_${listing.id}" style="min-width:40px; text-align:center;">1</span>
                                <button class="btn-secondary btn-sm" onclick="changeQty('${listing.id}', 1)">+</button>
                            </div>
                        </div>
                        <button class="btn-primary" onclick="addToCartWithQty('${listing.id}')">
                            <i class="fas fa-cart-plus"></i> Add to Cart
                        </button>
                    ` : ''}
                    ${isOwner ? `<button class="btn-secondary" onclick="closeModal('productDetailModal'); openCreateListing('${listing.id}')"><i class="fas fa-edit"></i> Edit</button>` : ''}
                    <button class="btn-secondary" onclick="toggleSaved('${listing.id}')" style="${isSaved ? 'color:#B85C45;' : ''}">
                        <i class="fas ${isSaved ? 'fa-heart' : 'fa-heart'}"></i> ${isSaved ? 'Saved' : 'Save'}
                    </button>
                    ${!isOwner ? `<button class="btn-secondary" onclick="shareProduct('${listing.id}')"><i class="fas fa-share-alt"></i> Share</button>` : ''}
                </div>
            </div>
        `;

        document.getElementById('productDetailContent').innerHTML = html;
        openModal('productDetailModal');
    };

    // ============================================================
    // QUANTITY CONTROLS
    // ============================================================

    window.changeQty = function(listingId, delta) {
        var span = document.getElementById('qty_' + listingId);
        if (!span) return;
        var current = parseInt(span.textContent) || 1;
        var newVal = current + delta;
        if (newVal < 1) newVal = 1;
        span.textContent = newVal;
    };

    window.addToCartWithQty = function(listingId) {
        var span = document.getElementById('qty_' + listingId);
        var qty = parseInt(span ? span.textContent : '1');
        addToCart(listingId, qty);
    };

    // ============================================================
    // CART
    // ============================================================

    window.addToCart = function(listingId, qty) {
        qty = qty || 1;
        var listings = getListings();
        var listing = listings.find(function(l) { return l.id === listingId; });
        if (!listing) { showToast('Product not found.', 'error'); return; }

        if (listing.quantityAvailable <= 0) {
            showToast('This product is sold out.', 'warning');
            return;
        }

        var cart = getCart();
        var existing = cart.find(function(c) { return c.listingId === listingId; });

        if (existing) {
            existing.quantity += qty;
            if (existing.quantity > listing.quantityAvailable) {
                existing.quantity = listing.quantityAvailable;
                showToast('Quantity adjusted to available stock.', 'warning');
            }
        } else {
            cart.push({
                listingId: listingId,
                listing: listing,
                quantity: Math.min(qty, listing.quantityAvailable)
            });
        }

        saveCart(cart);
        updateCartBadge();
        showToast('Added to cart!', 'success');
        renderProducts();
    };

    window.removeFromCart = function(listingId) {
        var cart = getCart();
        cart = cart.filter(function(c) { return c.listingId !== listingId; });
        saveCart(cart);
        updateCartBadge();
        renderCart();
        showToast('Removed from cart.', 'info');
    };

    window.updateCartQty = function(listingId, delta) {
        var cart = getCart();
        var item = cart.find(function(c) { return c.listingId === listingId; });
        if (!item) return;

        var newQty = item.quantity + delta;
        if (newQty <= 0) {
            removeFromCart(listingId);
            return;
        }

        var listings = getListings();
        var listing = listings.find(function(l) { return l.id === listingId; });
        if (listing && newQty > listing.quantityAvailable) {
            showToast('Not enough stock available.', 'warning');
            newQty = listing.quantityAvailable;
        }

        item.quantity = newQty;
        saveCart(cart);
        updateCartBadge();
        renderCart();
    };

    function updateCartBadge() {
        var cart = getCart();
        var total = cart.reduce(function(sum, c) { return sum + c.quantity; }, 0);
        var badge = document.getElementById('cartBadge');
        if (total > 0) {
            badge.textContent = total;
            badge.classList.add('show');
        } else {
            badge.classList.remove('show');
        }
    }

    window.showCart = function() {
        renderCart();
        openModal('cartModal');
    };

    function renderCart() {
        var container = document.getElementById('cartContent');
        var cart = getCart();

        if (cart.length === 0) {
            container.innerHTML = `
                <div class="empty-state" style="padding:1.5rem;">
                    <i class="fas fa-shopping-cart"></i>
                    <p>Your cart is empty.</p>
                    <button class="btn-secondary" onclick="closeModal('cartModal')">Browse Products</button>
                </div>
            `;
            return;
        }

        var html = '';
        var total = 0;

        // Group by seller
        var sellerGroups = {};
        cart.forEach(function(item) {
            var sellerId = item.listing.sellerId;
            if (!sellerGroups[sellerId]) {
                sellerGroups[sellerId] = {
                    sellerName: item.listing.sellerName,
                    items: []
                };
            }
            sellerGroups[sellerId].items.push(item);
        });

        var sellerIds = Object.keys(sellerGroups);
        for (var si = 0; si < sellerIds.length; si++) {
            var sid = sellerIds[si];
            var group = sellerGroups[sid];
            html += `<div style="margin-bottom:0.5rem; font-weight:600; color:#0B3D2E;">Seller: ${group.sellerName}</div>`;

            for (var ci = 0; ci < group.items.length; ci++) {
                var item = group.items[ci];
                var l = item.listing;
                var subtotal = l.pricePerUnit * item.quantity;
                total += subtotal;
                var img = l.images && l.images.length > 0 ? l.images[0] : null;

                html += `
                    <div class="cart-item">
                        ${img ? `<img src="${img}" alt="${l.productName}">` : `<div style="width:60px; height:60px; background:#EAE7DE; border-radius:8px; flex-shrink:0;"></div>`}
                        <div class="cart-item-info">
                            <div class="cart-item-name">${l.productName}</div>
                            <div class="cart-item-seller">${l.pricePerUnit} ETB / ${l.unit}</div>
                            <div class="cart-item-details">
                                <div class="cart-item-qty">
                                    <button onclick="updateCartQty('${l.id}', -1)">-</button>
                                    <span>${item.quantity}</span>
                                    <button onclick="updateCartQty('${l.id}', 1)">+</button>
                                </div>
                                <span style="font-weight:500;">${subtotal.toFixed(2)} ETB</span>
                                <button class="cart-item-remove" onclick="removeFromCart('${l.id}')">Remove</button>
                            </div>
                        </div>
                    </div>
                `;
            }
        }

        html += `
            <div class="cart-total">Total: ${total.toFixed(2)} ETB</div>
            <button class="btn-primary" onclick="closeModal('cartModal'); proceedToCheckout()" style="width:100%;">
                Proceed to Checkout
            </button>
        `;

        container.innerHTML = html;
    }

    // ============================================================
    // CHECKOUT
    // ============================================================

    window.proceedToCheckout = function() {
        var cart = getCart();
        if (cart.length === 0) {
            showToast('Your cart is empty.', 'warning');
            return;
        }

        var total = cart.reduce(function(sum, c) { return sum + (c.listing.pricePerUnit * c.quantity); }, 0);

        var html = `
            <div class="checkout-summary">
                <h4 style="margin-bottom:0.5rem;">Order Summary</h4>
        `;

        cart.forEach(function(item) {
            var l = item.listing;
            var subtotal = l.pricePerUnit * item.quantity;
            html += `
                <div class="checkout-item">
                    <span>${l.productName} × ${item.quantity} ${l.unit}</span>
                    <span>${subtotal.toFixed(2)} ETB</span>
                </div>
            `;
        });

        html += `
                <div class="checkout-total">Total: ${total.toFixed(2)} ETB</div>
            </div>

            <div style="margin:1rem 0;">
                <label style="font-weight:500; display:block; margin-bottom:0.5rem;">Select Payment Method</label>
                <div class="payment-methods">
                    <button class="payment-method-btn active" data-method="bank_transfer" onclick="selectPaymentMethod(this)">🏦 Bank Transfer</button>
                    <button class="payment-method-btn" data-method="mobile_money" onclick="selectPaymentMethod(this)">📱 Mobile Money</button>
                    <button class="payment-method-btn" data-method="cash" onclick="selectPaymentMethod(this)">💰 Cash on Delivery</button>
                </div>
            </div>

            <div id="paymentProofSection" style="margin-top:1rem;">
                <label style="font-weight:500; display:block; margin-bottom:0.5rem;">Upload Payment Proof</label>
                <div class="proof-upload-area" onclick="document.getElementById('proofInput').click()">
                    <i class="fas fa-cloud-upload-alt" style="font-size:2rem; color:#6B746E; display:block; margin-bottom:0.3rem;"></i>
                    <p>Upload screenshot/photo of payment confirmation</p>
                    <small>JPG, PNG (Max 2MB)</small>
                </div>
                <input type="file" id="proofInput" accept="image/*" style="display:none;" onchange="handlePaymentProof(this)">
                <div id="proofPreviewContainer"></div>
            </div>

            <button class="btn-primary" onclick="placeOrder()" style="width:100%; margin-top:1rem;">
                <i class="fas fa-check"></i> Place Order
            </button>
            <p style="font-size:0.75rem; color:#6B746E; text-align:center; margin-top:0.5rem;">
                ⚠️ Payment must be verified by the seller before order is confirmed.
            </p>
        `;

        document.getElementById('checkoutContent').innerHTML = html;
        state.paymentProofData = null;
        openModal('checkoutModal');
    };

    window.selectPaymentMethod = function(btn) {
        document.querySelectorAll('.payment-method-btn').forEach(function(b) {
            b.classList.remove('active');
        });
        btn.classList.add('active');
    };

    window.handlePaymentProof = function(input) {
        var file = input.files[0];
        if (!file) return;
        if (file.size > 2 * 1024 * 1024) {
            showToast('Image must be under 2MB.', 'error');
            return;
        }
        if (!file.type.startsWith('image/')) {
            showToast('Please select an image.', 'error');
            return;
        }
        var reader = new FileReader();
        reader.onload = function(ev) {
            state.paymentProofData = ev.target.result;
            var container = document.getElementById('proofPreviewContainer');
            container.innerHTML = `
                <img src="${state.paymentProofData}" class="proof-preview" alt="Payment proof">
                <button onclick="state.paymentProofData = null; document.getElementById('proofPreviewContainer').innerHTML = ''; document.getElementById('proofInput').value = '';" style="color:#B85C45; font-size:0.8rem; margin-top:0.3rem;">Remove</button>
            `;
        };
        reader.readAsDataURL(file);
        input.value = '';
    };

    window.placeOrder = function() {
        var cart = getCart();
        if (cart.length === 0) {
            showToast('Your cart is empty.', 'warning');
            return;
        }

        var paymentMethod = document.querySelector('.payment-method-btn.active');
        var method = paymentMethod ? paymentMethod.dataset.method : 'bank_transfer';

        // Require proof for bank transfer and mobile money
        if ((method === 'bank_transfer' || method === 'mobile_money') && !state.paymentProofData) {
            showToast('Please upload payment proof.', 'error');
            return;
        }

        var userId = getCurrentUserId();
        if (!userId) { showToast('Please log in.', 'error'); return; }

        var orders = getOrders();
        var total = cart.reduce(function(sum, c) { return sum + (c.listing.pricePerUnit * c.quantity); }, 0);

        // Create order for each seller (group by seller)
        var sellerGroups = {};
        cart.forEach(function(item) {
            var sellerId = item.listing.sellerId;
            if (!sellerGroups[sellerId]) {
                sellerGroups[sellerId] = {
                    sellerName: item.listing.sellerName,
                    sellerId: sellerId,
                    items: [],
                    total: 0
                };
            }
            var subtotal = item.listing.pricePerUnit * item.quantity;
            sellerGroups[sellerId].items.push({
                listingId: item.listingId,
                productName: item.listing.productName,
                unit: item.listing.unit,
                quantity: item.quantity,
                pricePerUnit: item.listing.pricePerUnit,
                subtotal: subtotal
            });
            sellerGroups[sellerId].total += subtotal;
        });

        var sellerIds = Object.keys(sellerGroups);
        var allOrders = [];

        sellerIds.forEach(function(sid) {
            var group = sellerGroups[sid];
            var order = {
                id: 'order_' + Date.now() + '_' + sid,
                buyerId: userId,
                buyerName: getCommunityDisplayName(),
                sellerId: group.sellerId,
                sellerName: group.sellerName,
                items: group.items,
                total: group.total,
                paymentMethod: method,
                paymentProof: state.paymentProofData || null,
                paymentStatus: state.paymentProofData ? 'proof_submitted' : 'pending',
                orderStatus: state.paymentProofData ? 'payment_proof_submitted' : 'pending_payment',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            allOrders.push(order);
            orders.push(order);

            // Update listing stock
            var listings = getListings();
            group.items.forEach(function(item) {
                var listing = listings.find(function(l) { return l.id === item.listingId; });
                if (listing) {
                    listing.quantityAvailable -= item.quantity;
                    if (listing.quantityAvailable < 0) listing.quantityAvailable = 0;
                }
            });
            saveListings(listings);
        });

        saveOrders(orders);

        // Clear cart
        saveCart([]);
        updateCartBadge();
        closeModal('checkoutModal');

        if (state.paymentProofData) {
            showToast('Order placed! Payment proof submitted for seller verification.', 'success');
        } else {
            showToast('Order placed! Please complete payment and upload proof.', 'info');
        }

        renderProducts();
        switchTab('orders');
    };

    // ============================================================
    // ORDERS & SALES
    // ============================================================

    function renderOrdersTab(tab) {
        var container = document.getElementById('productsContainer');
        var orders = getOrders();
        var userId = getCurrentUserId();

        var filtered = orders.filter(function(o) {
            return tab === 'orders' ? o.buyerId === userId : o.sellerId === userId;
        });

        if (filtered.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas ${tab === 'orders' ? 'fa-shopping-bag' : 'fa-chart-line'}"></i>
                    <h3>${tab === 'orders' ? 'No Orders' : 'No Sales'}</h3>
                    <p>${tab === 'orders' ? 'You have no orders yet.' : 'You have no sales yet.'}</p>
                </div>
            `;
            return;
        }

        // Sort by newest first
        filtered.sort(function(a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });

        var html = '';
        for (var i = 0; i < filtered.length; i++) {
            var o = filtered[i];
            var statusClass = getStatusClass(o.paymentStatus, o.orderStatus);

            html += `
                <div class="order-card" onclick="viewOrderDetail('${o.id}')">
                    <div class="order-card-header">
                        <span class="order-card-product">${o.items.length} item${o.items.length > 1 ? 's' : ''} · ${o.total.toFixed(2)} ETB</span>
                        <span class="order-card-status ${statusClass}">${getStatusLabel(o.paymentStatus, o.orderStatus)}</span>
                    </div>
                    <div class="order-card-details">
                        ${tab === 'orders' ? `Seller: ${o.sellerName}` : `Buyer: ${o.buyerName}`}
                        · ${new Date(o.createdAt).toLocaleDateString()}
                    </div>
                    <div class="order-card-actions">
                        ${tab === 'sales' && o.paymentStatus === 'proof_submitted' ? 
                            `<button class="btn-success btn-sm" onclick="event.stopPropagation(); confirmPayment('${o.id}')"><i class="fas fa-check"></i> Confirm Payment</button>
                             <button class="btn-danger btn-sm" onclick="event.stopPropagation(); rejectPayment('${o.id}')"><i class="fas fa-times"></i> Reject</button>` : ''}
                        ${tab === 'sales' && o.paymentStatus === 'confirmed' && o.orderStatus === 'payment_confirmed' ? 
                            `<button class="btn-success btn-sm" onclick="event.stopPropagation(); acceptOrder('${o.id}')"><i class="fas fa-check"></i> Accept Order</button>` : ''}
                        ${o.paymentProof ? `<button class="btn-secondary btn-sm" onclick="event.stopPropagation(); viewPaymentProof('${o.id}')"><i class="fas fa-eye"></i> View Proof</button>` : ''}
                    </div>
                </div>
            `;
        }

        container.innerHTML = html;
    }

    function getStatusClass(paymentStatus, orderStatus) {
        if (orderStatus === 'completed') return 'status-completed';
        if (orderStatus === 'order_accepted') return 'status-accepted';
        if (paymentStatus === 'confirmed') return 'status-confirmed';
        if (paymentStatus === 'rejected') return 'status-rejected';
        if (paymentStatus === 'proof_submitted') return 'status-proof';
        if (paymentStatus === 'pending') return 'status-pending';
        return 'status-pending';
    }

    function getStatusLabel(paymentStatus, orderStatus) {
        if (orderStatus === 'completed') return 'Completed';
        if (orderStatus === 'order_accepted') return 'Order Accepted';
        if (paymentStatus === 'confirmed') return 'Payment Confirmed';
        if (paymentStatus === 'rejected') return 'Payment Rejected';
        if (paymentStatus === 'proof_submitted') return 'Payment Proof Submitted';
        if (paymentStatus === 'pending' && orderStatus === 'pending_payment') return 'Pending Payment';
        return 'Pending';
    }

    // ============================================================
    // SELLER ACTIONS
    // ============================================================

    window.confirmPayment = function(orderId) {
        if (!confirm('Confirm payment for this order?')) return;
        var orders = getOrders();
        var order = orders.find(function(o) { return o.id === orderId; });
        if (!order) return;
        order.paymentStatus = 'confirmed';
        order.orderStatus = 'payment_confirmed';
        order.updatedAt = new Date().toISOString();
        saveOrders(orders);
        showToast('Payment confirmed!', 'success');
        renderProducts();
    };

    window.rejectPayment = function(orderId) {
        if (!confirm('Reject payment for this order?')) return;
        var orders = getOrders();
        var order = orders.find(function(o) { return o.id === orderId; });
        if (!order) return;
        order.paymentStatus = 'rejected';
        order.orderStatus = 'payment_rejected';
        order.updatedAt = new Date().toISOString();
        saveOrders(orders);
        showToast('Payment rejected.', 'warning');
        renderProducts();
    };

    window.acceptOrder = function(orderId) {
        if (!confirm('Accept this order?')) return;
        var orders = getOrders();
        var order = orders.find(function(o) { return o.id === orderId; });
        if (!order) return;
        order.orderStatus = 'order_accepted';
        order.updatedAt = new Date().toISOString();
        saveOrders(orders);
        showToast('Order accepted!', 'success');
        renderProducts();
    };

    window.completeOrder = function(orderId) {
        if (!confirm('Mark this order as completed?')) return;
        var orders = getOrders();
        var order = orders.find(function(o) { return o.id === orderId; });
        if (!order) return;
        order.orderStatus = 'completed';
        order.updatedAt = new Date().toISOString();
        saveOrders(orders);
        showToast('Order completed!', 'success');
        renderProducts();
    };

    // ============================================================
    // VIEW ORDER DETAIL
    // ============================================================

    window.viewOrderDetail = function(orderId) {
        var orders = getOrders();
        var order = orders.find(function(o) { return o.id === orderId; });
        if (!order) { showToast('Order not found.', 'error'); return; }

        var html = `
            <div style="display:grid; gap:1rem;">
                <div style="display:flex; justify-content:space-between; flex-wrap:wrap;">
                    <div><strong>Order ID:</strong> ${order.id}</div>
                    <div><strong>Status:</strong> <span class="order-card-status ${getStatusClass(order.paymentStatus, order.orderStatus)}">${getStatusLabel(order.paymentStatus, order.orderStatus)}</span></div>
                </div>
                <div><strong>Date:</strong> ${new Date(order.createdAt).toLocaleString()}</div>
                <div><strong>${order.buyerId === getCurrentUserId() ? 'Seller' : 'Buyer'}:</strong> ${order.buyerId === getCurrentUserId() ? order.sellerName : order.buyerName}</div>
                <div style="background:#F7F6F0; border-radius:12px; padding:1rem;">
                    <h4 style="margin-bottom:0.5rem;">Items</h4>
                    ${order.items.map(function(item) {
                        return `<div class="checkout-item"><span>${item.productName} × ${item.quantity} ${item.unit}</span><span>${item.subtotal.toFixed(2)} ETB</span></div>`;
                    }).join('')}
                    <div class="checkout-total">Total: ${order.total.toFixed(2)} ETB</div>
                </div>
                ${order.paymentProof ? `<div><strong>Payment Proof:</strong> <button class="btn-secondary btn-sm" onclick="viewPaymentProof('${order.id}')"><i class="fas fa-eye"></i> View</button></div>` : ''}
                <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
                    ${order.buyerId === getCurrentUserId() && order.orderStatus === 'order_accepted' ? `<button class="btn-success btn-sm" onclick="completeOrder('${order.id}')"><i class="fas fa-check"></i> Complete Order</button>` : ''}
                </div>
            </div>
        `;

        document.getElementById('orderDetailContent').innerHTML = html;
        openModal('orderDetailModal');
    };

    // ============================================================
    // PAYMENT PROOF VIEW
    // ============================================================

    window.viewPaymentProof = function(orderId) {
        var orders = getOrders();
        var order = orders.find(function(o) { return o.id === orderId; });
        if (!order || !order.paymentProof) {
            showToast('No payment proof available.', 'warning');
            return;
        }

        var html = `
            <div style="text-align:center;">
                <img src="${order.paymentProof}" alt="Payment proof" style="max-width:100%; max-height:400px; border-radius:12px;">
                <div style="margin-top:0.5rem; color:#6B746E;">
                    <strong>Order:</strong> ${order.id}<br>
                    <strong>Amount:</strong> ${order.total.toFixed(2)} ETB
                </div>
            </div>
        `;

        document.getElementById('paymentProofContent').innerHTML = html;
        openModal('paymentProofModal');
    };

    // ============================================================
    // SAVED PRODUCTS
    // ============================================================

    window.toggleSaved = function(listingId) {
        var saved = getSaved();
        var index = saved.indexOf(listingId);
        if (index !== -1) {
            saved.splice(index, 1);
            showToast('Removed from saved.', 'info');
        } else {
            saved.push(listingId);
            showToast('Saved!', 'success');
        }
        saveSaved(saved);
        renderProducts();
    };

    // ============================================================
    // SHARE
    // ============================================================

    window.shareProduct = function(listingId) {
        var listings = getListings();
        var listing = listings.find(function(l) { return l.id === listingId; });
        if (!listing) return;

        var text = 'Check out ' + listing.productName + ' on AgriNova Marketplace!';
        var url = window.location.href;

        if (navigator.share) {
            navigator.share({
                title: listing.productName,
                text: text,
                url: url
            }).catch(function() {});
        } else {
            navigator.clipboard.writeText(text + '\n\n' + url).then(function() {
                showToast('Product link copied!', 'success');
            }).catch(function() {
                var textarea = document.createElement('textarea');
                textarea.value = text + '\n\n' + url;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                showToast('Product link copied!', 'success');
            });
        }
    };

    // ============================================================
    // VIEW SELLER PROFILE
    // ============================================================

    window.viewSellerProfile = function(sellerId) {
        // Navigate to community profile
        localStorage.setItem('agrinova_viewing_profile', sellerId);
        window.location.href = 'farmer-community.html';
    };

    // ============================================================
    // DELETE LISTING
    // ============================================================

    window.deleteListing = function(listingId) {
        if (!confirm('Delete this listing?')) return;
        var listings = getListings();
        listings = listings.filter(function(l) { return l.id !== listingId; });
        saveListings(listings);
        renderProducts();
        showToast('Listing deleted.', 'info');
    };

    // ============================================================
    // SEARCH & FILTERS
    // ============================================================

    window.applyFilters = function() {
        renderProducts();
    };

    window.clearFilters = function() {
        document.getElementById('searchInput').value = '';
        document.getElementById('filterCategory').value = 'all';
        document.getElementById('filterSort').value = 'newest';
        renderProducts();
    };

    // ============================================================
    // IMAGE VIEWER
    // ============================================================

    window.viewImage = function(src) {
        document.getElementById('imageViewerImg').src = src;
        openModal('imageViewerModal');
    };

    // ============================================================
    // MODAL HELPERS
    // ============================================================

    window.openModal = function(id) {
        var modal = document.getElementById(id);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    };

    window.closeModal = function(id) {
        var modal = document.getElementById(id);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    };

    document.querySelectorAll('.modal').forEach(function(modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
                document.body.style.overflow = 'auto';
            }
        });
    });

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        var existing = document.querySelector('.toast');
        if (existing) existing.remove();

        var toast = document.createElement('div');
        toast.className = 'toast show ' + (type || '');
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(function() {
            toast.classList.remove('show');
            setTimeout(function() { toast.remove(); }, 300);
        }, 4000);
    }

    window.showToast = showToast;

    // ============================================================
    // INJECT TOAST STYLES
    // ============================================================

    (function injectToastStyles() {
        var style = document.createElement('style');
        style.textContent = `
            .toast {
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                background: #0B3D2E;
                color: #fff;
                padding: 0.8rem 1.5rem;
                border-radius: 12px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.15);
                z-index: 2000;
                display: none;
                max-width: 400px;
                animation: slideUp 0.3s ease;
                font-family: 'Inter', sans-serif;
                font-size: 0.9rem;
            }
            .toast.show { display: block; }
            .toast.error { background: #B85C45; }
            .toast.warning { background: #C68A2B; }
            .toast.success { background: #2F7D4A; }
            .toast.info { background: #145A3A; }
            @keyframes slideUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(style);
    })();

    // ============================================================
    // START
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();