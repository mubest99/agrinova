(function() {
    "use strict";

    // ============================================================
    // DATA HELPERS
    // ============================================================

    function getFarmer() {
        let raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getCrops() {
        let raw = localStorage.getItem('agrinova_crops_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getDailyRecords() {
        let raw = localStorage.getItem('agrinova_daily_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getTasks() {
        let raw = localStorage.getItem('agrinova_tasks_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getFarmRecords() {
        let raw = localStorage.getItem('agrinova_farm_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getFarmData() {
        let raw = localStorage.getItem('agrinova_farm_data');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    function getConversations() {
        let raw = localStorage.getItem('agrinova_ai_conversations');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveConversations(conversations) {
        localStorage.setItem('agrinova_ai_conversations', JSON.stringify(conversations));
    }

    // ============================================================
    // STATE
    // ============================================================

    let state = {
        currentConversation: null,
        messages: [],
        isRecording: false,
        autoSpeak: false,
        language: 'en',
        recognition: null,
        speechSynthesis: window.speechSynthesis,
        isProcessing: false
    };

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova AI Assistant Initializing...');
        
        updateDate();
        updateGreeting();
        updateProfile();
        setupProfileImage();
        setupDropdown();
        fetchWeather();
        updateDataSummary();
        updateContextStatus();
        generateRecommendations();
        renderConversations();
        loadLastConversation();

        // Setup chat input
        document.getElementById('chatInput').addEventListener('keydown', handleChatKeydown);
        document.getElementById('imageInput').addEventListener('change', handleImageUpload);

        // Setup voice recognition
        setupVoiceRecognition();

        console.log('AgriNova AI Assistant Ready.');
    }

    // ============================================================
    // DATE & GREETING
    // ============================================================

    function updateDate() {
        const now = new Date();
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        
        document.getElementById('dateDay').textContent = days[now.getDay()];
        document.getElementById('dateFull').textContent = `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    }

    function updateGreeting() {
        const farmer = getFarmer();
        const h1 = document.getElementById('greetingText');
        const hour = new Date().getHours();
        let greet = 'Good morning';
        if (hour >= 12 && hour < 17) greet = 'Good afternoon';
        else if (hour >= 17) greet = 'Good evening';

        const name = farmer?.name || farmer?.firstName || 'Farmer';
        h1.textContent = `${greet}, ${name}`;
        document.getElementById('navName').textContent = name;
    }

    function updateProfile() {
        const farmer = getFarmer();
        if (!farmer) return;

        const name = farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('pdName').textContent = name;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || '—';
        
        const city = farmer.city || '—';
        const region = farmer.region || '—';
        document.getElementById('pdLocation').textContent = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdFarmland').textContent = farmer.hectares ? `${farmer.hectares} ha` : '—';
    }

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }
        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // WEATHER
    // ============================================================

    async function fetchWeather() {
        try {
            const farmer = getFarmer();
            const city = farmer?.city || 'Addis Ababa';
            
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        await getWeatherData(latitude, longitude);
                    },
                    async () => {
                        await getWeatherByCity(city);
                    }
                );
            } else {
                await getWeatherByCity(city);
            }
        } catch (e) {
            console.warn('Weather error:', e);
            document.getElementById('navTemp').textContent = '--°C';
            document.getElementById('contextWeather').textContent = 'Unavailable';
            document.getElementById('contextWeather').className = 'toggle-status unavailable';
        }
    }

    async function getWeatherData(lat, lon) {
        try {
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`;
            const resp = await fetch(url);
            if (!resp.ok) throw new Error('Weather API error');
            const data = await resp.json();
            if (data.current_weather) {
                const temp = data.current_weather.temperature !== undefined ? `${Math.round(data.current_weather.temperature)}°C` : '--°C';
                document.getElementById('navTemp').textContent = temp;
                document.getElementById('contextWeather').textContent = 'Available';
                document.getElementById('contextWeather').className = 'toggle-status available';
            }
        } catch (e) {
            console.warn('Weather fetch error:', e);
        }
    }

    async function getWeatherByCity(city) {
        try {
            const geoResp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
            const geoData = await geoResp.json();
            if (geoData && geoData.length > 0) {
                const { lat, lon } = geoData[0];
                await getWeatherData(parseFloat(lat), parseFloat(lon));
            }
        } catch (e) {
            console.warn('City geocode error:', e);
        }
    }

    // ============================================================
    // DATA SUMMARY
    // ============================================================

    function updateDataSummary() {
        const crops = getCrops();
        const daily = getDailyRecords();
        const tasks = getTasks();

        document.getElementById('summaryCrops').textContent = crops.length;
        document.getElementById('summaryActivities').textContent = daily.length;
        document.getElementById('summaryTasks').textContent = tasks.filter(t => t.status !== 'completed').length;

        // Update status indicator
        const hasData = crops.length > 0 || daily.length > 0 || tasks.length > 0;
        const dot = document.querySelector('.status-dot');
        const text = document.querySelector('.status-text');
        if (hasData) {
            dot.className = 'status-dot connected';
            text.textContent = 'Farm context connected';
        } else {
            dot.className = 'status-dot limited';
            text.textContent = 'Limited farm context available';
        }
    }

    function updateContextStatus() {
        const crops = getCrops();
        const daily = getDailyRecords();
        const tasks = getTasks();

        document.getElementById('contextCrops').textContent = crops.length > 0 ? `Available (${crops.length})` : 'No crops';
        document.getElementById('contextCrops').className = `toggle-status ${crops.length > 0 ? 'available' : 'limited'}`;
        
        document.getElementById('contextDaily').textContent = daily.length > 0 ? `Available (${daily.length})` : 'No activities';
        document.getElementById('contextDaily').className = `toggle-status ${daily.length > 0 ? 'available' : 'limited'}`;
        
        document.getElementById('contextTasks').textContent = tasks.length > 0 ? `Available (${tasks.length})` : 'No tasks';
        document.getElementById('contextTasks').className = `toggle-status ${tasks.length > 0 ? 'available' : 'limited'}`;
    }

    // ============================================================
    // CHAT FUNCTIONS
    // ============================================================

    function addMessage(text, sender, options = {}) {
        const container = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;

        let bubbleHtml = `<div class="bubble">${text}`;
        
        // Add actions for AI messages
        if (sender === 'ai') {
            bubbleHtml += `
                <div class="message-actions">
                    <button onclick="speakResponse('${text.replace(/'/g, "\\'")}')">
                        <i class="fas fa-volume-up"></i> Listen
                    </button>
                    <button class="copy-btn" onclick="copyResponse(this, '${text.replace(/'/g, "\\'")}')">
                        <i class="fas fa-copy"></i> Copy
                    </button>
                    ${options.reason ? `<button onclick="showExplanation('${options.reason.replace(/'/g, "\\'")}')">
                        <i class="fas fa-question-circle"></i> Why this?
                    </button>` : ''}
                </div>
            `;
        }

        bubbleHtml += '</div>';
        messageDiv.innerHTML = bubbleHtml;
        container.appendChild(messageDiv);
        container.scrollTop = container.scrollHeight;

        // Auto-speak if enabled
        if (sender === 'ai' && state.autoSpeak) {
            speakResponse(text);
        }
    }

    function addTypingIndicator() {
        const container = document.getElementById('chatMessages');
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message ai';
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = `
            <div class="bubble" style="background:#F7F6F0; border:1px solid #EAE7DE;">
                <span style="display:flex; gap:4px; align-items:center;">
                    <span style="width:6px; height:6px; background:#2F7D4A; border-radius:50%; animation: pulse 0.6s infinite;"></span>
                    <span style="width:6px; height:6px; background:#2F7D4A; border-radius:50%; animation: pulse 0.6s infinite 0.2s;"></span>
                    <span style="width:6px; height:6px; background:#2F7D4A; border-radius:50%; animation: pulse 0.6s infinite 0.4s;"></span>
                </span>
            </div>
        `;
        container.appendChild(typingDiv);
        container.scrollTop = container.scrollHeight;
    }

    function removeTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) indicator.remove();
    }

    function sendMessage() {
        const input = document.getElementById('chatInput');
        const text = input.value.trim();
        if (!text || state.isProcessing) return;

        // Add user message
        addMessage(text, 'user');
        input.value = '';
        state.isProcessing = true;

        // Show typing indicator
        addTypingIndicator();

        // Process the question
        setTimeout(() => {
            processQuestion(text);
        }, 500);
    }

    function handleChatKeydown(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendMessage();
        }
    }

    window.sendMessage = sendMessage;

    // ============================================================
    // QUESTION PROCESSING (Rule-Based + AI)
    // ============================================================

    function processQuestion(text) {
        const lowerText = text.toLowerCase();
        let response = '';
        let reason = '';

        // Get farm data
        const crops = getCrops();
        const daily = getDailyRecords();
        const tasks = getTasks();
        const farmer = getFarmer();

        // Check for specific question types
        if (lowerText.includes('crop') || lowerText.includes('plant') || lowerText.includes('grow')) {
            if (crops.length === 0) {
                response = `You haven't added any crops yet. I recommend going to My Crops to add your crops so I can provide personalized assistance about your crops.\n\n[Go to My Crops](my-crops.html)`;
                reason = 'No crop data available. The user asked about crops but has no crops recorded.';
            } else {
                response = `You have ${crops.length} crops recorded:\n\n`;
                crops.forEach(c => {
                    response += `• **${c.name}** - Planted: ${c.plantingDate || 'Date not set'} | Area: ${c.area || 'N/A'} ha\n`;
                });
                response += `\nTo get more specific advice, tell me which crop you want to discuss.`;
                reason = `Generated crop summary from ${crops.length} crops in localStorage.`;
            }
        } 
        else if (lowerText.includes('task') || lowerText.includes('do today') || lowerText.includes('what should i do')) {
            const pendingTasks = tasks.filter(t => t.status !== 'completed');
            if (pendingTasks.length === 0) {
                response = `You have no pending tasks. Check your Farm Tasks & Calendar to plan activities.\n\n[Go to Farm Tasks](farm-tasks-calendar.html)`;
                reason = 'No pending tasks found. User asked about tasks but none are pending.';
            } else {
                response = `You have ${pendingTasks.length} pending tasks:\n\n`;
                pendingTasks.slice(0, 5).forEach(t => {
                    response += `• **${t.title}** - Due: ${t.dueDate || 'No date'} | Priority: ${t.priority || 'Medium'}\n`;
                });
                if (pendingTasks.length > 5) {
                    response += `\nAnd ${pendingTasks.length - 5} more tasks. View all in Farm Tasks & Calendar.`;
                }
                reason = `Generated task summary from ${pendingTasks.length} pending tasks.`;
            }
        }
        else if (lowerText.includes('weather') || lowerText.includes('rain') || lowerText.includes('temperature')) {
            const temp = document.getElementById('navTemp').textContent;
            if (temp === '--°C') {
                response = `Weather information is currently unavailable. Please check your internet connection and try again.`;
                reason = 'Weather data not available.';
            } else {
                response = `Current weather: ${temp}\n\nBased on the weather, consider:\n• ${temp.includes('30') ? '☀️ Hot conditions - ensure crops have adequate water' : '🌤️ Moderate conditions - good for farm activities'}\n• Check your irrigation schedule if rainfall is expected.`;
                reason = `Weather data from Open-Meteo API: ${temp}`;
            }
        }
        else if (lowerText.includes('health') || lowerText.includes('status')) {
            const cropCount = crops.length;
            const activityCount = daily.length;
            const taskCount = tasks.filter(t => t.status !== 'completed').length;
            
            if (cropCount === 0 && activityCount === 0) {
                response = `I need more farm data to assess your farm health.\n\nAdd crops in My Crops and record activities in Daily Farm to get health insights.`;
                reason = 'Insufficient data for farm health assessment.';
            } else {
                response = `📊 **Farm Health Summary**\n\n`;
                response += `• **Crops:** ${cropCount} ${cropCount > 0 ? '✅' : '⚠️ Add crops'}\n`;
                response += `• **Activities Logged:** ${activityCount} ${activityCount > 5 ? '✅ Good' : '⚠️ Limited data'}\n`;
                response += `• **Pending Tasks:** ${taskCount} ${taskCount === 0 ? '✅ All caught up' : '📋 Tasks pending'}\n\n`;
                if (cropCount > 0 && activityCount > 0) {
                    response += `Your farm appears to be active. Keep logging activities to get better insights.`;
                }
                reason = `Farm health summary based on ${cropCount} crops, ${activityCount} activities, and ${taskCount} pending tasks.`;
            }
        }
        else if (lowerText.includes('weather') || lowerText.includes('forecast')) {
            const temp = document.getElementById('navTemp').textContent;
            if (temp === '--°C') {
                response = `Weather information is currently unavailable. Please check your internet connection and try again.`;
                reason = 'Weather data not available.';
            } else {
                response = `🌤️ **Current Weather**\n\nTemperature: ${temp}\n\nBased on the weather, consider:\n• ${temp.includes('30') ? '☀️ Hot conditions - ensure crops have adequate water' : '🌤️ Moderate conditions - good for farm activities'}\n• Check your irrigation schedule if rainfall is expected.`;
                reason = `Weather data from Open-Meteo API: ${temp}`;
            }
        }
        else if (lowerText.includes('hello') || lowerText.includes('hi') || lowerText.includes('hey')) {
            const name = farmer?.name || farmer?.firstName || 'Farmer';
            response = `Hello ${name}! 👋\n\nHow can I help you with your farm today?\n\nYou can ask me about:\n• Your crops and their progress\n• Tasks you need to complete\n• Weather updates\n• Farm health\n• General agricultural questions`;
            reason = 'Greeting response.';
        }
        else if (lowerText.includes('thank')) {
            response = `You're welcome! 😊\n\nI'm here to help with your farm. Feel free to ask any questions about your crops, tasks, or farm management.\n\nHappy farming! 🌾`;
            reason = 'Thank you response.';
        }
        else {
            // Try Hugging Face API for general questions (free tier)
            // If fails, use rule-based fallback
            // For now, use rule-based fallback
            response = `I understand you're asking about "${text}"\n\n`;
            response += `Here's what I can tell you based on your farm data:\n`;
            response += `• You have ${crops.length} crops recorded\n`;
            response += `• ${daily.length} activities logged\n`;
            response += `• ${tasks.filter(t => t.status !== 'completed').length} pending tasks\n\n`;
            response += `To get more detailed answers, you can:\n`;
            response += `1. Add more data to your farm records\n`;
            response += `2. Ask specific questions about your crops, tasks, or weather\n`;
            response += `3. Upload images of plants or soil for analysis\n\n`;
            response += `I'm here to help with all your farm-related questions! 🌾`;
            reason = 'General question - rule-based fallback response.';
        }

        // Remove typing indicator and add AI response
        removeTypingIndicator();
        addMessage(response, 'ai', { reason: reason });
        state.isProcessing = false;

        // Save conversation
        saveConversation(text, response);
    }

    // ============================================================
    // HUGGING FACE API (Free Tier)
    // ============================================================

    async function queryHuggingFace(text) {
        // This is optional - using Hugging Face free inference API
        // Limited to 30 requests per hour on free tier
        // For now, we're using rule-based logic
        // Uncomment below to enable Hugging Face API
        
        /*
        try {
            const response = await fetch('https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium', {
                headers: { 
                    'Authorization': 'Bearer YOUR_HF_TOKEN' // Get free token from huggingface.co
                },
                method: 'POST',
                body: JSON.stringify({ inputs: text })
            });
            const result = await response.json();
            return result.generated_text || null;
        } catch (e) {
            console.warn('Hugging Face API error:', e);
            return null;
        }
        */
        
        return null; // Using rule-based for now
    }

    // ============================================================
    // QUICK ACTIONS
    // ============================================================

    window.askQuestion = function(question) {
        document.getElementById('chatInput').value = question;
        sendMessage();
    };

    // ============================================================
    // VOICE INPUT
    // ============================================================

    function setupVoiceRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            state.recognition = new SpeechRecognition();
            state.recognition.lang = 'en-US';
            state.recognition.continuous = false;
            state.recognition.interimResults = true;

            state.recognition.onresult = function(event) {
                let finalTranscript = '';
                let interimTranscript = '';
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }
                if (finalTranscript) {
                    document.getElementById('chatInput').value = finalTranscript;
                    stopVoiceInput();
                    sendMessage();
                } else if (interimTranscript) {
                    document.getElementById('chatInput').value = interimTranscript;
                }
            };

            state.recognition.onerror = function(event) {
                console.warn('Voice recognition error:', event.error);
                stopVoiceInput();
                if (event.error === 'not-allowed') {
                    showToast('Please allow microphone access to use voice input.', 'warning');
                } else {
                    showToast('Voice recognition error. Please try again.', 'error');
                }
            };

            state.recognition.onend = function() {
                stopVoiceInput();
            };
        } else {
            console.warn('Speech recognition not supported in this browser.');
        }
    }

    window.toggleVoiceInput = function() {
        if (state.isRecording) {
            stopVoiceInput();
        } else {
            startVoiceInput();
        }
    };

    function startVoiceInput() {
        if (!state.recognition) {
            showToast('Voice input is not supported in this browser.', 'error');
            return;
        }

        try {
            state.recognition.start();
            state.isRecording = true;
            document.getElementById('voiceBtn').classList.add('recording');
            document.getElementById('voiceStatus').style.display = 'flex';
            document.getElementById('chatInput').placeholder = 'Listening...';
            showToast('🎤 Listening... Speak now.', 'info');
        } catch (e) {
            console.warn('Voice start error:', e);
        }
    }

    window.stopVoiceInput = function() {
        if (state.recognition) {
            try {
                state.recognition.stop();
            } catch (e) {}
        }
        state.isRecording = false;
        document.getElementById('voiceBtn').classList.remove('recording');
        document.getElementById('voiceStatus').style.display = 'none';
        document.getElementById('chatInput').placeholder = 'Ask anything about your farm...';
    };

    // ============================================================
    // TEXT-TO-SPEECH
    // ============================================================

    window.speakResponse = function(text) {
        if (!window.speechSynthesis) {
            showToast('Text-to-speech is not supported in this browser.', 'warning');
            return;
        }

        // Remove markdown and HTML
        const cleanText = text.replace(/\*\*/g, '').replace(/\[.*?\]\(.*?\)/g, '');
        
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.lang = state.language === 'am' ? 'am-ET' : 'en-US';
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;

        // Try to find a voice
        const voices = speechSynthesis.getVoices();
        if (voices.length > 0) {
            const preferredVoice = voices.find(v => v.lang.startsWith(utterance.lang));
            if (preferredVoice) {
                utterance.voice = preferredVoice;
            }
        }

        speechSynthesis.speak(utterance);
    };

    window.toggleAutoSpeak = function() {
        state.autoSpeak = !state.autoSpeak;
        const icon = document.getElementById('autoSpeakIcon');
        icon.style.color = state.autoSpeak ? '#2F7D4A' : '#6B746E';
        showToast(state.autoSpeak ? 'Auto-speak enabled' : 'Auto-speak disabled', 'info');
    };

    // ============================================================
    // COPY RESPONSE
    // ============================================================

    window.copyResponse = function(button, text) {
        navigator.clipboard.writeText(text).then(() => {
            button.innerHTML = '<i class="fas fa-check"></i> Copied!';
            button.classList.add('copied');
            setTimeout(() => {
                button.innerHTML = '<i class="fas fa-copy"></i> Copy';
                button.classList.remove('copied');
            }, 2000);
        }).catch(() => {
            // Fallback
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            showToast('Copied!', 'success');
        });
    };

    // ============================================================
    // EXPLANATION
    // ============================================================

    window.showExplanation = function(reason) {
        showToast(`💡 ${reason}`, 'info');
    };

    // ============================================================
    // IMAGE UPLOAD
    // ============================================================

    window.uploadImage = function() {
        document.getElementById('imageInput').click();
    };

    function handleImageUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        if (!file.type.startsWith('image/')) {
            showToast('Please select an image file.', 'error');
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            const imageUrl = e.target.result;
            const msg = `📷 **Image Uploaded**\n\nI can see your image. `;
            
            // Add image to chat
            const container = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message user';
            messageDiv.innerHTML = `
                <div class="bubble">
                    <img src="${imageUrl}" style="max-width:200px; border-radius:8px; margin-bottom:0.5rem;">
                    <br>
                    <span>📷 Image uploaded for analysis</span>
                </div>
            `;
            container.appendChild(messageDiv);
            container.scrollTop = container.scrollHeight;

            // AI response about image
            addTypingIndicator();
            setTimeout(() => {
                removeTypingIndicator();
                const response = `📸 **Image Received**\n\n`;
                const aiResponse = response + `For detailed image analysis (crop health, pest detection, etc.), I would need a vision AI service connection.\n\nCurrently, I can provide general guidance based on your description. What would you like to know about this image?\n\nTell me:\n• What crop is this?\n• What concerns do you have?\n• What do you see?`;
                addMessage(aiResponse, 'ai', {
                    reason: 'Image uploaded. Awaiting farmer description for context.'
                });
            }, 1000);
        };
        reader.readAsDataURL(file);
        event.target.value = '';
    }

    // ============================================================
    // LANGUAGE
    // ============================================================

    window.changeLanguage = function() {
        const lang = document.getElementById('languageSelect').value;
        state.language = lang;
        showToast(`Language changed to ${lang === 'en' ? 'English' : lang === 'am' ? 'አማርኛ' : 'Auto Detect'}`, 'info');
        
        // Update voice recognition language
        if (state.recognition) {
            state.recognition.lang = lang === 'am' ? 'am-ET' : 'en-US';
        }
    };

    // ============================================================
    // CONVERSATIONS
    // ============================================================

    function saveConversation(question, answer) {
        let conversations = getConversations();
        const now = new Date();
        const title = question.length > 50 ? question.substring(0, 50) + '...' : question;
        
        const conv = {
            id: 'conv_' + Date.now(),
            title: title,
            question: question,
            answer: answer,
            date: now.toISOString(),
            messages: [
                { sender: 'user', text: question, timestamp: now.toISOString() },
                { sender: 'ai', text: answer, timestamp: new Date(now.getTime() + 1000).toISOString() }
            ]
        };
        
        conversations.unshift(conv);
        if (conversations.length > 20) {
            conversations = conversations.slice(0, 20);
        }
        saveConversations(conversations);
        renderConversations();
    }

    function loadConversation(id) {
        const conversations = getConversations();
        const conv = conversations.find(c => c.id === id);
        if (!conv) return;

        const container = document.getElementById('chatMessages');
        container.innerHTML = '';
        
        conv.messages.forEach(msg => {
            addMessage(msg.text, msg.sender);
        });
        
        state.currentConversation = id;
        showToast('Conversation loaded.', 'info');
    }

    function loadLastConversation() {
        const conversations = getConversations();
        if (conversations.length > 0) {
            loadConversation(conversations[0].id);
        } else {
            // Welcome message
            const welcome = `👋 Welcome to your AgriNova AI Agricultural Assistant!\n\nI'm here to help you manage your farm. I can assist with:\n\n• **Crop Management** - Ask about your crops and their progress\n• **Farm Tasks** - Review and plan your farm activities\n• **Weather Updates** - Get real-time weather information\n• **Farm Health** - Understand your farm's overall status\n• **General Questions** - Ask anything about farming\n\n**Try asking:**\n"What crops do I have?"\n"What should I do today?"\n"How's the weather?"\n"How is my farm doing?"\n\nI learn from your farm data. Add crops, log activities, and track tasks to get more personalized insights! 🌾`;
            addMessage(welcome, 'ai', {
                reason: 'Welcome message displayed on first visit.'
            });
        }
    }

    function renderConversations() {
        const container = document.getElementById('conversationsContainer');
        const conversations = getConversations();

        if (conversations.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-comment"></i>
                    <p>No conversations yet. Start chatting with your AI assistant.</p>
                </div>
            `;
            return;
        }

        let html = '';
        conversations.forEach(conv => {
            const date = new Date(conv.date);
            const timeStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
            html += `
                <div class="conversation-item" onclick="loadConversation('${conv.id}')">
                    <div>
                        <div class="conv-title">${conv.title}</div>
                        <div class="conv-meta">${timeStr}</div>
                    </div>
                    <button class="conv-delete" onclick="event.stopPropagation(); deleteConversation('${conv.id}')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    window.deleteConversation = function(id) {
        if (!confirm('Delete this conversation?')) return;
        let conversations = getConversations();
        conversations = conversations.filter(c => c.id !== id);
        saveConversations(conversations);
        renderConversations();
        showToast('Conversation deleted.', 'warning');
    };

    window.clearAllConversations = function() {
        if (!confirm('Delete all conversations?')) return;
        saveConversations([]);
        renderConversations();
        document.getElementById('chatMessages').innerHTML = '';
        loadLastConversation();
        showToast('All conversations cleared.', 'warning');
    };

    window.clearChat = function() {
        if (document.getElementById('chatMessages').children.length > 0) {
            if (!confirm('Start a new conversation?')) return;
        }
        document.getElementById('chatMessages').innerHTML = '';
        loadLastConversation();
        state.currentConversation = null;
    };

    // ============================================================
    // RECOMMENDATIONS
    // ============================================================

    function generateRecommendations() {
        const container = document.getElementById('recommendationsContainer');
        const crops = getCrops();
        const tasks = getTasks();
        const daily = getDailyRecords();

        let recommendations = [];

        if (crops.length === 0) {
            recommendations.push({
                title: 'Add Your First Crop',
                priority: 'important',
                reason: 'No crops have been added yet. Adding crops allows for personalized crop management assistance.',
                action: 'Go to My Crops',
                link: 'my-crops.html'
            });
        } else {
            // Check for crops nearing harvest
            crops.forEach(crop => {
                // Simple check - could be enhanced with actual growth data
                if (crop.plantingDate) {
                    const daysSince = getDaysSincePlanting(crop.plantingDate);
                    if (daysSince > 60) {
                        recommendations.push({
                            title: `Monitor ${crop.name} for maturity`,
                            priority: 'high',
                            reason: `${crop.name} has been growing for ${daysSince} days. Consider monitoring for harvest readiness.`,
                            action: 'View Crop',
                            link: 'my-crops.html'
                        });
                    }
                }
            });
        }

        const pendingTasks = tasks.filter(t => t.status !== 'completed');
        if (pendingTasks.length > 3) {
            recommendations.push({
                title: `${pendingTasks.length} Pending Tasks`,
                priority: 'high',
                reason: `You have ${pendingTasks.length} tasks that need attention. Review and prioritize them.`,
                action: 'View Tasks',
                link: 'farm-tasks-calendar.html'
            });
        }

        if (daily.length === 0 && crops.length > 0) {
            recommendations.push({
                title: 'Log Farm Activities',
                priority: 'important',
                reason: 'You have crops but no recent activities logged. Daily Farm helps track your farm operations.',
                action: 'Log Activity',
                link: 'daily-farm.html'
            });
        }

        if (recommendations.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <p>Everything looks good! Your farm is well-managed.</p>
                </div>
            `;
            return;
        }

        let html = '';
        recommendations.slice(0, 4).forEach(rec => {
            const priorityClass = rec.priority === 'high' ? 'high' : rec.priority === 'important' ? 'important' : 'informational';
            html += `
                <div class="recommendation-item">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span class="rec-title">${rec.title}</span>
                        <span class="rec-priority ${priorityClass}">${rec.priority}</span>
                    </div>
                    <div class="rec-reason">${rec.reason}</div>
                    <div class="rec-actions">
                        <button onclick="navigateTo('${rec.link}')">
                            <i class="fas fa-arrow-right"></i> ${rec.action}
                        </button>
                        <button onclick="showExplanation('${rec.reason.replace(/'/g, "\\'")}')">
                            <i class="fas fa-question-circle"></i> Why?
                        </button>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function navigateTo(url) {
        window.location.href = url;
    }

    function getDaysSincePlanting(plantingDate) {
        if (!plantingDate) return 0;
        const planted = new Date(plantingDate);
        const now = new Date();
        const diffTime = Math.abs(now - planted);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast show ${type || ''}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    window.showToast = showToast;

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim().toLowerCase();
                    if (query) {
                        const conversations = getConversations();
                        const results = conversations.filter(c => 
                            c.title.toLowerCase().includes(query) ||
                            c.question.toLowerCase().includes(query) ||
                            c.answer.toLowerCase().includes(query)
                        );
                        if (results.length > 0) {
                            showToast(`Found ${results.length} conversation${results.length > 1 ? 's' : ''} matching "${query}"`, 'success');
                        } else {
                            showToast(`No conversations found matching "${query}"`, 'warning');
                        }
                    }
                }
            });
        }
    }

    // ============================================================
    // EXPOSE FUNCTIONS
    // ============================================================

    window.sendMessage = sendMessage;
    window.askQuestion = askQuestion;
    window.toggleVoiceInput = toggleVoiceInput;
    window.stopVoiceInput = stopVoiceInput;
    window.speakResponse = speakResponse;
    window.toggleAutoSpeak = toggleAutoSpeak;
    window.copyResponse = copyResponse;
    window.showExplanation = showExplanation;
    window.uploadImage = uploadImage;
    window.changeLanguage = changeLanguage;
    window.loadConversation = loadConversation;
    window.deleteConversation = deleteConversation;
    window.clearAllConversations = clearAllConversations;
    window.clearChat = clearChat;
    window.showToast = showToast;

    // ============================================================
    // INIT
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();