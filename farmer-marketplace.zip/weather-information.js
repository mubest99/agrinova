// ===== WEATHER INFORMATION — JAVASCRIPT =====
// Data Source: Open-Meteo API (Free, no API key required)

(function() {

    // ----- 1. DOM REFS -----
    const searchInput = document.getElementById('locationSearch');
    const searchBtn = document.getElementById('searchBtn');
    const heroLocation = document.getElementById('heroLocation');
    const heroTemp = document.getElementById('heroTemp');
    const heroCondition = document.getElementById('heroCondition');
    const heroFeels = document.getElementById('heroFeels');
    const heroRain = document.getElementById('heroRain');
    const heroHumidity = document.getElementById('heroHumidity');
    const heroWind = document.getElementById('heroWind');
    const heroBackground = document.getElementById('heroBackground');

    const detailTemp = document.getElementById('detailTemp');
    const detailFeels = document.getElementById('detailFeels');
    const detailRain = document.getElementById('detailRain');
    const detailHumidity = document.getElementById('detailHumidity');
    const detailWind = document.getElementById('detailWind');
    const detailDirection = document.getElementById('detailDirection');
    const detailPressure = document.getElementById('detailPressure');
    const detailVisibility = document.getElementById('detailVisibility');

    const hourlyForecast = document.getElementById('hourlyForecast');
    const dailyForecast = document.getElementById('dailyForecast');
    const recommendationText = document.getElementById('recommendationText');
    const activitiesText = document.getElementById('activitiesText');
    const alertsContainer = document.getElementById('alertsContainer');
    const cropSelect = document.getElementById('cropSelect');
    const cropWeatherResult = document.getElementById('cropWeatherResult');
    const weatherMessage = document.getElementById('weatherMessage');
    const messageText = document.getElementById('messageText');
    const retryBtn = document.getElementById('retryBtn');

    const sourceUpdated = document.getElementById('sourceUpdated');
    const sourceLocation = document.getElementById('sourceLocation');

    // ----- 2. STATE -----
    let currentLocation = 'Addis Ababa';
    let currentLat = 9.03;
    let currentLon = 38.74;
    let weatherData = null;
    let hourlyData = null;
    let dailyData = null;
    let currentBackground = '';

    // ----- 3. WEATHER BACKGROUND MAPPING (YOUR IMAGES) -----
    const weatherBackgrounds = {
        'clear': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvwdSRzRHwjmDI9FAqso31sz0I2eEV3m0NGjXAPRGj-A&s=10',
        'sunny': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvwdSRzRHwjmDI9FAqso31sz0I2eEV3m0NGjXAPRGj-A&s=10',
        'partly-cloudy': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnFTYwXgRSqawOR1SiLtJNXZ6g5KXbhcPKRP5ytYs9vw&s=10',
        'cloudy': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLOV77mRByGB1HN9Vb5LfPkq94EPbplEVF0PhzSDP-2g&s=10',
        'overcast': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLOV77mRByGB1HN9Vb5LfPkq94EPbplEVF0PhzSDP-2g&s=10',
        'rain': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR4KNgO0D_DYicJk47RWry5SNj2uwT0JGnGf685nCNfvg&s=10',
        'heavy-rain': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBfZOmyTE-OevOnFuJE5xDpMq4inW6gnOCS8faemNEPw&s=10',
        'thunderstorm': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnZKehPiEodUFRH_mf2Q3yDRUxr-9SolvMZ2og24VqXA&s=10',
        'fog': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNODKDcwyIpnUDuJy36ap5DoWQLCOqUMxlN3Y_OUiQig&s=10',
        'mist': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNODKDcwyIpnUDuJy36ap5DoWQLCOqUMxlN3Y_OUiQig&s=10',
        'windy': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3GCBgEvjDgPVfHciCrKovf1FDmmSZ5XAw_t2vpW_Yyg&s=10',
        'dry': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT51k5SJHNwwCbJfBtjuQvORLoU5SeUPVROv5GQ2MAbtA&s=10',
        'default': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvwdSRzRHwjmDI9FAqso31sz0I2eEV3m0NGjXAPRGj-A&s=10'
    };

    // ----- 4. WEATHER CODE MAPPING -----
    function getWeatherCondition(code) {
        const conditions = {
            0: 'clear', 1: 'clear', 2: 'partly-cloudy', 3: 'cloudy',
            45: 'fog', 48: 'fog',
            51: 'rain', 53: 'rain', 55: 'heavy-rain',
            56: 'rain', 57: 'rain',
            61: 'rain', 63: 'rain', 65: 'heavy-rain',
            66: 'rain', 67: 'rain',
            71: 'rain', 73: 'rain', 75: 'rain',
            77: 'rain',
            80: 'rain', 81: 'rain', 82: 'heavy-rain',
            85: 'rain', 86: 'rain',
            95: 'thunderstorm', 96: 'thunderstorm', 99: 'thunderstorm'
        };
        return conditions[code] || 'default';
    }

    function getConditionName(code) {
        const names = {
            0: 'Clear', 1: 'Sunny', 2: 'Partly Cloudy', 3: 'Cloudy',
            45: 'Fog', 48: 'Fog',
            51: 'Light Rain', 53: 'Moderate Rain', 55: 'Heavy Rain',
            56: 'Light Rain', 57: 'Light Rain',
            61: 'Light Rain', 63: 'Moderate Rain', 65: 'Heavy Rain',
            66: 'Light Rain', 67: 'Light Rain',
            71: 'Light Rain', 73: 'Moderate Rain', 75: 'Heavy Rain',
            77: 'Rain',
            80: 'Rain Showers', 81: 'Rain Showers', 82: 'Heavy Rain',
            85: 'Light Rain', 86: 'Heavy Rain',
            95: 'Thunderstorm', 96: 'Thunderstorm', 99: 'Thunderstorm'
        };
        return names[code] || 'Unknown';
    }

    // ----- 5. UPDATE BACKGROUND WITH SMOOTH TRANSITION -----
    function updateBackground(condition) {
        let bgUrl = weatherBackgrounds[condition] || weatherBackgrounds['default'];
        
        // Check if it's extremely dry (temperature > 35 and rain < 10)
        const temp = parseInt(heroTemp.textContent) || 0;
        const rain = parseInt(heroRain.textContent) || 0;
        if (temp > 35 && rain < 15) {
            bgUrl = weatherBackgrounds['dry'];
        }
        
        // Only update if background changed
        if (bgUrl !== currentBackground) {
            currentBackground = bgUrl;
            
            // Preload image for smooth transition
            const img = new Image();
            img.onload = function() {
                heroBackground.style.backgroundImage = `url('${bgUrl}')`;
                heroBackground.style.opacity = '1';
            };
            img.onerror = function() {
                // Fallback if image fails to load
                heroBackground.style.backgroundImage = `url('${weatherBackgrounds['default']}')`;
                heroBackground.style.opacity = '1';
            };
            img.src = bgUrl;
        }
    }

    // ----- 6. FETCH WEATHER DATA -----
    function fetchWeather(lat, lon, locationName) {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=temperature_2m,relativehumidity_2m,precipitation_probability,precipitation,wind_speed_10m,wind_direction_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max&timezone=auto&forecast_days=7`;

        showLoading('Fetching weather data...');

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error('Weather API request failed');
                return response.json();
            })
            .then(data => {
                weatherData = data;
                processWeatherData(data, locationName);
                hideLoading();
            })
            .catch(error => {
                console.error('Weather fetch error:', error);
                showError('Unable to retrieve weather information for this location.');
            });
    }

    // ----- 7. PROCESS WEATHER DATA -----
    function processWeatherData(data, locationName) {
        const current = data.current_weather;
        const hourly = data.hourly;
        const daily = data.daily;

        const temp = Math.round(current.temperature);
        const wind = Math.round(current.windspeed);
        const code = current.weathercode;
        const condition = getWeatherCondition(code);
        const conditionName = getConditionName(code);

        // Find current hour index
        const now = new Date();
        const currentHour = now.getHours();
        let hourIndex = hourly.time.findIndex(t => {
            const d = new Date(t);
            return d.getHours() >= currentHour;
        });
        if (hourIndex === -1) hourIndex = 0;

        const humidity = hourly.relativehumidity_2m[hourIndex] || 60;
        const rainProb = hourly.precipitation_probability[hourIndex] || 0;
        const feels = Math.round(temp - 2 + (humidity / 100) * 0.5);

        // Update Hero
        heroLocation.textContent = locationName + ', Ethiopia';
        heroTemp.textContent = temp + '°C';
        heroCondition.textContent = conditionName;
        heroFeels.textContent = feels + '°C';
        heroRain.textContent = rainProb + '%';
        heroHumidity.textContent = humidity + '%';
        heroWind.textContent = wind + ' km/h';

        // Update Background with smooth transition
        updateBackground(condition);

        // Update Details (remove pressure and visibility)
        detailTemp.textContent = temp + '°C';
        detailFeels.textContent = feels + '°C';
        detailRain.textContent = rainProb + '%';
        detailHumidity.textContent = humidity + '%';
        detailWind.textContent = wind + ' km/h';
        detailDirection.textContent = current.winddirection ? current.winddirection + '°' : 'Data unavailable';
        detailPressure.textContent = 'Data unavailable';
        detailVisibility.textContent = 'Data unavailable';

        // Update Source
        const nowStr = new Date().toLocaleString();
        sourceUpdated.textContent = nowStr;
        sourceLocation.textContent = locationName + ', Ethiopia';

        // Update Recommendations
        updateRecommendations(condition, rainProb, wind, temp);

        // Update Alerts
        updateAlerts(condition, rainProb, wind, temp);

        // Update Activities
        updateActivities(condition, rainProb, wind, temp);

        // Update Hourly Forecast
        renderHourlyForecast(hourly, hourIndex);

        // Update Daily Forecast
        renderDailyForecast(daily);

        // Update Charts
        renderRainfallChart(hourly, hourIndex);
        renderTemperatureChart(hourly, hourIndex);

        // Update Crop Weather
        updateCropWeather();
    }

    // ----- 8. RECOMMENDATIONS -----
    function updateRecommendations(condition, rainProb, wind, temp) {
        let rec = '';

        if (rainProb > 70) {
            rec = 'Heavy rainfall is expected. Consider postponing pesticide application where rainfall could reduce its effectiveness. Monitor fields for waterlogging risk.';
        } else if (rainProb > 50) {
            rec = 'Moderate rainfall is expected. Field activities may be affected. Check soil moisture before any irrigation decisions.';
        } else if (wind > 30) {
            rec = 'Strong winds are present. Avoid spraying during unsuitable wind conditions because of spray drift risk.';
        } else if (temp > 35) {
            rec = 'Extremely high temperatures and dry conditions. Ensure adequate water availability for crops. Monitor for heat stress and consider providing shade for sensitive crops.';
        } else if (temp > 30) {
            rec = 'High temperatures are expected. Monitor soil moisture and ensure adequate water availability for crops. Consider providing shade for sensitive crops.';
        } else if (temp < 10) {
            rec = 'Cool temperatures are present. Monitor for frost risk, especially in low-lying areas. Protect sensitive crops if needed.';
        } else if (condition === 'clear' || condition === 'sunny') {
            rec = 'Current weather conditions are generally suitable for routine field activities, subject to crop and soil conditions.';
        } else if (condition === 'cloudy' || condition === 'overcast') {
            rec = 'Overcast conditions with limited direct sunlight. Good for transplanting activities but monitor for increased disease pressure.';
        } else if (condition === 'fog' || condition === 'mist') {
            rec = 'Foggy conditions present. Reduced visibility for field operations. Check for potential disease development in crops.';
        } else if (condition === 'windy') {
            rec = 'Windy conditions. Avoid pesticide spraying and other operations sensitive to wind. Check for wind damage to crops.';
        } else {
            rec = 'Current weather conditions are generally suitable for routine field activities, subject to crop and soil conditions.';
        }

        recommendationText.textContent = rec;
    }

    // ----- 9. ALERTS -----
    function updateAlerts(condition, rainProb, wind, temp) {
        let alerts = [];

        if (rainProb > 80) {
            alerts.push({
                title: 'HEAVY RAIN EXPECTED',
                desc: 'Significant rainfall is forecast for the selected location.',
                action: 'Consider delaying activities that are sensitive to rainfall, such as certain spraying operations.'
            });
        } else if (rainProb > 60) {
            alerts.push({
                title: 'RAIN EXPECTED',
                desc: 'Moderate rainfall is forecast for the selected location.',
                action: 'Monitor field conditions and adjust irrigation schedules accordingly.'
            });
        }

        if (wind > 40) {
            alerts.push({
                title: 'STRONG WIND WARNING',
                desc: 'Strong winds are occurring at the selected location.',
                action: 'Avoid pesticide spraying and other activities sensitive to wind conditions.'
            });
        }

        if (temp > 38) {
            alerts.push({
                title: 'EXTREME HEAT WARNING',
                desc: 'Extremely high temperatures and dry conditions are occurring.',
                action: 'Ensure adequate water availability for crops. Monitor for heat stress and wilting.'
            });
        } else if (temp > 32) {
            alerts.push({
                title: 'HIGH TEMPERATURE WARNING',
                desc: 'High temperatures are occurring at the selected location.',
                action: 'Ensure adequate water availability for crops. Monitor for heat stress.'
            });
        }

        if (alerts.length === 0) {
            alertsContainer.innerHTML = '<p style="color: #7a8f7a; font-size: 0.9rem;">No active agricultural weather alerts for this location.</p>';
            return;
        }

        alertsContainer.innerHTML = alerts.map(a => `
            <div class="alert-item">
                <div class="alert-title">${a.title}</div>
                <div class="alert-desc">${a.desc}</div>
                <div class="alert-action">Recommendation: ${a.action}</div>
            </div>
        `).join('');
    }

    // ----- 10. ACTIVITIES -----
    function updateActivities(condition, rainProb, wind, temp) {
        let activities = [];

        if (rainProb < 30 && wind < 20 && temp < 30) {
            activities.push('Field work and planting activities are generally suitable.');
        }

        if (rainProb < 20 && wind < 15 && temp < 28) {
            activities.push('Spraying operations may be suitable, subject to wind direction and crop stage.');
        }

        if (rainProb > 60) {
            activities.push('Rain expected. Check irrigation requirements, as rainfall may reduce the need for irrigation.');
        }

        if (wind > 25) {
            activities.push('Windy conditions. Avoid spraying pesticides during high-wind periods.');
        }

        if (temp > 30) {
            activities.push('High temperatures. Monitor soil moisture and consider irrigation scheduling.');
        }

        if (temp > 38) {
            activities.push('Extreme heat. Provide shade for sensitive crops and ensure adequate water availability.');
        }

        if (activities.length === 0) {
            activitiesText.textContent = 'Based on current weather conditions, consider general field activities. Check specific crop requirements for detailed guidance.';
        } else {
            activitiesText.textContent = activities.join(' ');
        }
    }

    // ----- 11. HOURLY FORECAST -----
    function renderHourlyForecast(hourly, startIndex) {
        const times = hourly.time;
        const temps = hourly.temperature_2m;
        const rains = hourly.precipitation_probability;
        const winds = hourly.wind_speed_10m;

        let html = '';
        const maxHours = Math.min(12, times.length - startIndex);

        for (let i = startIndex; i < startIndex + maxHours && i < times.length; i++) {
            const time = new Date(times[i]);
            const hour = time.getHours();
            const ampm = hour >= 12 ? 'PM' : 'AM';
            const hour12 = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;

            html += `
                <div class="hour-item">
                    <div class="hour-time">${hour12} ${ampm}</div>
                    <div class="hour-temp">${Math.round(temps[i])}°C</div>
                    <div class="hour-condition">${rains[i] > 50 ? 'Rain' : 'Cloudy'}</div>
                    <div class="hour-rain">${rains[i]}%</div>
                    <div class="hour-wind">${Math.round(winds[i])} km/h</div>
                </div>
            `;
        }

        hourlyForecast.innerHTML = html;
    }

    // ----- 12. DAILY FORECAST -----
    function renderDailyForecast(daily) {
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const today = new Date().getDay();

        let html = '';

        for (let i = 0; i < Math.min(7, daily.time.length); i++) {
            const date = new Date(daily.time[i]);
            const dayIndex = (today + i) % 7;
            const dayName = i === 0 ? 'Today' : days[dayIndex];

            const high = Math.round(daily.temperature_2m_max[i]);
            const low = Math.round(daily.temperature_2m_min[i]);
            const rain = daily.precipitation_probability_max[i] || 0;

            html += `
                <div class="day-item">
                    <div class="day-name">${dayName}</div>
                    <div class="day-date">${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</div>
                    <div class="day-temp">${high}° / ${low}°</div>
                    <div class="day-condition">${rain > 50 ? 'Rain' : 'Clear'}</div>
                    <div class="day-rain">${rain}%</div>
                </div>
            `;
        }

        dailyForecast.innerHTML = html;
    }

    // ----- 13. RAINFALL CHART -----
    function renderRainfallChart(hourly, startIndex) {
        const canvas = document.getElementById('rainfallChart');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        canvas.width = canvas.parentElement.clientWidth - 60;
        canvas.height = 200;

        const width = canvas.width;
        const height = canvas.height;
        const padding = { top: 20, bottom: 30, left: 30, right: 20 };
        const chartWidth = width - padding.left - padding.right;
        const chartHeight = height - padding.top - padding.bottom;

        const maxHours = Math.min(24, hourly.time.length - startIndex);
        const times = hourly.time.slice(startIndex, startIndex + maxHours);
        const rains = hourly.precipitation_probability.slice(startIndex, startIndex + maxHours);

        ctx.clearRect(0, 0, width, height);

        ctx.fillStyle = '#F7F4EA';
        ctx.fillRect(0, 0, width, height);

        const maxRain = Math.max(10, ...rains);

        const barWidth = Math.min(20, chartWidth / times.length - 2);
        const spacing = Math.max(4, (chartWidth - barWidth * times.length) / (times.length + 1));

        rains.forEach((rain, i) => {
            const x = padding.left + spacing + i * (barWidth + spacing);
            const barHeight = (rain / maxRain) * chartHeight;
            const y = padding.top + chartHeight - barHeight;

            const gradient = ctx.createLinearGradient(x, y, x, padding.top + chartHeight);
            gradient.addColorStop(0, '#1a237e');
            gradient.addColorStop(0.5, '#42a5f5');
            gradient.addColorStop(1, '#90caf9');

            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.roundRect(x, y, barWidth, barHeight, 4);
            ctx.fill();

            const hour = new Date(times[i]).getHours();
            ctx.fillStyle = '#7a8f7a';
            ctx.font = '10px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(hour + 'h', x + barWidth / 2, padding.top + chartHeight + 18);
        });

        ctx.fillStyle = '#7a8f7a';
        ctx.font = '10px Inter';
        ctx.textAlign = 'right';
        for (let i = 0; i <= 4; i++) {
            const val = Math.round((i / 4) * maxRain);
            const y = padding.top + chartHeight - (i / 4) * chartHeight;
            ctx.fillText(val + '%', padding.left - 5, y + 3);
        }

        ctx.fillStyle = '#164A2A';
        ctx.font = '10px Inter';
        ctx.textAlign = 'left';
        ctx.fillText('Precipitation Probability (%)', padding.left, 15);
    }

    // ----- 14. TEMPERATURE CHART -----
    function renderTemperatureChart(hourly, startIndex) {
        const canvas = document.getElementById('temperatureChart');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        canvas.width = canvas.parentElement.clientWidth - 60;
        canvas.height = 200;

        const width = canvas.width;
        const height = canvas.height;
        const padding = { top: 20, bottom: 30, left: 30, right: 20 };
        const chartWidth = width - padding.left - padding.right;
        const chartHeight = height - padding.top - padding.bottom;

        const maxHours = Math.min(24, hourly.time.length - startIndex);
        const times = hourly.time.slice(startIndex, startIndex + maxHours);
        const temps = hourly.temperature_2m.slice(startIndex, startIndex + maxHours);

        ctx.clearRect(0, 0, width, height);

        ctx.fillStyle = '#F7F4EA';
        ctx.fillRect(0, 0, width, height);

        const minTemp = Math.max(0, Math.min(...temps) - 5);
        const maxTemp = Math.max(40, Math.max(...temps) + 5);

        ctx.strokeStyle = '#e0e4e0';
        ctx.lineWidth = 0.5;
        for (let i = 0; i <= 4; i++) {
            const y = padding.top + chartHeight - (i / 4) * chartHeight;
            ctx.beginPath();
            ctx.moveTo(padding.left, y);
            ctx.lineTo(padding.left + chartWidth, y);
            ctx.stroke();

            const val = Math.round(minTemp + (i / 4) * (maxTemp - minTemp));
            ctx.fillStyle = '#7a8f7a';
            ctx.font = '10px Inter';
            ctx.textAlign = 'right';
            ctx.fillText(val + '°', padding.left - 5, y + 3);
        }

        ctx.strokeStyle = '#2E7D32';
        ctx.lineWidth = 2;
        ctx.beginPath();

        temps.forEach((temp, i) => {
            const x = padding.left + (i / (temps.length - 1 || 1)) * chartWidth;
            const y = padding.top + chartHeight - ((temp - minTemp) / (maxTemp - minTemp)) * chartHeight;

            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });
        ctx.stroke();

        temps.forEach((temp, i) => {
            const x = padding.left + (i / (temps.length - 1 || 1)) * chartWidth;
            const y = padding.top + chartHeight - ((temp - minTemp) / (maxTemp - minTemp)) * chartHeight;

            ctx.fillStyle = '#164A2A';
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#164A2A';
            ctx.font = '9px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(Math.round(temp) + '°', x, y - 8);
        });

        const step = Math.max(1, Math.floor(temps.length / 8));
        for (let i = 0; i < temps.length; i += step) {
            const x = padding.left + (i / (temps.length - 1 || 1)) * chartWidth;
            const hour = new Date(times[i]).getHours();
            ctx.fillStyle = '#7a8f7a';
            ctx.font = '9px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(hour + 'h', x, padding.top + chartHeight + 18);
        }

        ctx.fillStyle = '#164A2A';
        ctx.font = '10px Inter';
        ctx.textAlign = 'left';
        ctx.fillText('Temperature (°C)', padding.left, 15);
    }

    // ----- 15. CROP WEATHER COMPARISON -----
    function updateCropWeather() {
        const crop = cropSelect.value;
        const cropRequirements = {
            maize: { temp: { min: 18, max: 32 }, rain: 500, humidity: { min: 60, max: 85 } },
            teff: { temp: { min: 15, max: 30 }, rain: 400, humidity: { min: 50, max: 80 } },
            wheat: { temp: { min: 10, max: 25 }, rain: 450, humidity: { min: 55, max: 80 } },
            coffee: { temp: { min: 15, max: 24 }, rain: 1500, humidity: { min: 70, max: 90 } },
            sorghum: { temp: { min: 20, max: 35 }, rain: 350, humidity: { min: 40, max: 70 } },
            barley: { temp: { min: 10, max: 22 }, rain: 400, humidity: { min: 50, max: 75 } },
            sesame: { temp: { min: 20, max: 32 }, rain: 300, humidity: { min: 40, max: 70 } },
            enset: { temp: { min: 15, max: 26 }, rain: 1200, humidity: { min: 70, max: 90 } }
        };

        const req = cropRequirements[crop];
        if (!req) {
            cropWeatherResult.innerHTML = '<p>Crop information not available.</p>';
            return;
        }

        const temp = parseInt(heroTemp.textContent);
        const rain = parseInt(heroRain.textContent);
        const humidity = parseInt(heroHumidity.textContent);

        const tempStatus = (temp >= req.temp.min && temp <= req.temp.max) ? 'suitable' : (temp < req.temp.min ? 'moderate' : 'unsuitable');
        const rainStatus = (rain >= req.rain * 0.6 && rain <= req.rain * 1.4) ? 'suitable' : 'moderate';
        const humidityStatus = (humidity >= req.humidity.min && humidity <= req.humidity.max) ? 'suitable' : 'moderate';

        const allSuitable = tempStatus === 'suitable' && rainStatus === 'suitable' && humidityStatus === 'suitable';
        const overallStatus = allSuitable ? 'suitable' : (tempStatus === 'unsuitable' ? 'unsuitable' : 'moderate');

        const statusLabels = {
            'suitable': 'Within documented range',
            'moderate': 'Moderately suitable',
            'unsuitable': 'Outside documented range'
        };

        const statusColors = {
            'suitable': 'suitable',
            'moderate': 'moderate',
            'unsuitable': 'unsuitable'
        };

        cropWeatherResult.innerHTML = `
            <div style="margin-bottom:0.8rem;font-weight:600;color:#164A2A;">${crop.charAt(0).toUpperCase() + crop.slice(1)} — Current Weather Compatibility</div>
            <div class="crop-comparison">
                <div class="crop-comp-item">
                    <div class="comp-label">Temperature</div>
                    <div class="comp-value">${temp}°C</div>
                    <span class="comp-status ${statusColors[tempStatus]}">${statusLabels[tempStatus]}</span>
                    <div style="font-size:0.65rem;color:#7a8f7a;margin-top:0.2rem;">Requires: ${req.temp.min}–${req.temp.max}°C</div>
                </div>
                <div class="crop-comp-item">
                    <div class="comp-label">Rain Probability</div>
                    <div class="comp-value">${rain}%</div>
                    <span class="comp-status ${statusColors[rainStatus]}">${statusLabels[rainStatus]}</span>
                    <div style="font-size:0.65rem;color:#7a8f7a;margin-top:0.2rem;">Requires: ~${req.rain}mm annually</div>
                </div>
                <div class="crop-comp-item">
                    <div class="comp-label">Humidity</div>
                    <div class="comp-value">${humidity}%</div>
                    <span class="comp-status ${statusColors[humidityStatus]}">${statusLabels[humidityStatus]}</span>
                    <div style="font-size:0.65rem;color:#7a8f7a;margin-top:0.2rem;">Requires: ${req.humidity.min}–${req.humidity.max}%</div>
                </div>
            </div>
            <div style="margin-top:0.8rem;padding:0.8rem;background:${overallStatus === 'suitable' ? '#e8f5e9' : overallStatus === 'moderate' ? '#fff3e0' : '#fce4ec'};border-radius:8px;font-size:0.9rem;color:#26332A;">
                <strong>Overall Assessment:</strong> ${overallStatus === 'suitable' ? 'Current conditions are within the documented range for this crop.' : overallStatus === 'moderate' ? 'Current conditions are partially within the documented range. Some factors may require attention.' : 'Current conditions are outside the documented range for this crop. Consider adjusting management practices.'}
            </div>
        `;
    }

    // ----- 16. LOADING / ERROR STATES -----
    function showLoading(message) {
        weatherMessage.style.display = 'block';
        messageText.textContent = message || 'Loading weather information...';
        retryBtn.style.display = 'none';
    }

    function hideLoading() {
        weatherMessage.style.display = 'none';
    }

    function showError(message) {
        weatherMessage.style.display = 'block';
        messageText.textContent = message || 'Unable to retrieve weather information for this location.';
        retryBtn.style.display = 'inline-block';
    }

    // ----- 17. LOCATION SEARCH -----
    function searchLocation(query) {
        const locations = {
            'addis ababa': { lat: 9.03, lon: 38.74, name: 'Addis Ababa' },
            'bahir dar': { lat: 11.6, lon: 37.38, name: 'Bahir Dar' },
            'hawassa': { lat: 7.06, lon: 38.48, name: 'Hawassa' },
            'jimma': { lat: 7.67, lon: 36.83, name: 'Jimma' },
            'mekelle': { lat: 13.50, lon: 39.47, name: 'Mekelle' },
            'dire dawa': { lat: 9.60, lon: 41.85, name: 'Dire Dawa' },
            'bonga': { lat: 7.27, lon: 36.24, name: 'Bonga' },
            'asosa': { lat: 10.07, lon: 34.53, name: 'Asosa' },
            'semera': { lat: 11.79, lon: 41.01, name: 'Semera' },
            'jijiga': { lat: 9.35, lon: 42.80, name: 'Jijiga' },
            'harar': { lat: 9.31, lon: 42.12, name: 'Harar' },
            'gambela': { lat: 7.92, lon: 34.59, name: 'Gambela' },
            'sodo': { lat: 6.86, lon: 37.78, name: 'Wolaita Sodo' },
            'adama': { lat: 8.54, lon: 39.27, name: 'Adama' },
            'dessie': { lat: 11.13, lon: 39.63, name: 'Dessie' }
        };

        const queryLower = query.toLowerCase().trim();
        let found = null;

        if (locations[queryLower]) {
            found = locations[queryLower];
        } else {
            for (const [key, val] of Object.entries(locations)) {
                if (key.includes(queryLower) || queryLower.includes(key)) {
                    found = val;
                    break;
                }
            }
        }

        if (found) {
            currentLocation = found.name;
            currentLat = found.lat;
            currentLon = found.lon;
            fetchWeather(currentLat, currentLon, currentLocation);
            searchInput.value = found.name;
        } else {
            showError('Location not found. Please try another search.');
        }
    }

    // ----- 18. EVENT LISTENERS -----
    searchBtn.addEventListener('click', function() {
        const query = searchInput.value.trim();
        if (query) searchLocation(query);
    });

    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const query = this.value.trim();
            if (query) searchLocation(query);
        }
    });

    cropSelect.addEventListener('change', updateCropWeather);

    retryBtn.addEventListener('click', function() {
        fetchWeather(currentLat, currentLon, currentLocation);
    });

    // ----- 19. ROUND RECT POLYFILL -----
    if (!CanvasRenderingContext2D.prototype.roundRect) {
        CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, r) {
            if (r > w / 2) r = w / 2;
            if (r > h / 2) r = h / 2;
            this.moveTo(x + r, y);
            this.lineTo(x + w - r, y);
            this.quadraticCurveTo(x + w, y, x + w, y + r);
            this.lineTo(x + w, y + h - r);
            this.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
            this.lineTo(x + r, y + h);
            this.quadraticCurveTo(x, y + h, x, y + h - r);
            this.lineTo(x, y + r);
            this.quadraticCurveTo(x, y, x + r, y);
            this.closePath();
            return this;
        };
    }

    // ----- 20. INITIALIZE -----
    console.log('🌤️ Weather Information page loaded with custom backgrounds.');
    console.log('📍 Default location: Addis Ababa');

    // Load default location
    fetchWeather(currentLat, currentLon, currentLocation);

})();