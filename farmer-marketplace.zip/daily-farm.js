(function() {
    "use strict";

    // ============================================================
    // DATA HELPERS
    // ============================================================

    function getFarmer() {
        let raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getCrops() {
        let raw = localStorage.getItem('agrinova_crops_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getDailyRecords() {
        let raw = localStorage.getItem('agrinova_daily_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveDailyRecords(records) {
        localStorage.setItem('agrinova_daily_records', JSON.stringify(records));
    }

    function getTodayRecord() {
        const records = getDailyRecords();
        const today = new Date().toDateString();
        return records.find(r => new Date(r.date).toDateString() === today) || null;
    }

    // ============================================================
    // STATE
    // ============================================================

    let state = {
        activities: [],
        observations: [],
        assessment: null,
        weatherImpact: null,
        photos: [],
        notes: '',
        currentActivityType: null,
        recordSaved: false
    };

    let currentRecord = getTodayRecord();

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova Daily Farm Initializing...');
        
        updateDate();
        updateProfile();
        setupProfileImage();
        setupDropdown();
        setupSearch();
        fetchWeather();
        populateCropDropdown();
        
        // Load today's record if exists
        if (currentRecord) {
            loadRecord(currentRecord);
            state.recordSaved = true;
            document.getElementById('saveDailyRecord').textContent = 'Update Daily Farm Record';
        }
        
        // Setup weather impact toggle
        document.getElementById('weatherImpact').addEventListener('change', function() {
            if (this.value === 'Yes') {
                document.getElementById('weatherImpactDetail').style.display = 'block';
            } else {
                document.getElementById('weatherImpactDetail').style.display = 'none';
            }
        });

        // Setup photo upload
        document.getElementById('photoInput').addEventListener('change', handlePhotoUpload);

        // Load history
        renderHistory();

        updateSummary();
        updateStatus();

        console.log('AgriNova Daily Farm Ready.');
    }

    // ============================================================
    // DATE
    // ============================================================

    function updateDate() {
        const now = new Date();
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        
        document.getElementById('dateDay').textContent = days[now.getDay()];
        document.getElementById('dateFull').textContent = `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
        document.getElementById('summaryDate').textContent = `${days[now.getDay()]}, ${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    }

    // ============================================================
    // PROFILE
    // ============================================================

    function updateProfile() {
        const farmer = getFarmer();
        if (!farmer) return;

        const name = farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('navName').textContent = name;
        document.getElementById('pdName').textContent = name;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || '—';
        
        const city = farmer.city || '—';
        const region = farmer.region || '—';
        document.getElementById('pdLocation').textContent = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdFarmland').textContent = farmer.hectares ? `${farmer.hectares} ha` : '—';
    }

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }
        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim().toLowerCase();
                    if (query) {
                        const records = getDailyRecords();
                        const results = records.filter(r => {
                            const activities = r.activities || [];
                            const observations = r.observations || [];
                            const matchActivity = activities.some(a => 
                                a.type?.toLowerCase().includes(query) || 
                                a.details?.toLowerCase().includes(query)
                            );
                            const matchObservation = observations.some(o => 
                                o.description?.toLowerCase().includes(query) ||
                                o.category?.toLowerCase().includes(query)
                            );
                            return matchActivity || matchObservation;
                        });
                        if (results.length > 0) {
                            showToast(`Found ${results.length} record${results.length > 1 ? 's' : ''} matching "${query}"`);
                        } else {
                            showToast(`No records found matching "${query}"`);
                        }
                    }
                }
            });
        }
    }

    // ============================================================
    // CROP DROPDOWN
    // ============================================================

    function populateCropDropdown() {
        const crops = getCrops();
        const selects = document.querySelectorAll('#observationCrop, #activityCrop');

        selects.forEach(select => {
            select.innerHTML = '<option value="">Select crop</option>';
            crops.forEach(crop => {
                select.innerHTML += `<option value="${crop.name}">${crop.name}</option>`;
            });
            if (crops.length === 0) {
                select.innerHTML += '<option value="" disabled>No crops added yet</option>';
            }
        });
    }

    // ============================================================
    // ACTIVITY SELECTION
    // ============================================================

    window.selectActivity = function(type) {
        state.currentActivityType = type;
        
        // Highlight selected
        document.querySelectorAll('.activity-option').forEach(el => {
            el.classList.remove('active');
        });
        document.querySelector(`.activity-option[data-type="${type}"]`)?.classList.add('active');

        // Show form
        document.getElementById('activityDetailForm').style.display = 'block';
        
        const formContent = document.getElementById('activityFormContent');
        const activityNames = {
            'irrigation': 'Irrigation / Watering',
            'fertilizer': 'Fertilizer Application',
            'pest': 'Pest Management',
            'weed': 'Weed Management',
            'planting': 'Planting / Sowing',
            'soil': 'Soil Preparation',
            'pruning': 'Pruning',
            'harvesting': 'Harvesting',
            'inspection': 'Field Inspection',
            'maintenance': 'Equipment Maintenance',
            'land': 'Land Preparation',
            'other': 'Other Activity'
        };

        const crops = getCrops();
        let cropOptions = '<option value="">Select crop/field</option>';
        crops.forEach(crop => {
            cropOptions += `<option value="${crop.name}">${crop.name}</option>`;
        });
        if (crops.length === 0) {
            cropOptions += '<option value="" disabled>No crops added</option>';
        }

        let detailHtml = `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                <h4 style="font-family:'Playfair Display',serif; color:#102F26;">${activityNames[type] || 'Activity'}</h4>
                <button class="btn-secondary btn-sm" onclick="document.getElementById('activityDetailForm').style.display='none'">Cancel</button>
            </div>
            <div class="activity-detail-row">
                <div class="form-group activity-detail-full">
                    <label>Which crop or field?</label>
                    <select id="activityCrop">${cropOptions}</select>
                </div>
        `;

        // Activity-specific fields
        switch(type) {
            case 'irrigation':
                detailHtml += `
                    <div class="form-group">
                        <label>Irrigation Method</label>
                        <select id="activityMethod">
                            <option value="Drip">Drip</option>
                            <option value="Sprinkler">Sprinkler</option>
                            <option value="Surface">Surface</option>
                            <option value="Manual">Manual</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Duration (hours)</label>
                        <input type="number" id="activityDuration" step="0.5" placeholder="e.g., 2">
                    </div>
                    <div class="form-group">
                        <label>Water Amount</label>
                        <input type="text" id="activityAmount" placeholder="e.g., 5000 liters">
                    </div>
                `;
                break;
            case 'fertilizer':
                detailHtml += `
                    <div class="form-group">
                        <label>Fertilizer Name/Type</label>
                        <input type="text" id="activityFertilizer" placeholder="e.g., DAP, Urea">
                    </div>
                    <div class="form-group">
                        <label>Quantity Applied</label>
                        <input type="text" id="activityQuantity" placeholder="e.g., 50 kg">
                    </div>
                    <div class="form-group">
                        <label>Application Method</label>
                        <select id="activityMethod">
                            <option value="Broadcast">Broadcast</option>
                            <option value="Side Dressing">Side Dressing</option>
                            <option value="Foliar">Foliar</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                `;
                break;
            case 'pest':
                detailHtml += `
                    <div class="form-group">
                        <label>What issue was observed?</label>
                        <input type="text" id="activityIssue" placeholder="Describe the issue">
                    </div>
                    <div class="form-group">
                        <label>Action taken</label>
                        <input type="text" id="activityAction" placeholder="What did you do?">
                    </div>
                    <div class="form-group">
                        <label>Product used (optional)</label>
                        <input type="text" id="activityProduct" placeholder="Product name">
                    </div>
                `;
                break;
            case 'weed':
                detailHtml += `
                    <div class="form-group">
                        <label>Management Method</label>
                        <select id="activityMethod">
                            <option value="Manual Removal">Manual Removal</option>
                            <option value="Mechanical">Mechanical</option>
                            <option value="Chemical">Chemical</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Area Treated (hectares)</label>
                        <input type="number" id="activityArea" step="0.01" placeholder="e.g., 1.5">
                    </div>
                `;
                break;
            case 'planting':
                detailHtml += `
                    <div class="form-group">
                        <label>Area Planted (hectares)</label>
                        <input type="number" id="activityArea" step="0.01" placeholder="e.g., 2">
                    </div>
                    <div class="form-group">
                        <label>Seed Quantity</label>
                        <input type="text" id="activitySeed" placeholder="e.g., 25 kg">
                    </div>
                `;
                break;
            case 'harvesting':
                detailHtml += `
                    <div class="form-group">
                        <label>Harvesting Status</label>
                        <select id="activityStatus">
                            <option value="Started">Started</option>
                            <option value="Partially Completed">Partially Completed</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Quantity Harvested</label>
                        <input type="text" id="activityQuantity" placeholder="e.g., 500 kg">
                    </div>
                `;
                break;
            case 'inspection':
                detailHtml += `
                    <div class="form-group activity-detail-full">
                        <label>What was observed?</label>
                        <textarea id="activityObservation" rows="2" placeholder="Describe what you observed..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>Requires attention?</label>
                        <select id="activityAttention">
                            <option value="No">No</option>
                            <option value="Yes">Yes</option>
                            <option value="Not Sure">Not Sure</option>
                        </select>
                    </div>
                `;
                break;
            case 'maintenance':
                detailHtml += `
                    <div class="form-group">
                        <label>Equipment Name</label>
                        <input type="text" id="activityEquipment" placeholder="Equipment name">
                    </div>
                    <div class="form-group">
                        <label>Maintenance Performed</label>
                        <input type="text" id="activityMaintenance" placeholder="What was done?">
                    </div>
                    <div class="form-group">
                        <label>Condition After</label>
                        <select id="activityCondition">
                            <option value="Good">Good</option>
                            <option value="Fair">Fair</option>
                            <option value="Needs Further Work">Needs Further Work</option>
                        </select>
                    </div>
                `;
                break;
            case 'other':
                detailHtml += `
                    <div class="form-group activity-detail-full">
                        <label>Activity Name</label>
                        <input type="text" id="activityName" placeholder="Name of the activity">
                    </div>
                    <div class="form-group activity-detail-full">
                        <label>Description</label>
                        <textarea id="activityDescription" rows="2" placeholder="Describe the activity..."></textarea>
                    </div>
                `;
                break;
            default:
                detailHtml += `
                    <div class="form-group activity-detail-full">
                        <label>Details</label>
                        <textarea id="activityDetails" rows="2" placeholder="Add details..."></textarea>
                    </div>
                `;
        }

        detailHtml += `
                <div class="form-group activity-detail-full">
                    <label>Additional Notes</label>
                    <textarea id="activityNotes" rows="2" placeholder="Any additional notes..."></textarea>
                </div>
                <div class="form-group activity-detail-full" style="margin-top:0.5rem;">
                    <button class="btn-primary btn-sm" onclick="addActivity()">
                        <i class="fas fa-plus"></i> Add Activity
                    </button>
                </div>
            </div>
        `;

        formContent.innerHTML = detailHtml;
    };

    // ============================================================
    // ADD ACTIVITY
    // ============================================================

    window.addActivity = function() {
        const type = state.currentActivityType;
        if (!type) {
            showToast('Please select an activity type first.', 'error');
            return;
        }

        const crop = document.getElementById('activityCrop')?.value || '';
        const notes = document.getElementById('activityNotes')?.value || '';

        // Collect details based on type
        let details = {};
        const fields = document.querySelectorAll('#activityFormContent input, #activityFormContent select, #activityFormContent textarea');
        fields.forEach(field => {
            if (field.id && field.id !== 'activityNotes' && field.id !== 'activityCrop') {
                details[field.id.replace('activity', '').toLowerCase()] = field.value;
            }
        });

        const activity = {
            id: 'act_' + Date.now(),
            type: type,
            crop: crop,
            details: details,
            notes: notes,
            createdAt: new Date().toISOString()
        };

        state.activities.push(activity);
        renderActivities();
        updateSummary();
        updateStatus();
        document.getElementById('activityDetailForm').style.display = 'none';
        document.querySelectorAll('.activity-option').forEach(el => el.classList.remove('active'));
        showToast('Activity added successfully!');
    };

    // ============================================================
    // RENDER ACTIVITIES
    // ============================================================

    function renderActivities() {
        const container = document.getElementById('activitiesList');
        const wrapper = document.getElementById('addedActivities');

        if (state.activities.length === 0) {
            wrapper.style.display = 'none';
            document.getElementById('activityCount').textContent = '0 activities';
            return;
        }

        wrapper.style.display = 'block';
        document.getElementById('activityCount').textContent = `${state.activities.length} activities`;

        const typeLabels = {
            'irrigation': 'Irrigation',
            'fertilizer': 'Fertilizer',
            'pest': 'Pest Management',
            'weed': 'Weed Management',
            'planting': 'Planting',
            'soil': 'Soil Prep',
            'pruning': 'Pruning',
            'harvesting': 'Harvesting',
            'inspection': 'Inspection',
            'maintenance': 'Maintenance',
            'land': 'Land Prep',
            'other': 'Other'
        };

        let html = '';
        state.activities.forEach((act, index) => {
            html += `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:0.6rem 0.8rem; background:#F7F6F1; border-radius:8px; margin-bottom:0.4rem;">
                    <div>
                        <span style="font-weight:500;">${typeLabels[act.type] || act.type}</span>
                        ${act.crop ? `<span style="color:#69736C; font-size:0.85rem;"> · ${act.crop}</span>` : ''}
                    </div>
                    <button class="btn-danger-sm" onclick="removeActivity('${act.id}')">
                        <i class="fas fa-times"></i> Remove
                    </button>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    // ============================================================
    // REMOVE ACTIVITY
    // ============================================================

    window.removeActivity = function(id) {
        state.activities = state.activities.filter(a => a.id !== id);
        renderActivities();
        updateSummary();
        updateStatus();
    };

    // ============================================================
    // OBSERVATIONS
    // ============================================================

    window.addObservation = function() {
        const category = document.getElementById('observationCategory').value;
        const crop = document.getElementById('observationCrop').value;
        const priority = document.getElementById('observationPriority').value;
        const description = document.getElementById('observationDescription').value.trim();

        if (!category || !description) {
            showToast('Please select a category and enter a description.', 'error');
            return;
        }

        const observation = {
            id: 'obs_' + Date.now(),
            category: category,
            crop: crop || null,
            priority: priority,
            description: description,
            createdAt: new Date().toISOString()
        };

        state.observations.push(observation);
        renderObservations();
        updateSummary();
        updateStatus();

        // Clear form
        document.getElementById('observationCategory').value = '';
        document.getElementById('observationDescription').value = '';
        showToast('Observation added successfully!');
    };

    function renderObservations() {
        const container = document.getElementById('observationsList');
        const wrapper = document.getElementById('addedObservations');

        if (state.observations.length === 0) {
            wrapper.style.display = 'none';
            document.getElementById('observationCount').textContent = '0 observations';
            return;
        }

        wrapper.style.display = 'block';
        document.getElementById('observationCount').textContent = `${state.observations.length} observations`;

        const priorityColors = {
            'Informational': '#69736C',
            'Needs Attention': '#B9822A',
            'Important': '#B94A48'
        };

        let html = '';
        state.observations.forEach((obs, index) => {
            html += `
                <div style="display:flex; justify-content:space-between; align-items:flex-start; padding:0.6rem 0.8rem; background:#F7F6F1; border-radius:8px; margin-bottom:0.4rem;">
                    <div>
                        <span style="font-weight:500;">${obs.category}</span>
                        ${obs.crop ? `<span style="color:#69736C; font-size:0.85rem;"> · ${obs.crop}</span>` : ''}
                        <div style="font-size:0.85rem; color:#17231D; margin-top:0.1rem;">${obs.description}</div>
                        <span style="font-size:0.7rem; color:${priorityColors[obs.priority] || '#69736C'}; font-weight:500;">${obs.priority}</span>
                    </div>
                    <button class="btn-danger-sm" onclick="removeObservation('${obs.id}')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    window.removeObservation = function(id) {
        state.observations = state.observations.filter(o => o.id !== id);
        renderObservations();
        updateSummary();
        updateStatus();
    };

    // ============================================================
    // ASSESSMENT
    // ============================================================

    window.selectAssessment = function(value) {
        state.assessment = value;
        document.querySelectorAll('.assessment-option').forEach(el => {
            el.classList.toggle('active', el.dataset.value === value);
        });
        document.getElementById('selectedAssessment').textContent = `Selected: ${value}`;
        updateSummary();
        updateStatus();
    };

    // ============================================================
    // PHOTOS
    // ============================================================

    function handlePhotoUpload(e) {
        const files = e.target.files;
        if (!files.length) return;

        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            if (!file.type.startsWith('image/')) continue;

            const reader = new FileReader();
            reader.onload = function(ev) {
                const dataUrl = ev.target.result;
                state.photos.push({
                    id: 'photo_' + Date.now() + '_' + i,
                    dataUrl: dataUrl,
                    caption: '',
                    createdAt: new Date().toISOString()
                });
                renderPhotos();
                updateSummary();
                updateStatus();
            };
            reader.readAsDataURL(file);
        }
        // Reset input
        e.target.value = '';
    }

    function renderPhotos() {
        const container = document.getElementById('photoPreviewGrid');
        const count = document.getElementById('photoCount');

        if (state.photos.length === 0) {
            container.style.display = 'none';
            count.textContent = '0 photos';
            return;
        }

        container.style.display = 'grid';
        count.textContent = `${state.photos.length} photos`;

        let html = '';
        state.photos.forEach((photo, index) => {
            html += `
                <div class="photo-grid-item">
                    <img src="${photo.dataUrl}" alt="Farm documentation">
                    <div class="photo-caption">
                        <input type="text" placeholder="Add caption..." 
                               style="width:100%; border:none; font-size:0.75rem; padding:0;"
                               onchange="updatePhotoCaption('${photo.id}', this.value)">
                    </div>
                    <div class="remove-photo" onclick="removePhoto('${photo.id}')">
                        <i class="fas fa-times"></i>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    window.updatePhotoCaption = function(id, caption) {
        const photo = state.photos.find(p => p.id === id);
        if (photo) photo.caption = caption;
    };

    window.removePhoto = function(id) {
        state.photos = state.photos.filter(p => p.id !== id);
        renderPhotos();
        updateSummary();
        updateStatus();
    };

    // ============================================================
    // WEATHER
    // ============================================================

    async function fetchWeather() {
        try {
            const farmer = getFarmer();
            const city = farmer?.city || 'Addis Ababa';
            
            // Try geolocation first
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        await getWeatherData(latitude, longitude);
                    },
                    async () => {
                        // Fallback to city
                        await getWeatherByCity(city);
                    }
                );
            } else {
                await getWeatherByCity(city);
            }
        } catch (e) {
            console.warn('Weather error:', e);
            document.getElementById('weatherTempDisplay').textContent = '--°C';
            document.getElementById('weatherConditionDisplay').textContent = 'Weather unavailable';
        }
    }

    async function getWeatherData(lat, lon) {
        try {
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=relativehumidity_2m,windspeed_10m&timezone=auto`;
            const resp = await fetch(url);
            if (!resp.ok) throw new Error('Weather API error');
            const data = await resp.json();
            if (data.current_weather) {
                updateWeatherDisplay(data.current_weather, data);
            }
        } catch (e) {
            console.warn('Weather fetch error:', e);
        }
    }

    async function getWeatherByCity(city) {
        try {
            const geoResp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
            const geoData = await geoResp.json();
            if (geoData && geoData.length > 0) {
                const { lat, lon } = geoData[0];
                await getWeatherData(parseFloat(lat), parseFloat(lon));
            }
        } catch (e) {
            console.warn('City geocode error:', e);
        }
    }

    function updateWeatherDisplay(weather, fullData) {
        const temp = weather.temperature !== undefined ? `${Math.round(weather.temperature)}°C` : '--°C';
        document.getElementById('weatherTempDisplay').textContent = temp;
        document.getElementById('navTemp').textContent = temp;

        const condition = weather.weathercode ? mapWeatherCode(weather.weathercode) : '—';
        document.getElementById('weatherConditionDisplay').textContent = condition;

        let details = [];
        if (fullData.hourly?.relativehumidity_2m?.[0]) {
            details.push(`Humidity: ${Math.round(fullData.hourly.relativehumidity_2m[0])}%`);
        }
        if (weather.windspeed) {
            details.push(`Wind: ${Math.round(weather.windspeed)} km/h`);
        }
        document.getElementById('weatherDetailsDisplay').textContent = details.join(' · ') || '';
    }

    function mapWeatherCode(code) {
        const map = {
            0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
            45: 'Fog', 48: 'Fog',
            51: 'Drizzle', 53: 'Drizzle', 55: 'Drizzle',
            61: 'Rain', 63: 'Rain', 65: 'Rain',
            71: 'Snow', 73: 'Snow', 75: 'Snow',
            80: 'Rain showers', 81: 'Rain showers', 82: 'Rain showers',
            95: 'Thunderstorm', 96: 'Thunderstorm', 99: 'Thunderstorm'
        };
        return map[code] || '—';
    }

    // ============================================================
    // SUMMARY
    // ============================================================

    function updateSummary() {
        document.getElementById('summaryActivities').textContent = state.activities.length;
        document.getElementById('summaryObservations').textContent = state.observations.length;
        document.getElementById('summaryPhotos').textContent = state.photos.length;
        document.getElementById('summaryAssessment').textContent = state.assessment || 'Not recorded';

        const weatherImpact = document.getElementById('weatherImpact').value;
        document.getElementById('summaryWeather').textContent = weatherImpact || 'Not recorded';

        const notes = document.getElementById('dailyNotes').value.trim();
        document.getElementById('summaryNotes').textContent = notes || 'Not recorded';
    }

    function updateStatus() {
        const badge = document.getElementById('statusBadge');
        const hasData = state.activities.length > 0 || state.observations.length > 0 || 
                        state.photos.length > 0 || state.assessment || 
                        document.getElementById('dailyNotes').value.trim();

        if (state.recordSaved) {
            badge.textContent = 'Completed';
            badge.className = 'status-badge completed';
        } else if (hasData) {
            badge.textContent = 'In Progress';
            badge.className = 'status-badge in-progress';
        } else {
            badge.textContent = 'Not Started';
            badge.className = 'status-badge';
        }
    }

    // ============================================================
    // SAVE / EDIT
    // ============================================================

    window.saveDailyRecord = function() {
        const today = new Date().toISOString();
        const weatherImpact = document.getElementById('weatherImpact').value;
        const weatherDesc = document.getElementById('weatherImpactDescription')?.value || '';
        const notes = document.getElementById('dailyNotes').value.trim();

        const record = {
            id: currentRecord?.id || 'daily_' + Date.now(),
            date: today,
            activities: state.activities,
            observations: state.observations,
            assessment: state.assessment,
            weather: {
                impact: weatherImpact,
                description: weatherDesc
            },
            photos: state.photos,
            notes: notes,
            updatedAt: new Date().toISOString(),
            status: 'completed'
        };

        const records = getDailyRecords();
        const index = records.findIndex(r => r.id === record.id);

        if (index !== -1) {
            records[index] = record;
        } else {
            records.push(record);
        }

        saveDailyRecords(records);
        currentRecord = record;
        state.recordSaved = true;
        updateStatus();
        renderHistory();
        showToast('✅ Daily farm record saved successfully!');
        document.getElementById('saveDailyRecord').textContent = 'Update Daily Farm Record';
        document.getElementById('editDailyRecord').style.display = 'inline-flex';
    };

    window.editDailyRecord = function() {
        state.recordSaved = false;
        document.getElementById('editDailyRecord').style.display = 'none';
        document.getElementById('saveDailyRecord').textContent = 'Save Daily Farm Record';
        document.getElementById('statusBadge').textContent = 'In Progress';
        document.getElementById('statusBadge').className = 'status-badge in-progress';
        showToast('You can now edit today\'s record.');
    };

    // ============================================================
    // LOAD RECORD
    // ============================================================

    function loadRecord(record) {
        state.activities = record.activities || [];
        state.observations = record.observations || [];
        state.assessment = record.assessment || null;
        state.photos = record.photos || [];
        state.notes = record.notes || '';

        if (state.assessment) {
            document.querySelectorAll('.assessment-option').forEach(el => {
                el.classList.toggle('active', el.dataset.value === state.assessment);
            });
            document.getElementById('selectedAssessment').textContent = `Selected: ${state.assessment}`;
        }

        if (record.weather?.impact) {
            document.getElementById('weatherImpact').value = record.weather.impact;
            if (record.weather.impact === 'Yes' && record.weather.description) {
                document.getElementById('weatherImpactDetail').style.display = 'block';
                document.getElementById('weatherImpactDescription').value = record.weather.description;
            }
        }

        document.getElementById('dailyNotes').value = state.notes;

        renderActivities();
        renderObservations();
        renderPhotos();
        updateSummary();
        updateStatus();

        if (state.activities.length > 0 || state.observations.length > 0 || state.photos.length > 0) {
            document.getElementById('editDailyRecord').style.display = 'inline-flex';
        }
    }

    // ============================================================
    // HISTORY
    // ============================================================

    function renderHistory() {
        const container = document.getElementById('historyContainer');
        const records = getDailyRecords();

        if (records.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p>Your farm history will appear here as you record daily activities.</p>
                </div>
            `;
            return;
        }

        // Sort by date descending
        const sorted = [...records].sort((a, b) => new Date(b.date) - new Date(a.date));

        let html = '';
        sorted.forEach(record => {
            const date = new Date(record.date);
            const dateStr = date.toLocaleDateString('en-US', { 
                month: 'long', 
                day: 'numeric', 
                year: 'numeric' 
            });
            const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][date.getDay()];

            const activityCount = (record.activities || []).length;
            const obsCount = (record.observations || []).length;
            const photoCount = (record.photos || []).length;

            html += `
                <div class="timeline-item">
                    <div class="timeline-dot"></div>
                    <div class="timeline-date">${dayName} · ${dateStr}</div>
                    <div class="timeline-title">Daily Farm Record</div>
                    <div class="timeline-details">
                        ${activityCount > 0 ? `📋 ${activityCount} activity${activityCount > 1 ? 's' : ''}` : ''}
                        ${obsCount > 0 ? ` 👁️ ${obsCount} observation${obsCount > 1 ? 's' : ''}` : ''}
                        ${photoCount > 0 ? ` 📸 ${photoCount} photo${photoCount > 1 ? 's' : ''}` : ''}
                        ${record.assessment ? ` 📊 ${record.assessment}` : ''}
                    </div>
                    <div class="timeline-actions">
                        <button class="btn-secondary btn-sm" onclick="viewHistoryRecord('${record.id}')">
                            <i class="fas fa-eye"></i> View Record
                        </button>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    window.viewHistoryRecord = function(id) {
        const records = getDailyRecords();
        const record = records.find(r => r.id === id);
        if (!record) return;

        let details = `📅 ${new Date(record.date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            month: 'long', 
            day: 'numeric', 
            year: 'numeric' 
        })}\n\n`;

        if (record.activities?.length > 0) {
            details += '📋 ACTIVITIES:\n';
            record.activities.forEach(a => {
                details += `  • ${a.type}${a.crop ? ` (${a.crop})` : ''}\n`;
            });
            details += '\n';
        }

        if (record.observations?.length > 0) {
            details += '👁️ OBSERVATIONS:\n';
            record.observations.forEach(o => {
                details += `  • ${o.category}: ${o.description}\n`;
            });
            details += '\n';
        }

        if (record.assessment) {
            details += `📊 ASSESSMENT: ${record.assessment}\n\n`;
        }

        if (record.notes) {
            details += `📝 NOTES: ${record.notes}\n`;
        }

        alert(details);
    };

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast show ${type || ''}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // ============================================================
    // INIT
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // ============================================================
    // EXPOSE FUNCTIONS FOR ONCLICK
    // ============================================================
    
    window.selectActivity = selectActivity;
    window.addActivity = addActivity;
    window.removeActivity = removeActivity;
    window.addObservation = addObservation;
    window.removeObservation = removeObservation;
    window.selectAssessment = selectAssessment;
    window.saveDailyRecord = saveDailyRecord;
    window.editDailyRecord = editDailyRecord;
    window.viewHistoryRecord = viewHistoryRecord;
    window.removePhoto = removePhoto;
    window.updatePhotoCaption = updatePhotoCaption;

})();