(function() {
    "use strict";

    // ============================================================
    // DATA HELPERS
    // ============================================================

    function getFarmer() {
        let raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getCrops() {
        let raw = localStorage.getItem('agrinova_crops_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getDailyRecords() {
        let raw = localStorage.getItem('agrinova_daily_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getTasks() {
        let raw = localStorage.getItem('agrinova_tasks_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getCheckpoints(cropId) {
        let raw = localStorage.getItem('agrinova_checkpoints_' + cropId);
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getFarmRecords() {
        let raw = localStorage.getItem('agrinova_farm_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveFarmRecords(records) {
        localStorage.setItem('agrinova_farm_records', JSON.stringify(records));
    }

    function getFarmPhotos() {
        let raw = localStorage.getItem('agrinova_farm_photos');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveFarmPhotos(photos) {
        localStorage.setItem('agrinova_farm_photos', JSON.stringify(photos));
    }

    // ============================================================
    // STATE
    // ============================================================

    let state = {
        records: [],
        filteredRecords: [],
        selectedRecord: null,
        searchTerm: '',
        filterCategory: 'all',
        filterCrop: 'all',
        filterDate: 'all'
    };

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova Farm Records Initializing...');
        
        updateDate();
        updateGreeting();
        updateProfile();
        setupProfileImage();
        setupDropdown();
        setupSearch();
        fetchWeather();
        
        // Build records from all sources
        buildRecords();
        
        // Render everything
        renderTimeline();
        updateStats();
        populateCropDropdowns();
        renderMediaArchive();
        renderCropTimeline();
        
        // Setup search
        document.getElementById('globalSearch').addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                state.searchTerm = this.value.trim();
                applyFilters();
            }
        });

        console.log('AgriNova Farm Records Ready.');
    }

    // ============================================================
    // DATE & GREETING
    // ============================================================

    function updateDate() {
        const now = new Date();
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        
        document.getElementById('dateDay').textContent = days[now.getDay()];
        document.getElementById('dateFull').textContent = `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
    }

    function updateGreeting() {
        const farmer = getFarmer();
        const h1 = document.getElementById('greetingText');
        const hour = new Date().getHours();
        let greet = 'Good Morning';
        if (hour >= 12 && hour < 17) greet = 'Good Afternoon';
        else if (hour >= 17) greet = 'Good Evening';

        const name = farmer?.name || farmer?.firstName || 'Farmer';
        h1.textContent = `${greet}, ${name}`;
        document.getElementById('navName').textContent = name;
    }

    // ============================================================
    // PROFILE
    // ============================================================

    function updateProfile() {
        const farmer = getFarmer();
        if (!farmer) return;

        const name = farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('pdName').textContent = name;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || '—';
        
        const city = farmer.city || '—';
        const region = farmer.region || '—';
        document.getElementById('pdLocation').textContent = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdFarmland').textContent = farmer.hectares ? `${farmer.hectares} ha` : '—';
    }

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }
        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim().toLowerCase();
                    if (query) {
                        state.searchTerm = query;
                        applyFilters();
                        const count = state.filteredRecords.length;
                        showToast(`Found ${count} record${count > 1 ? 's' : ''} matching "${query}"`);
                    }
                }
            });
        }
    }

    // ============================================================
    // BUILD RECORDS FROM ALL SOURCES
    // ============================================================

    function buildRecords() {
        let records = [];

        // 1. Get existing farm records (for manual entries)
        const existingRecords = getFarmRecords();
        records.push(...existingRecords);

        // 2. From Crops (My Crops)
        const crops = getCrops();
        crops.forEach(crop => {
            // Crop added record
            records.push({
                id: 'crop_added_' + crop.id,
                type: 'crop',
                category: 'crop',
                title: `Crop Added: ${crop.name}`,
                description: `${crop.name} was added to the farm.`,
                date: crop.createdAt || crop.updatedAt || new Date().toISOString(),
                source: 'My Crops',
                sourcePage: 'my-crops.html',
                cropName: crop.name,
                cropId: crop.id,
                details: {
                    variety: crop.variety || 'Not specified',
                    area: crop.area || 'Not specified',
                    field: crop.field || 'Not specified',
                    plantingDate: crop.plantingDate || 'Not set'
                }
            });

            // Planting record
            if (crop.plantingDate) {
                records.push({
                    id: 'planting_' + crop.id,
                    type: 'planting',
                    category: 'planting',
                    title: `Planted: ${crop.name}`,
                    description: `${crop.name} was planted on ${new Date(crop.plantingDate).toLocaleDateString()}.`,
                    date: crop.plantingDate,
                    source: 'My Crops',
                    sourcePage: 'my-crops.html',
                    cropName: crop.name,
                    cropId: crop.id,
                    details: {
                        plantingDate: crop.plantingDate,
                        area: crop.area || 'Not specified',
                        field: crop.field || 'Not specified'
                    }
                });
            }

            // Checkpoints (growth stage updates)
            const checkpoints = getCheckpoints(crop.id);
            checkpoints.forEach(cp => {
                if (cp.status === 'completed') {
                    records.push({
                        id: 'checkpoint_' + cp.id,
                        type: 'crop',
                        category: 'crop',
                        title: `Growth Stage: ${cp.stageName}`,
                        description: `${crop.name} reached ${cp.stageName} stage. Day ${cp.daySincePlanting}`,
                        date: cp.completedAt || cp.createdAt,
                        source: 'My Crops',
                        sourcePage: 'my-crops.html',
                        cropName: crop.name,
                        cropId: crop.id,
                        details: {
                            stage: cp.stageName,
                            daySincePlanting: cp.daySincePlanting,
                            observations: cp.observations || 'No observations',
                            hasPhoto: !!cp.photo
                        },
                        photo: cp.photo || null
                    });
                }
            });
        });

        // 3. From Daily Farm
        const dailyRecords = getDailyRecords();
        dailyRecords.forEach(record => {
            const activities = record.activities || [];
            activities.forEach(act => {
                records.push({
                    id: 'daily_act_' + act.id,
                    type: 'daily_activity',
                    category: 'daily_activity',
                    title: `Activity: ${act.type}`,
                    description: act.notes || `${act.type} activity recorded.`,
                    date: record.date,
                    source: 'Daily Farm',
                    sourcePage: 'daily-farm.html',
                    cropName: act.crop || null,
                    details: {
                        type: act.type,
                        crop: act.crop || 'Not specified',
                        notes: act.notes || 'No notes'
                    }
                });
            });

            // Observations from Daily Farm
            const observations = record.observations || [];
            observations.forEach(obs => {
                records.push({
                    id: 'daily_obs_' + obs.id,
                    type: 'daily_activity',
                    category: 'daily_activity',
                    title: `Observation: ${obs.category}`,
                    description: obs.description || 'Observation recorded.',
                    date: record.date,
                    source: 'Daily Farm',
                    sourcePage: 'daily-farm.html',
                    cropName: obs.crop || null,
                    details: {
                        category: obs.category,
                        priority: obs.priority,
                        description: obs.description,
                        crop: obs.crop || 'Not specified'
                    }
                });
            });
        });

        // 4. From Tasks (Completed tasks)
        const tasks = getTasks();
        tasks.forEach(task => {
            if (task.status === 'completed') {
                records.push({
                    id: 'task_completed_' + task.id,
                    type: 'task',
                    category: 'task',
                    title: `Task Completed: ${task.title}`,
                    description: `${task.title} was completed.`,
                    date: task.completedAt || task.updatedAt,
                    source: 'Farm Tasks',
                    sourcePage: 'farm-tasks-calendar.html',
                    cropName: task.crop || null,
                    details: {
                        category: task.category,
                        priority: task.priority,
                        dueDate: task.dueDate,
                        notes: task.notes || 'No notes'
                    }
                });
            }
        });

        // Sort by date (newest first)
        records.sort((a, b) => new Date(b.date) - new Date(a.date));

        state.records = records;
        state.filteredRecords = records;
    }

    // ============================================================
    // TIMELINE
    // ============================================================

    function renderTimeline() {
        const container = document.getElementById('timelineContainer');
        const records = state.filteredRecords;

        if (records.length === 0) {
            container.innerHTML = `
                <div class="empty-state" style="padding:2rem;">
                    <i class="fas fa-history"></i>
                    <p>No records found matching your filters.</p>
                </div>
            `;
            document.getElementById('recordCount').textContent = '0 records';
            return;
        }

        document.getElementById('recordCount').textContent = `${records.length} records`;

        let html = '<div class="timeline-container">';
        let currentDate = '';

        records.forEach(record => {
            const recordDate = new Date(record.date);
            const dateStr = recordDate.toDateString();
            const displayDate = recordDate.toLocaleDateString('en-US', { 
                weekday: 'long', 
                month: 'long', 
                day: 'numeric', 
                year: 'numeric' 
            });

            if (dateStr !== currentDate) {
                if (currentDate !== '') {
                    html += '</div>';
                }
                currentDate = dateStr;
                html += `
                    <div style="margin-top:1.5rem; margin-bottom:0.5rem; font-weight:600; color:#12352A; font-family:'Playfair Display',serif;">
                        ${displayDate}
                    </div>
                `;
            }

            const dotClass = record.type === 'photo' ? 'photo' : 
                           record.type === 'task' ? 'task' : 
                           record.type === 'crop' ? 'crop' : 
                           record.type === 'daily_activity' ? 'activity' : 
                           'document';

            const iconMap = {
                'crop': '🌱',
                'planting': '🌿',
                'daily_activity': '📋',
                'task': '✅',
                'photo': '📸',
                'document': '📄'
            };

            html += `
                <div class="timeline-item" onclick="showRecordDetail('${record.id}')">
                    <div class="timeline-dot ${dotClass}"></div>
                    <div class="timeline-date">${iconMap[record.type] || '📌'} ${new Date(record.date).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</div>
                    <div class="timeline-title">${record.title}</div>
                    <div class="timeline-sub">${record.description}</div>
                    ${record.cropName ? `<div class="timeline-sub" style="color:#3F7355;">🌾 ${record.cropName}</div>` : ''}
                    <div class="timeline-source">${record.source}</div>
                </div>
            `;
        });

        html += '</div>';
        container.innerHTML = html;
    }

    // ============================================================
    // STATS
    // ============================================================

    function updateStats() {
        const records = state.records;

        const total = records.length;
        const activities = records.filter(r => r.type === 'daily_activity').length;
        const cropRecords = records.filter(r => r.type === 'crop' || r.type === 'planting').length;
        const photos = records.filter(r => r.type === 'photo').length;
        const documents = records.filter(r => r.type === 'document').length;

        document.getElementById('statTotal').textContent = total;
        document.getElementById('statActivities').textContent = activities;
        document.getElementById('statCropRecords').textContent = cropRecords;
        document.getElementById('statPhotos').textContent = photos;
        document.getElementById('statDocuments').textContent = documents;
    }

    // ============================================================
    // FILTERS
    // ============================================================

    window.applyFilters = function() {
        const searchTerm = document.getElementById('recordSearch').value.toLowerCase().trim();
        const category = document.getElementById('filterCategory').value;
        const cropFilter = document.getElementById('filterCrop').value;
        const dateFilter = document.getElementById('filterDate').value;

        let filtered = state.records;

        // Search
        if (searchTerm) {
            filtered = filtered.filter(r => 
                r.title.toLowerCase().includes(searchTerm) ||
                r.description.toLowerCase().includes(searchTerm) ||
                (r.cropName && r.cropName.toLowerCase().includes(searchTerm)) ||
                (r.details && JSON.stringify(r.details).toLowerCase().includes(searchTerm))
            );
        }

        // Category
        if (category !== 'all') {
            filtered = filtered.filter(r => r.category === category || r.type === category);
        }

        // Crop
        if (cropFilter !== 'all') {
            filtered = filtered.filter(r => r.cropName === cropFilter);
        }

        // Date
        if (dateFilter !== 'all') {
            const now = new Date();
            const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            
            filtered = filtered.filter(r => {
                const recordDate = new Date(r.date);
                if (dateFilter === 'today') {
                    return recordDate >= today;
                } else if (dateFilter === 'week') {
                    const weekAgo = new Date(today);
                    weekAgo.setDate(weekAgo.getDate() - 7);
                    return recordDate >= weekAgo;
                } else if (dateFilter === 'month') {
                    const monthAgo = new Date(today);
                    monthAgo.setMonth(monthAgo.getMonth() - 1);
                    return recordDate >= monthAgo;
                } else if (dateFilter === 'year') {
                    const yearAgo = new Date(today);
                    yearAgo.setFullYear(yearAgo.getFullYear() - 1);
                    return recordDate >= yearAgo;
                }
                return true;
            });
        }

        state.filteredRecords = filtered;
        renderTimeline();
        document.getElementById('recordCount').textContent = `${filtered.length} records`;
    };

    // ============================================================
    // POPULATE DROPDOWNS
    // ============================================================

    function populateCropDropdowns() {
        const crops = getCrops();
        const select = document.getElementById('filterCrop');
        const timelineSelect = document.getElementById('cropTimelineSelect');

        [select, timelineSelect].forEach(el => {
            el.innerHTML = '<option value="all">All Crops</option>';
            crops.forEach(crop => {
                el.innerHTML += `<option value="${crop.name}">${crop.name}</option>`;
            });
            if (crops.length === 0) {
                el.innerHTML += '<option value="" disabled>No crops added yet</option>';
            }
        });
    }

    // ============================================================
    // RECORD DETAILS
    // ============================================================

    window.showRecordDetail = function(recordId) {
        const record = state.records.find(r => r.id === recordId);
        if (!record) return;

        document.getElementById('recordDetailTitle').textContent = record.title;

        const details = record.details || {};
        let detailsHtml = '';

        for (const [key, value] of Object.entries(details)) {
            const label = key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' ');
            detailsHtml += `
                <div class="record-detail-item">
                    <span class="label">${label}</span>
                    <span class="value">${value || 'Not provided'}</span>
                </div>
            `;
        }

        const html = `
            <div style="display:grid; gap:0.8rem;">
                <div class="record-detail-item">
                    <span class="label">Date</span>
                    <span class="value">${new Date(record.date).toLocaleString()}</span>
                </div>
                <div class="record-detail-item">
                    <span class="label">Category</span>
                    <span class="value">${record.category || record.type}</span>
                </div>
                ${record.cropName ? `
                <div class="record-detail-item">
                    <span class="label">Crop</span>
                    <span class="value">${record.cropName}</span>
                </div>` : ''}
                <div class="record-detail-item">
                    <span class="label">Source</span>
                    <span class="value">${record.source}</span>
                </div>
                ${record.description ? `
                <div class="record-detail-item">
                    <span class="label">Description</span>
                    <span class="value" style="text-align:left; max-width:60%;">${record.description}</span>
                </div>` : ''}
                ${detailsHtml}
                ${record.photo ? `
                <div style="margin-top:0.5rem;">
                    <img src="${record.photo}" alt="Record photo" style="max-width:100%; max-height:300px; border-radius:8px;">
                </div>` : ''}
            </div>
            <div style="display:flex; gap:0.8rem; margin-top:1.5rem; padding-top:1rem; border-top:1px solid #E1E7DF;">
                ${record.sourcePage ? `<a href="${record.sourcePage}" class="btn-secondary btn-sm"><i class="fas fa-external-link-alt"></i> View in ${record.source}</a>` : ''}
            </div>
        `;

        document.getElementById('recordDetailContent').innerHTML = html;
        openModal('recordDetailModal');

        // Also update the details panel
        const panel = document.getElementById('recordDetailsContainer');
        panel.innerHTML = html;
        state.selectedRecord = record;
    };

    // ============================================================
    // CROP GROWTH TIMELINE
    // ============================================================

    window.renderCropTimeline = function() {
        const container = document.getElementById('cropTimelineContainer');
        const cropName = document.getElementById('cropTimelineSelect').value;

        if (!cropName || cropName === 'all') {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-seedling"></i>
                    <p>Select a crop to view its growth journey.</p>
                </div>
            `;
            return;
        }

        const crops = getCrops();
        const crop = crops.find(c => c.name === cropName);
        if (!crop) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-seedling"></i>
                    <p>Crop not found.</p>
                </div>
            `;
            return;
        }

        // Get records for this crop
        const cropRecords = state.records.filter(r => r.cropName === cropName);
        const growthRecords = cropRecords.filter(r => r.type === 'crop' || r.type === 'planting');
        const photoRecords = cropRecords.filter(r => r.photo);

        if (growthRecords.length === 0 && photoRecords.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-camera"></i>
                    <p>No growth records or photos for ${cropName}.</p>
                </div>
            `;
            return;
        }

        let html = '<div class="crop-timeline">';

        // Show planting first
        const planting = growthRecords.find(r => r.type === 'planting');
        if (planting) {
            html += `
                <div class="crop-timeline-stage">
                    <div style="font-size:2rem; margin-bottom:0.3rem;">🌱</div>
                    <div class="stage-name">Planted</div>
                    <div class="stage-date">${new Date(planting.date).toLocaleDateString()}</div>
                    ${planting.details?.area ? `<div class="stage-days">Area: ${planting.details.area}</div>` : ''}
                </div>
            `;
        }

        // Show growth stages with photos
        const stages = growthRecords.filter(r => r.type === 'crop');
        stages.forEach((stage, index) => {
            const hasPhoto = photoRecords.find(p => p.details?.stage === stage.details?.stage);
            const photoData = hasPhoto || stage;

            html += `
                <div class="crop-timeline-stage">
                    ${index < stages.length - 1 ? `<div class="stage-arrow"><i class="fas fa-chevron-right"></i></div>` : ''}
                    ${photoData.photo ? `<img src="${photoData.photo}" alt="${stage.title}" onerror="this.style.display='none'">` : `<div style="height:150px; background:#E8F0E5; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#6F786F; font-size:0.8rem;">No photo</div>`}
                    <div class="stage-name">${stage.details?.stage || stage.title}</div>
                    <div class="stage-date">${new Date(stage.date).toLocaleDateString()}</div>
                    ${stage.details?.daySincePlanting ? `<div class="stage-days">Day ${stage.details.daySincePlanting}</div>` : ''}
                </div>
            `;
        });

        html += '</div>';
        container.innerHTML = html;
    };

    // ============================================================
    // MEDIA ARCHIVE
    // ============================================================

    function renderMediaArchive() {
        const container = document.getElementById('mediaArchiveContainer');
        const photos = state.records.filter(r => r.photo);

        if (photos.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-camera"></i>
                    <p>No farm photos have been recorded yet.</p>
                </div>
            `;
            document.getElementById('mediaCount').textContent = '0 photos';
            return;
        }

        document.getElementById('mediaCount').textContent = `${photos.length} photos`;

        let html = '<div class="media-grid">';
        photos.forEach(photo => {
            html += `
                <div class="media-item" onclick="viewPhoto('${photo.id}')">
                    <img src="${photo.photo}" alt="Farm photo" onerror="this.style.display='none'">
                    <div class="media-info">
                        <div class="media-crop">${photo.cropName || 'General'}</div>
                        <div class="media-date">${new Date(photo.date).toLocaleDateString()}</div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;
    }

    // ============================================================
    // PHOTO VIEWER
    // ============================================================

    window.viewPhoto = function(recordId) {
        const record = state.records.find(r => r.id === recordId);
        if (!record || !record.photo) return;

        document.getElementById('photoViewerTitle').textContent = record.cropName || 'Farm Photo';

        const html = `
            <div style="text-align:center;">
                <img src="${record.photo}" alt="Farm photo" style="max-width:100%; max-height:70vh; border-radius:8px;">
                <div style="margin-top:1rem; color:#6F786F;">
                    ${record.cropName ? `<div>🌾 ${record.cropName}</div>` : ''}
                    ${record.details?.stage ? `<div>Stage: ${record.details.stage}</div>` : ''}
                    <div>${new Date(record.date).toLocaleString()}</div>
                    ${record.description ? `<div style="margin-top:0.5rem;">${record.description}</div>` : ''}
                </div>
            </div>
        `;

        document.getElementById('photoViewerContent').innerHTML = html;
        openModal('photoViewerModal');
    };

    // ============================================================
    // EXPORT RECORDS
    // ============================================================

    window.exportRecords = function(type) {
        const records = state.filteredRecords;
        
        if (records.length === 0) {
            showToast('No records to export.', 'warning');
            return;
        }

        // Create CSV content
        let csv = 'Date,Title,Category,Crop,Source,Description\n';
        records.forEach(r => {
            const date = new Date(r.date).toLocaleDateString();
            const crop = r.cropName || '';
            const desc = r.description.replace(/,/g, ';');
            csv += `${date},"${r.title}",${r.category || r.type},${crop},${r.source},"${desc}"\n`;
        });

        if (type === 'share') {
            // Share via Web Share API if available
            if (navigator.share) {
                navigator.share({
                    title: 'AgriNova Farm Records',
                    text: `I have ${records.length} farm records. Here's my farm history:\n\n${csv}`,
                }).catch(() => {});
            } else {
                // Fallback: copy to clipboard
                navigator.clipboard.writeText(csv).then(() => {
                    showToast('Records copied to clipboard!');
                }).catch(() => {
                    // Download as fallback
                    downloadCSV(csv);
                });
            }
        } else {
            downloadCSV(csv);
        }
    };

    function downloadCSV(csv) {
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `agrinova_records_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
        showToast('Records exported successfully!');
    }

    // ============================================================
    // WEATHER
    // ============================================================

    async function fetchWeather() {
        try {
            const farmer = getFarmer();
            const city = farmer?.city || 'Addis Ababa';
            
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        await getWeatherData(latitude, longitude);
                    },
                    async () => {
                        await getWeatherByCity(city);
                    }
                );
            } else {
                await getWeatherByCity(city);
            }
        } catch (e) {
            console.warn('Weather error:', e);
            document.getElementById('navTemp').textContent = '--°C';
        }
    }

    async function getWeatherData(lat, lon) {
        try {
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`;
            const resp = await fetch(url);
            if (!resp.ok) throw new Error('Weather API error');
            const data = await resp.json();
            if (data.current_weather) {
                const temp = data.current_weather.temperature !== undefined ? `${Math.round(data.current_weather.temperature)}°C` : '--°C';
                document.getElementById('navTemp').textContent = temp;
            }
        } catch (e) {
            console.warn('Weather fetch error:', e);
        }
    }

    async function getWeatherByCity(city) {
        try {
            const geoResp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
            const geoData = await geoResp.json();
            if (geoData && geoData.length > 0) {
                const { lat, lon } = geoData[0];
                await getWeatherData(parseFloat(lat), parseFloat(lon));
            }
        } catch (e) {
            console.warn('City geocode error:', e);
        }
    }

    // ============================================================
    // MODAL HELPERS
    // ============================================================

    window.openModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    };

    window.closeModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    };

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
                document.body.style.overflow = 'auto';
            }
        });
    });

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast show ${type || ''}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // ============================================================
    // EXPOSE FUNCTIONS FOR ONCLICK
    // ============================================================
    
    window.showRecordDetail = showRecordDetail;
    window.viewPhoto = viewPhoto;
    window.exportRecords = exportRecords;
    window.applyFilters = applyFilters;
    window.renderCropTimeline = renderCropTimeline;
    window.closeModal = closeModal;

    // ============================================================
    // INIT
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();