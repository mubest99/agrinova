(function() {
    "use strict";

    // ============================================================
    // COMPLETE 70 CROPS GROWTH DATA
    // ============================================================
    
    const CROP_GROWTH_DATA = {
        // Cereals & Grains
        'maize': { totalDays: 120, stages: [
            { name: 'Germination', startDay: 0, endDay: 7 },
            { name: 'Seedling', startDay: 8, endDay: 21 },
            { name: 'Vegetative', startDay: 22, endDay: 50 },
            { name: 'Flowering', startDay: 51, endDay: 70 },
            { name: 'Grain Fill', startDay: 71, endDay: 100 },
            { name: 'Maturity', startDay: 101, endDay: 120 }
        ]},
        'teff': { totalDays: 80, stages: [
            { name: 'Germination', startDay: 0, endDay: 6 },
            { name: 'Seedling', startDay: 7, endDay: 25 },
            { name: 'Tillering', startDay: 26, endDay: 45 },
            { name: 'Stem Elongation', startDay: 46, endDay: 60 },
            { name: 'Heading/Flowering', startDay: 61, endDay: 70 },
            { name: 'Grain Fill/Maturity', startDay: 71, endDay: 80 }
        ]},
        'wheat (bread)': { totalDays: 120, stages: [
            { name: 'Germination', startDay: 0, endDay: 5 },
            { name: 'Seedling', startDay: 6, endDay: 20 },
            { name: 'Tillering', startDay: 21, endDay: 45 },
            { name: 'Stem Elongation', startDay: 46, endDay: 65 },
            { name: 'Heading/Flowering', startDay: 66, endDay: 80 },
            { name: 'Grain Fill', startDay: 81, endDay: 100 },
            { name: 'Maturity', startDay: 101, endDay: 120 }
        ]},
        'durum wheat': { totalDays: 110, stages: [
            { name: 'Germination', startDay: 0, endDay: 5 },
            { name: 'Seedling', startDay: 6, endDay: 18 },
            { name: 'Tillering', startDay: 19, endDay: 40 },
            { name: 'Stem Elongation', startDay: 41, endDay: 60 },
            { name: 'Heading', startDay: 61, endDay: 75 },
            { name: 'Grain Fill', startDay: 76, endDay: 95 },
            { name: 'Maturity', startDay: 96, endDay: 110 }
        ]},
        'barley (food)': { totalDays: 100, stages: [
            { name: 'Germination', startDay: 0, endDay: 5 },
            { name: 'Seedling', startDay: 6, endDay: 15 },
            { name: 'Tillering', startDay: 16, endDay: 35 },
            { name: 'Stem Elongation', startDay: 36, endDay: 55 },
            { name: 'Heading', startDay: 56, endDay: 70 },
            { name: 'Grain Fill', startDay: 71, endDay: 85 },
            { name: 'Maturity', startDay: 86, endDay: 100 }
        ]},
        'barley (malt)': { totalDays: 110, stages: [
            { name: 'Germination', startDay: 0, endDay: 5 },
            { name: 'Seedling', startDay: 6, endDay: 15 },
            { name: 'Tillering', startDay: 16, endDay: 40 },
            { name: 'Stem Elongation', startDay: 41, endDay: 60 },
            { name: 'Heading', startDay: 61, endDay: 75 },
            { name: 'Grain Fill', startDay: 76, endDay: 95 },
            { name: 'Maturity', startDay: 96, endDay: 110 }
        ]},
        'sorghum': { totalDays: 130, stages: [
            { name: 'Germination', startDay: 0, endDay: 7 },
            { name: 'Seedling', startDay: 8, endDay: 20 },
            { name: 'Vegetative', startDay: 21, endDay: 50 },
            { name: 'Growing Point Diff', startDay: 51, endDay: 65 },
            { name: 'Flag Leaf/Boot', startDay: 66, endDay: 75 },
            { name: 'Heading/Flowering', startDay: 76, endDay: 90 },
            { name: 'Grain Fill', startDay: 91, endDay: 115 },
            { name: 'Maturity', startDay: 116, endDay: 130 }
        ]},
        'potato': { totalDays: 110, stages: [
            { name: 'Germination/Emergence', startDay: 0, endDay: 20 },
            { name: 'Vegetative Growth', startDay: 21, endDay: 45 },
            { name: 'Tuber Initiation', startDay: 46, endDay: 60 },
            { name: 'Tuber Bulking', startDay: 61, endDay: 90 },
            { name: 'Maturation/Skin Set', startDay: 91, endDay: 110 }
        ]},
        'coffee (arabica)': { totalDays: 240, stages: [
            { name: 'Flowering', startDay: 0, endDay: 14 },
            { name: 'Pinhead Stage', startDay: 15, endDay: 45 },
            { name: 'Fast Growth', startDay: 46, endDay: 105 },
            { name: 'Slow Growth', startDay: 106, endDay: 165 },
            { name: 'Maturation (Green to Red)', startDay: 166, endDay: 225 },
            { name: 'Harvest (Ripe Cherry)', startDay: 226, endDay: 240 }
        ]},
        'rice (upland)': { totalDays: 120, stages: [
            { name: 'Germination', startDay: 0, endDay: 7 },
            { name: 'Seedling', startDay: 8, endDay: 20 },
            { name: 'Tillering', startDay: 21, endDay: 50 },
            { name: 'Panicle Initiation', startDay: 51, endDay: 65 },
            { name: 'Heading', startDay: 66, endDay: 80 },
            { name: 'Flowering', startDay: 81, endDay: 90 },
            { name: 'Grain Fill', startDay: 91, endDay: 105 },
            { name: 'Maturity', startDay: 106, endDay: 120 }
        ]}
    };

    // ============================================================
    // STAGE-SPECIFIC QUESTIONS
    // ============================================================
    
    const STAGE_QUESTIONS = {
        'planting': [
            { id: 'q1', text: 'Has planting/sowing been completed?', type: 'select', options: ['Yes', 'No', 'Partially'] },
            { id: 'q2', text: 'Was the planned planting area fully planted?', type: 'select', options: ['Yes', 'No', 'Partially'] },
            { id: 'q3', text: 'Do you have any observations about planting?', type: 'text' }
        ],
        'germination': [
            { id: 'q1', text: 'Have you observed crop emergence or germination?', type: 'select', options: ['Yes', 'No', 'Partially', 'Not sure'] },
            { id: 'q2', text: 'How would you describe emergence across the planted area?', type: 'select', options: ['Even', 'Uneven', 'Limited', 'Not sure'] },
            { id: 'q3', text: 'Has watering or irrigation occurred during this period?', type: 'select', options: ['Yes', 'No', 'Not applicable'] },
            { id: 'q4', text: 'Have you noticed any unusual issues?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q5', text: 'Additional observations', type: 'text' }
        ],
        'seedling': [
            { id: 'q1', text: 'Are plants continuing to develop?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q2', text: 'Has watering or irrigation occurred?', type: 'select', options: ['Yes', 'No', 'Not applicable'] },
            { id: 'q3', text: 'Have weeds been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q4', text: 'Have insects or pests been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q5', text: 'Have unusual plant symptoms been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q6', text: 'Additional observations', type: 'text' }
        ],
        'vegetative': [
            { id: 'q1', text: 'Does the crop appear to be actively developing?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q2', text: 'Has irrigation or watering been performed during this period?', type: 'select', options: ['Yes', 'No', 'Not applicable'] },
            { id: 'q3', text: 'Has fertilizer been applied?', type: 'select', options: ['Yes', 'No'] },
            { id: 'q4', text: 'Have weeds been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q5', text: 'Has weed management been performed?', type: 'select', options: ['Yes', 'No', 'Not applicable'] },
            { id: 'q6', text: 'Have pests been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q7', text: 'Have unusual symptoms been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q8', text: 'Additional observations', type: 'text' }
        ],
        'flowering': [
            { id: 'q1', text: 'Have you observed reproductive development?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q2', text: 'Has watering or irrigation occurred?', type: 'select', options: ['Yes', 'No', 'Not applicable'] },
            { id: 'q3', text: 'Have unusual changes been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q4', text: 'Have pests been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q5', text: 'Have possible disease symptoms been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q6', text: 'Additional observations', type: 'text' }
        ],
        'fruit_development': [
            { id: 'q1', text: 'Have you observed the expected crop development?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q2', text: 'Has watering or irrigation occurred during this period?', type: 'select', options: ['Yes', 'No', 'Not applicable'] },
            { id: 'q3', text: 'Have pests been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q4', text: 'Have unusual symptoms been observed?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q5', text: 'Have you noticed physical crop damage?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q6', text: 'Additional observations', type: 'text' }
        ],
        'maturity': [
            { id: 'q1', text: 'Have you observed signs of crop maturity?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q2', text: 'Is the crop being prepared for harvest?', type: 'select', options: ['Yes', 'No', 'Not yet'] },
            { id: 'q3', text: 'Have you noticed issues that may affect harvesting?', type: 'select', options: ['Yes', 'No', 'Not sure'] },
            { id: 'q4', text: 'Do you have an estimated harvest date based on your observation?', type: 'date' },
            { id: 'q5', text: 'Additional observations', type: 'text' }
        ],
        'harvest': [
            { id: 'q1', text: 'Has harvesting started?', type: 'select', options: ['Yes', 'No'] },
            { id: 'q2', text: 'Has harvesting been completed?', type: 'select', options: ['Yes', 'Partially', 'No'] },
            { id: 'q3', text: 'Actual harvest date', type: 'date' },
            { id: 'q4', text: 'Harvest quantity (in kg or quintals)', type: 'number' },
            { id: 'q5', text: 'Were there any harvest issues?', type: 'text' },
            { id: 'q6', text: 'Additional notes', type: 'text' }
        ]
    };

    // ============================================================
    // CROP IMAGES
    // ============================================================
    
    const CROP_IMAGES = {
        'maize': 'https://images.unsplash.com/photo-1551754655-cd27a38e3f9f?w=600&h=400&fit=crop',
        'teff': 'https://images.unsplash.com/photo-1574943320219-553eb3b3c97b?w=600&h=400&fit=crop',
        'wheat (bread)': 'https://images.unsplash.com/photo-1574323347407-f5e1d273aa42?w=600&h=400&fit=crop',
        'barley (food)': 'https://images.unsplash.com/photo-1574323347407-f5e1d273aa42?w=600&h=400&fit=crop',
        'sorghum': 'https://images.unsplash.com/photo-1528458909330-3fc76dfda077?w=600&h=400&fit=crop',
        'potato': 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600&h=400&fit=crop',
        'coffee (arabica)': 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&h=400&fit=crop',
        'rice (upland)': 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=600&h=400&fit=crop',
        'default': 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop'
    };

    // ============================================================
    // DATA HELPERS
    // ============================================================

    function getFarmer() {
        let raw = localStorage.getItem('agrinova_user');
        if (!raw) raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    function getFarmData() {
        let raw = localStorage.getItem('agrinova_farm_data');
        if (!raw) return {};
        try { return JSON.parse(raw); } catch { return {}; }
    }

    function getCrops() {
        let raw = localStorage.getItem('agrinova_crops_data');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveCrops(crops) {
        localStorage.setItem('agrinova_crops_data', JSON.stringify(crops));
    }

    function getLandSections() {
        const farmData = getFarmData();
        return farmData.landSections || [];
    }

    function getCheckpoints(cropId) {
        let raw = localStorage.getItem('agrinova_checkpoints_' + cropId);
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function saveCheckpoints(cropId, checkpoints) {
        localStorage.setItem('agrinova_checkpoints_' + cropId, JSON.stringify(checkpoints));
    }

    // ============================================================
    // CROP CALCULATIONS
    // ============================================================

    function getCropGrowthData(cropName) {
        const key = cropName.toLowerCase().trim();
        return CROP_GROWTH_DATA[key] || null;
    }

    function getCropImage(cropName) {
        const key = cropName.toLowerCase().trim();
        return CROP_IMAGES[key] || CROP_IMAGES.default;
    }

    function getAllCropNames() {
        return Object.keys(CROP_GROWTH_DATA).sort();
    }

    function getDaysSincePlanting(plantingDate) {
        if (!plantingDate) return 0;
        const planted = new Date(plantingDate);
        const now = new Date();
        const diffTime = Math.abs(now - planted);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    function getCurrentStage(cropName, plantingDate) {
        const growthData = getCropGrowthData(cropName);
        if (!growthData) return null;
        const daysSince = getDaysSincePlanting(plantingDate);
        const stages = growthData.stages;

        for (let i = 0; i < stages.length; i++) {
            if (daysSince >= stages[i].startDay && daysSince <= stages[i].endDay) {
                return stages[i].name;
            }
        }
        if (daysSince > growthData.totalDays) {
            return 'Harvest Ready';
        }
        return 'Unknown';
    }

    function getStageIndex(cropName, plantingDate) {
        const growthData = getCropGrowthData(cropName);
        if (!growthData) return -1;
        const daysSince = getDaysSincePlanting(plantingDate);
        const stages = growthData.stages;

        for (let i = 0; i < stages.length; i++) {
            if (daysSince >= stages[i].startDay && daysSince <= stages[i].endDay) {
                return i;
            }
        }
        if (daysSince > growthData.totalDays) {
            return stages.length;
        }
        return -1;
    }

    function getDaysToHarvest(cropName, plantingDate) {
        const growthData = getCropGrowthData(cropName);
        if (!growthData) return null;
        const daysSince = getDaysSincePlanting(plantingDate);
        return growthData.totalDays - daysSince;
    }

    function getHarvestStatus(cropName, plantingDate) {
        const daysLeft = getDaysToHarvest(cropName, plantingDate);
        if (daysLeft === null) return 'unknown';
        if (daysLeft <= 0) return 'overdue';
        if (daysLeft <= 14) return 'harvest_ready';
        if (daysLeft <= 30) return 'near_harvest';
        return 'growing';
    }

    function getFormattedHarvestInfo(cropName, plantingDate) {
        const daysLeft = getDaysToHarvest(cropName, plantingDate);
        if (daysLeft === null) return { label: 'Data unavailable', status: 'unknown' };
        if (daysLeft <= 0) {
            return { label: '🌾 Harvest Overdue', status: 'overdue' };
        } else if (daysLeft <= 14) {
            return { label: `🌾 Ready to Harvest (${daysLeft} days)`, status: 'harvest_ready' };
        } else {
            return { label: `${daysLeft} days to harvest`, status: 'growing' };
        }
    }

    function getQuestionsForStage(stageName) {
        const stageKey = stageName.toLowerCase().trim();
        if (stageKey.includes('plant') || stageKey.includes('sow')) {
            return STAGE_QUESTIONS.planting;
        } else if (stageKey.includes('germ') || stageKey.includes('emergence')) {
            return STAGE_QUESTIONS.germination;
        } else if (stageKey.includes('seedling')) {
            return STAGE_QUESTIONS.seedling;
        } else if (stageKey.includes('vegetative') || stageKey.includes('growing')) {
            return STAGE_QUESTIONS.vegetative;
        } else if (stageKey.includes('flower') || stageKey.includes('reproductive')) {
            return STAGE_QUESTIONS.flowering;
        } else if (stageKey.includes('fruit') || stageKey.includes('grain') || stageKey.includes('pod') || stageKey.includes('fill')) {
            return STAGE_QUESTIONS.fruit_development;
        } else if (stageKey.includes('maturity') || stageKey.includes('mature')) {
            return STAGE_QUESTIONS.maturity;
        } else if (stageKey.includes('harvest')) {
            return STAGE_QUESTIONS.harvest;
        }
        return STAGE_QUESTIONS.vegetative;
    }

    // ============================================================
    // CHECKPOINT SYSTEM
    // ============================================================

    function checkAndCreateCheckpoints(crop) {
        const cropId = crop.id;
        const cropName = crop.name;
        const plantingDate = crop.plantingDate;
        const growthData = getCropGrowthData(cropName);
        if (!growthData) return;

        const checkpoints = getCheckpoints(cropId);
        const currentStageIndex = getStageIndex(cropName, plantingDate);
        if (currentStageIndex < 0) return;

        const stages = growthData.stages;

        // Check if we need to create a new checkpoint for the current stage
        const currentStageName = stages[currentStageIndex]?.name;
        if (!currentStageName) return;

        // Check if this stage already has a checkpoint
        const existingCheckpoint = checkpoints.find(c => c.stageName === currentStageName);
        if (!existingCheckpoint) {
            // Create new checkpoint
            const newCheckpoint = {
                id: 'checkpoint_' + Date.now(),
                stageName: currentStageName,
                stageIndex: currentStageIndex,
                daySincePlanting: getDaysSincePlanting(plantingDate),
                status: 'available',
                createdAt: new Date().toISOString(),
                completedAt: null,
                photo: null,
                answers: {},
                observations: ''
            };
            checkpoints.push(newCheckpoint);
            saveCheckpoints(cropId, checkpoints);
            showToast(`📌 New checkpoint available: ${currentStageName}`);
            updateNotificationBadge();
        }
    }

    function completeCheckpoint(cropId, checkpointId, data) {
        const checkpoints = getCheckpoints(cropId);
        const index = checkpoints.findIndex(c => c.id === checkpointId);
        if (index === -1) return;

        checkpoints[index].status = 'completed';
        checkpoints[index].completedAt = new Date().toISOString();
        checkpoints[index].photo = data.photo || null;
        checkpoints[index].answers = data.answers || {};
        checkpoints[index].observations = data.observations || '';

        saveCheckpoints(cropId, checkpoints);
        showToast('✅ Checkpoint completed successfully!');
        updateNotificationBadge();
    }

    function getAvailableCheckpoint(cropId) {
        const checkpoints = getCheckpoints(cropId);
        return checkpoints.find(c => c.status === 'available') || null;
    }

    function getCompletedCheckpoints(cropId) {
        const checkpoints = getCheckpoints(cropId);
        return checkpoints.filter(c => c.status === 'completed');
    }

    function updateNotificationBadge() {
        const crops = getCrops();
        let totalAvailable = 0;
        crops.forEach(crop => {
            const checkpoints = getCheckpoints(crop.id);
            const available = checkpoints.filter(c => c.status === 'available').length;
            totalAvailable += available;
        });

        const badge = document.getElementById('notifBadge');
        if (badge) {
            if (totalAvailable > 0) {
                badge.textContent = totalAvailable;
                badge.classList.add('show');
            } else {
                badge.classList.remove('show');
            }
        }
    }

    // ============================================================
    // RENDER CROPS
    // ============================================================

    function renderCrops() {
        const container = document.getElementById('cropsGrid');
        if (!container) return;

        const crops = getCrops();

        if (crops.length === 0) {
            container.innerHTML = `
                <div class="empty-state" style="grid-column: 1 / -1;">
                    <i class="fas fa-seedling"></i>
                    <h4>No crops added yet</h4>
                    <p>Start your crop journey by adding the crops currently growing on your farm.</p>
                    <button class="btn-primary" onclick="document.getElementById('addCropBtn').click()">
                        <i class="fas fa-plus"></i> Add Your First Crop
                    </button>
                </div>
            `;
            updateStats();
            return;
        }

        let html = '';
        crops.forEach(crop => {
            const cropName = crop.name || 'Unnamed';
            const variety = crop.variety || '';
            const fieldName = crop.field || 'Not assigned';
            const area = crop.area || 0;
            const plantingDate = crop.plantingDate || '';
            const daysSince = getDaysSincePlanting(plantingDate);
            const currentStage = getCurrentStage(cropName, plantingDate) || 'Unknown';
            const harvestInfo = getFormattedHarvestInfo(cropName, plantingDate);
            const imageUrl = getCropImage(cropName);
            
            // Check for available checkpoint
            const checkpoints = getCheckpoints(crop.id);
            const hasAvailable = checkpoints.some(c => c.status === 'available');

            let stageClass = 'crop-card-stage';
            if (harvestInfo.status === 'overdue') stageClass += ' overdue';
            else if (harvestInfo.status === 'harvest_ready') stageClass += ' harvest-ready';

            html += `
                <div class="crop-card" onclick="showCropDetail('${crop.id}')">
                    <img class="crop-card-image" src="${imageUrl}" alt="${cropName}" onerror="this.src='${CROP_IMAGES.default}'">
                    <div class="crop-card-body">
                        <div class="crop-card-header">
                            <div>
                                <div class="crop-card-name">${cropName}</div>
                                ${variety ? `<div class="crop-card-variety">${variety}</div>` : ''}
                            </div>
                            <span class="${stageClass}">${currentStage}</span>
                        </div>
                        ${hasAvailable ? `<div style="margin-bottom:0.5rem;"><span class="checkpoint-badge available"><i class="fas fa-camera"></i> Checkpoint Available</span></div>` : ''}
                        <div class="crop-card-details">
                            <div class="crop-card-detail">📅 <span>${daysSince} days</span> since planting</div>
                            <div class="crop-card-detail">📏 <span>${area} ha</span></div>
                            <div class="crop-card-detail">📍 <span>${fieldName}</span></div>
                            <div class="crop-card-detail">🌾 <span>${harvestInfo.label}</span></div>
                        </div>
                        <div class="crop-card-actions">
                            <button class="btn-secondary" onclick="event.stopPropagation(); showCropDetail('${crop.id}')">
                                <i class="fas fa-eye"></i> View Details
                            </button>
                            ${hasAvailable ? `<button class="btn-gold" onclick="event.stopPropagation(); openCheckpoint('${crop.id}')" style="padding:0.3rem 0.8rem; font-size:0.8rem;">
                                <i class="fas fa-camera"></i> Check-in
                            </button>` : ''}
                            <button class="btn-danger" onclick="event.stopPropagation(); deleteCrop('${crop.id}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        updateStats();
        updateNotificationBadge();
    }

    // ============================================================
    // UPDATE STATS
    // ============================================================

    function updateStats() {
        const crops = getCrops();
        const activeCrops = crops.length;

        let totalArea = 0;
        let growthStages = new Set();
        let nearHarvest = 0;

        crops.forEach(crop => {
            totalArea += parseFloat(crop.area) || 0;
            const stage = getCurrentStage(crop.name, crop.plantingDate);
            if (stage) growthStages.add(stage);

            const harvestStatus = getHarvestStatus(crop.name, crop.plantingDate);
            if (harvestStatus === 'harvest_ready' || harvestStatus === 'near_harvest') {
                nearHarvest++;
            }
        });

        document.getElementById('statActiveCrops').textContent = activeCrops;
        document.getElementById('statCultivatedArea').textContent = totalArea.toFixed(1);
        document.getElementById('statGrowthStages').textContent = growthStages.size;
        document.getElementById('statNearHarvest').textContent = nearHarvest;
        document.getElementById('cropCount').textContent = `${activeCrops} crops`;
    }

    // ============================================================
    // ADD / EDIT CROP
    // ============================================================

    function populateCropDropdown() {
        const select = document.getElementById('cropNameInput');
        const cropNames = getAllCropNames();

        select.innerHTML = '<option value="">Select a crop</option>';
        cropNames.forEach(name => {
            const displayName = name.charAt(0).toUpperCase() + name.slice(1);
            select.innerHTML += `<option value="${name}">${displayName}</option>`;
        });
    }

    function populateFieldDropdown() {
        const select = document.getElementById('cropFieldInput');
        const sections = getLandSections();
        const warning = document.getElementById('fieldWarning');

        select.innerHTML = '<option value="">Select a field</option>';

        if (sections.length === 0) {
            warning.style.display = 'block';
            select.innerHTML += `<option value="" disabled>No fields available</option>`;
        } else {
            warning.style.display = 'none';
            sections.forEach(section => {
                select.innerHTML += `<option value="${section.name}">${section.name} (${section.area || 0} ha)</option>`;
            });
        }
    }

    function openAddCropModal() {
        document.getElementById('editCropId').value = '';
        document.getElementById('cropModalTitle').textContent = 'Add New Crop';
        document.getElementById('cropForm').reset();
        populateFieldDropdown();
        openModal('cropModal');
    }

    function editCrop(id) {
        const crops = getCrops();
        const crop = crops.find(c => c.id === id);
        if (!crop) return;

        document.getElementById('editCropId').value = id;
        document.getElementById('cropModalTitle').textContent = 'Edit Crop';
        document.getElementById('cropNameInput').value = crop.name || '';
        document.getElementById('cropVarietyInput').value = crop.variety || '';
        document.getElementById('cropFieldInput').value = crop.field || '';
        document.getElementById('cropAreaInput').value = crop.area || '';
        document.getElementById('cropPlantingDateInput').value = crop.plantingDate || '';
        document.getElementById('cropSeedInput').value = crop.seed || '';
        document.getElementById('cropNotesInput').value = crop.notes || '';

        populateFieldDropdown();
        openModal('cropModal');
    }

    function saveCrop(event) {
        event.preventDefault();

        const editId = document.getElementById('editCropId').value;
        const name = document.getElementById('cropNameInput').value;
        const variety = document.getElementById('cropVarietyInput').value;
        const field = document.getElementById('cropFieldInput').value;
        const area = parseFloat(document.getElementById('cropAreaInput').value);
        const plantingDate = document.getElementById('cropPlantingDateInput').value;
        const seed = document.getElementById('cropSeedInput').value;
        const notes = document.getElementById('cropNotesInput').value;

        if (!name || !field || !area || !plantingDate) {
            showToast('Please fill in all required fields.', 'error');
            return;
        }

        const crops = getCrops();

        if (editId) {
            const index = crops.findIndex(c => c.id === editId);
            if (index !== -1) {
                crops[index] = {
                    ...crops[index],
                    name,
                    variety,
                    field,
                    area,
                    plantingDate,
                    seed,
                    notes,
                    updatedAt: new Date().toISOString()
                };
                saveCrops(crops);
                showToast('Crop updated successfully!');
            }
        } else {
            const newCrop = {
                id: 'crop_' + Date.now(),
                name,
                variety,
                field,
                area,
                plantingDate,
                seed,
                notes,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            crops.push(newCrop);
            saveCrops(crops);
            showToast('Crop added successfully!');
            
            // Create initial checkpoint
            setTimeout(() => {
                checkAndCreateCheckpoints(newCrop);
            }, 500);
        }

        closeModal('cropModal');
        renderCrops();
        if (typeof loadCropsForDashboard === 'function') {
            loadCropsForDashboard();
        }
    }

    // ============================================================
    // DELETE CROP
    // ============================================================

    function deleteCrop(id) {
        if (!confirm('Are you sure you want to delete this crop?')) return;

        const crops = getCrops();
        const filtered = crops.filter(c => c.id !== id);
        saveCrops(filtered);
        localStorage.removeItem('agrinova_checkpoints_' + id);
        renderCrops();
        showToast('Crop deleted.');
        if (typeof loadCropsForDashboard === 'function') {
            loadCropsForDashboard();
        }
    }

    // ============================================================
    // CROP DETAIL
    // ============================================================

    function showCropDetail(id) {
        const crops = getCrops();
        const crop = crops.find(c => c.id === id);
        if (!crop) return;

        const cropName = crop.name || 'Unnamed';
        const variety = crop.variety || '';
        const field = crop.field || 'Not assigned';
        const area = crop.area || 0;
        const plantingDate = crop.plantingDate || '';
        const notes = crop.notes || 'No notes';
        const daysSince = getDaysSincePlanting(plantingDate);
        const currentStage = getCurrentStage(cropName, plantingDate) || 'Unknown';
        const harvestInfo = getFormattedHarvestInfo(cropName, plantingDate);
        const imageUrl = getCropImage(cropName);
        const growthData = getCropGrowthData(cropName);
        
        const checkpoints = getCheckpoints(id);
        const completedCheckpoints = checkpoints.filter(c => c.status === 'completed');
        const availableCheckpoint = checkpoints.find(c => c.status === 'available');

        document.getElementById('cropDetailTitle').textContent = `${cropName} - Details`;

        // Build stages HTML
        let stagesHtml = '';
        if (growthData) {
            growthData.stages.forEach((stage, index) => {
                const isActive = stage.name === currentStage;
                const hasCheckpoint = checkpoints.some(c => c.stageName === stage.name && c.status === 'completed');
                const isAvailable = checkpoints.some(c => c.stageName === stage.name && c.status === 'available');
                
                let statusIcon = '○';
                let statusColor = '#68736C';
                if (hasCheckpoint) {
                    statusIcon = '✅';
                    statusColor = '#2F6B4F';
                } else if (isAvailable) {
                    statusIcon = '📌';
                    statusColor = '#B08D57';
                } else if (isActive) {
                    statusIcon = '●';
                    statusColor = '#2F6B4F';
                }
                
                stagesHtml += `
                    <div style="display:flex; align-items:center; gap:0.8rem; padding:0.4rem 0; border-bottom:1px solid #EDF2E9; ${isActive ? 'background:#EDF2E9; padding:0.4rem 0.8rem; border-radius:8px;' : ''}">
                        <div style="width:8px; height:8px; border-radius:50%; background:${isActive ? '#2F6B4F' : hasCheckpoint ? '#2F6B4F' : '#B8C9AE'};"></div>
                        <div style="flex:1;">
                            <span style="font-weight:${isActive ? '600' : '400'}; color:${isActive ? '#102F26' : '#68736C'};">${stage.name}</span>
                            <span style="font-size:0.75rem; color:#68736C; margin-left:0.5rem;">Day ${stage.startDay}-${stage.endDay}</span>
                        </div>
                        ${hasCheckpoint ? '<span style="font-size:0.7rem; background:#2F6B4F; color:#fff; padding:0.1rem 0.6rem; border-radius:12px;">✓ Done</span>' : ''}
                        ${isAvailable ? '<span style="font-size:0.7rem; background:#B08D57; color:#fff; padding:0.1rem 0.6rem; border-radius:12px;">📌 Available</span>' : ''}
                        ${isActive && !hasCheckpoint && !isAvailable ? '<span style="font-size:0.7rem; background:#2F6B4F; color:#fff; padding:0.1rem 0.6rem; border-radius:12px;">Current</span>' : ''}
                    </div>
                `;
            });
        }

        // Build completed checkpoints timeline
        let timelineHtml = '';
        if (completedCheckpoints.length > 0) {
            timelineHtml = `<div style="margin-top:1rem;">`;
            completedCheckpoints.forEach(cp => {
                const photoHtml = cp.photo ? `<img src="${cp.photo}" class="checkpoint-photo" alt="Progress photo">` : '';
                timelineHtml += `
                    <div class="checkpoint-card completed">
                        <div class="checkpoint-card-header">
                            <span class="checkpoint-card-title">📸 ${cp.stageName}</span>
                            <span class="checkpoint-card-date">Day ${cp.daySincePlanting}</span>
                        </div>
                        <div class="checkpoint-card-body">
                            ${photoHtml}
                            ${cp.observations ? `<p style="margin-top:0.3rem;">${cp.observations}</p>` : ''}
                        </div>
                    </div>
                `;
            });
            timelineHtml += `</div>`;
        }

        const detailHtml = `
            <div class="crop-detail-hero">
                <img src="${imageUrl}" alt="${cropName}" onerror="this.src='${CROP_IMAGES.default}'">
                <div class="crop-detail-info">
                    <h2>${cropName}</h2>
                    ${variety ? `<div class="subtitle">${variety}</div>` : ''}
                    <div class="crop-detail-meta">
                        <div class="crop-detail-meta-item">📍 <span>${field}</span></div>
                        <div class="crop-detail-meta-item">📏 <span>${area} ha</span></div>
                        <div class="crop-detail-meta-item">📅 Planted: <span>${plantingDate || 'Not set'}</span></div>
                        <div class="crop-detail-meta-item">⏱️ <span>${daysSince} days</span> since planting</div>
                        <div class="crop-detail-meta-item">🌱 Expected: <span>${currentStage}</span></div>
                        <div class="crop-detail-meta-item">🌾 <span>${harvestInfo.label}</span></div>
                    </div>
                </div>
            </div>

            ${availableCheckpoint ? `
            <div style="background:#FDF8F0; border:1px solid #B08D57; border-radius:12px; padding:1rem 1.2rem; margin-bottom:1.5rem;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
                    <div>
                        <div style="font-weight:600; color:#102F26;">📌 New Checkpoint Available</div>
                        <div style="font-size:0.85rem; color:#68736C;">${availableCheckpoint.stageName} · Day ${availableCheckpoint.daySincePlanting}</div>
                        <div style="font-size:0.75rem; color:#68736C;">Record your observations and upload a progress photo.</div>
                    </div>
                    <button class="btn-gold" onclick="closeModal('cropDetailModal'); openCheckpoint('${crop.id}')">
                        <i class="fas fa-camera"></i> Complete Checkpoint
                    </button>
                </div>
            </div>
            ` : ''}

            <div class="crop-detail-section">
                <h4>📊 Growth Timeline</h4>
                <div style="margin-top:0.5rem;">
                    ${stagesHtml || '<div style="color:#68736C;">Growth data not available for this crop.</div>'}
                </div>
            </div>

            ${timelineHtml ? `
            <div class="crop-detail-section">
                <h4>📸 Progress Journey</h4>
                ${timelineHtml}
            </div>
            ` : ''}

            <div class="crop-detail-section">
                <h4>📝 Notes</h4>
                <div style="color:#68736C; background:#F7F6F1; padding:0.8rem; border-radius:8px; margin-top:0.3rem;">
                    ${notes || 'No notes added.'}
                </div>
            </div>

            <div style="display:flex; gap:0.8rem; margin-top:1.5rem; padding-top:1rem; border-top:1px solid #EDF2E9; flex-wrap:wrap;">
                ${availableCheckpoint ? `<button class="btn-gold" onclick="closeModal('cropDetailModal'); openCheckpoint('${crop.id}')">
                    <i class="fas fa-camera"></i> Complete Checkpoint
                </button>` : ''}
                <button class="btn-primary" onclick="closeModal('cropDetailModal'); editCrop('${crop.id}')">
                    <i class="fas fa-edit"></i> Edit Crop
                </button>
                <button class="btn-danger" onclick="closeModal('cropDetailModal'); deleteCrop('${crop.id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        `;

        document.getElementById('cropDetailContent').innerHTML = detailHtml;
        openModal('cropDetailModal');
    }

    // ============================================================
    // CHECKPOINT MODAL
    // ============================================================

    function openCheckpoint(cropId) {
        const crops = getCrops();
        const crop = crops.find(c => c.id === cropId);
        if (!crop) return;

        const checkpoints = getCheckpoints(cropId);
        const available = checkpoints.find(c => c.status === 'available');
        if (!available) {
            showToast('No checkpoint available for this crop.', 'warning');
            return;
        }

        const cropName = crop.name || 'Unnamed';
        const plantingDate = crop.plantingDate || '';
        const daysSince = getDaysSincePlanting(plantingDate);
        const imageUrl = getCropImage(cropName);
        const questions = getQuestionsForStage(available.stageName);

        document.getElementById('checkpointModalTitle').textContent = `Checkpoint: ${available.stageName}`;

        let questionsHtml = '';
        questions.forEach((q, index) => {
            let inputHtml = '';
            if (q.type === 'select') {
                inputHtml = `<div class="q-options">`;
                q.options.forEach(opt => {
                    inputHtml += `
                        <label>
                            <input type="radio" name="q_${q.id}" value="${opt}">
                            ${opt}
                        </label>
                    `;
                });
                inputHtml += `</div>`;
            } else if (q.type === 'text') {
                inputHtml = `<textarea id="q_${q.id}" rows="2" placeholder="Enter your observations..."></textarea>`;
            } else if (q.type === 'date') {
                inputHtml = `<input type="date" id="q_${q.id}">`;
            } else if (q.type === 'number') {
                inputHtml = `<input type="number" id="q_${q.id}" step="0.01" placeholder="Enter quantity">`;
            }

            questionsHtml += `
                <div class="question-item">
                    <div class="q-text">${index + 1}. ${q.text}</div>
                    ${inputHtml}
                </div>
            `;
        });

        const checkpointHtml = `
            <div style="margin-bottom:1.5rem;">
                <div style="display:flex; align-items:center; gap:1rem; padding:1rem; background:#EDF2E9; border-radius:12px;">
                    <img src="${imageUrl}" alt="${cropName}" style="width:60px; height:60px; object-fit:cover; border-radius:8px;">
                    <div>
                        <div style="font-weight:600; font-size:1.1rem;">${cropName}</div>
                        <div style="color:#68736C; font-size:0.9rem;">Expected Stage: ${available.stageName}</div>
                        <div style="color:#68736C; font-size:0.85rem;">Day ${available.daySincePlanting} since planting</div>
                    </div>
                </div>
                <div style="font-size:0.8rem; color:#68736C; margin-top:0.3rem;">
                    ⚠️ Based on planting date and configured crop growth data.
                </div>
            </div>

            <div class="checkpoint-form-section">
                <h4>📸 Crop Progress Photo</h4>
                <div class="subtitle">Upload a recent photo showing the current condition of your crop.</div>
                <div class="photo-upload-area" id="photoUploadArea" onclick="document.getElementById('checkpointPhotoInput').click()">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <p>Click to upload a photo</p>
                    <small style="color:#68736C;">JPG, PNG, or WEBP</small>
                </div>
                <input type="file" id="checkpointPhotoInput" accept="image/*" style="display:none;">
                <div id="photoPreviewContainer"></div>
            </div>

            <div class="checkpoint-form-section">
                <h4>📋 Farmer Observations</h4>
                <div class="subtitle">Answer these questions based on your actual field observations.</div>
                ${questionsHtml}
            </div>

            <div class="checkpoint-form-section">
                <h4>📝 Additional Observations</h4>
                <div class="subtitle">Record anything else you observed about your crop during this stage.</div>
                <textarea id="checkpointObservations" rows="3" placeholder="Enter any additional observations..."></textarea>
            </div>

            <button class="btn-primary" onclick="submitCheckpoint('${crop.id}', '${available.id}')" style="width:100%;">
                <i class="fas fa-save"></i> Save Crop Progress Record
            </button>
        `;

        document.getElementById('checkpointContent').innerHTML = checkpointHtml;
        openModal('checkpointModal');

        // Setup photo upload
        const photoInput = document.getElementById('checkpointPhotoInput');
        const photoArea = document.getElementById('photoUploadArea');
        const previewContainer = document.getElementById('photoPreviewContainer');

        photoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            if (!file.type.startsWith('image/')) {
                alert('Please select an image file.');
                return;
            }
            const reader = new FileReader();
            reader.onload = function(ev) {
                const dataUrl = ev.target.result;
                previewContainer.innerHTML = `
                    <img src="${dataUrl}" class="photo-preview" alt="Crop progress photo">
                    <button onclick="document.getElementById('photoPreviewContainer').innerHTML = ''; document.getElementById('checkpointPhotoInput').value = '';" 
                            style="color:#B94A48; font-size:0.8rem; margin-top:0.3rem;">
                        <i class="fas fa-times"></i> Remove photo
                    </button>
                `;
                // Store the photo data URL
                photoInput.dataset.photoData = dataUrl;
            };
            reader.readAsDataURL(file);
        });
    }

    function submitCheckpoint(cropId, checkpointId) {
        // Collect answers
        const questions = document.querySelectorAll('.question-item');
        const answers = {};
        let hasErrors = false;

        questions.forEach(q => {
            const radio = q.querySelector('input[type="radio"]:checked');
            const textarea = q.querySelector('textarea');
            const dateInput = q.querySelector('input[type="date"]');
            const numberInput = q.querySelector('input[type="number"]');

            if (radio) {
                const name = radio.name;
                answers[name] = radio.value;
            } else if (textarea) {
                const id = textarea.id;
                if (id) answers[id] = textarea.value;
            } else if (dateInput) {
                const id = dateInput.id;
                if (id) answers[id] = dateInput.value;
            } else if (numberInput) {
                const id = numberInput.id;
                if (id) answers[id] = numberInput.value;
            }
        });

        // Check required fields (at least some answers)
        const hasAnswers = Object.keys(answers).length > 0;
        if (!hasAnswers) {
            showToast('Please answer at least one question.', 'error');
            return;
        }

        // Get photo data
        const photoInput = document.getElementById('checkpointPhotoInput');
        const photoData = photoInput.dataset.photoData || null;

        // Get observations
        const observations = document.getElementById('checkpointObservations').value || '';

        const data = {
            photo: photoData,
            answers: answers,
            observations: observations
        };

        completeCheckpoint(cropId, checkpointId, data);
        closeModal('checkpointModal');
        renderCrops();
        showToast('✅ Checkpoint completed successfully!');
    }

    // ============================================================
    // MODAL HELPERS
    // ============================================================

    window.openModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    };

    window.closeModal = function(id) {
        const modal = document.getElementById(id);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    };

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
                document.body.style.overflow = 'auto';
            }
        });
    });

    // ============================================================
    // TOAST
    // ============================================================

    function showToast(message, type) {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast show ${type || ''}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // ============================================================
    // PROFILE
    // ============================================================

    function updateProfile() {
        const farmer = getFarmer();
        if (!farmer) return;

        const name = farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('navName').textContent = name;
        document.getElementById('pdName').textContent = name;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || '—';
        
        const city = farmer.city || '—';
        const region = farmer.region || '—';
        document.getElementById('pdLocation').textContent = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdFarmland').textContent = farmer.hectares ? `${farmer.hectares} ha` : '—';
    }

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }
        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim().toLowerCase();
                    if (query) {
                        const crops = getCrops();
                        const results = crops.filter(c => 
                            c.name.toLowerCase().includes(query) ||
                            c.variety.toLowerCase().includes(query) ||
                            c.field.toLowerCase().includes(query)
                        );
                        if (results.length > 0) {
                            showToast(`Found ${results.length} crop${results.length > 1 ? 's' : ''} matching "${query}"`);
                        } else {
                            showToast(`No crops found matching "${query}"`);
                        }
                    }
                }
            });
        }
    }

    // ============================================================
    // NAV WEATHER
    // ============================================================

    async function fetchNavWeather() {
        try {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const { latitude, longitude } = pos.coords;
                        const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&timezone=auto`;
                        const resp = await fetch(url);
                        if (resp.ok) {
                            const data = await resp.json();
                            if (data.current_weather) {
                                document.getElementById('navTemp').textContent = data.current_weather.temperature + '°C';
                            }
                        }
                    },
                    async () => {
                        const farmer = getFarmer();
                        const city = farmer?.city || 'Addis Ababa';
                        const geoResp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
                        const geoData = await geoResp.json();
                        if (geoData && geoData.length > 0) {
                            const { lat, lon } = geoData[0];
                            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`;
                            const resp = await fetch(url);
                            if (resp.ok) {
                                const data = await resp.json();
                                if (data.current_weather) {
                                    document.getElementById('navTemp').textContent = data.current_weather.temperature + '°C';
                                }
                            }
                        }
                    }
                );
            }
        } catch (e) {
            console.warn('Nav weather error:', e);
        }
    }

    // ============================================================
    // AUTO CHECKPOINT CHECKER
    // ============================================================

    function checkAllCropsForCheckpoints() {
        const crops = getCrops();
        crops.forEach(crop => {
            checkAndCreateCheckpoints(crop);
        });
        renderCrops();
    }

    // ============================================================
    // EVENT LISTENERS
    // ============================================================

    document.addEventListener('DOMContentLoaded', function() {
        const addBtn = document.getElementById('addCropBtn');
        if (addBtn) {
            addBtn.addEventListener('click', openAddCropModal);
        }
        
        const form = document.getElementById('cropForm');
        if (form) {
            form.addEventListener('submit', saveCrop);
        }
    });

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova My Crops Page Initializing...');
        console.log('Total crops in database:', Object.keys(CROP_GROWTH_DATA).length);
        
        populateCropDropdown();
        updateProfile();
        setupProfileImage();
        setupDropdown();
        setupSearch();
        fetchNavWeather();
        
        // Check for checkpoints on load
        checkAllCropsForCheckpoints();
        renderCrops();

        // Check for checkpoints every 60 seconds
        setInterval(checkAllCropsForCheckpoints, 60000);

        console.log('AgriNova My Crops Page Ready.');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // ============================================================
    // EXPOSE FUNCTIONS FOR ONCLICK
    // ============================================================
    
    window.showCropDetail = showCropDetail;
    window.deleteCrop = deleteCrop;
    window.editCrop = editCrop;
    window.closeModal = closeModal;
    window.openAddCropModal = openAddCropModal;
    window.openCheckpoint = openCheckpoint;
    window.submitCheckpoint = submitCheckpoint;

})();