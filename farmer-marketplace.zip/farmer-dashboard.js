(function() {
    "use strict";

    // ============================================================
    // DATA HELPERS - Read from localStorage
    // ============================================================

    function getFarmer() {
        // Try multiple possible keys
        let raw = localStorage.getItem('agrinova_farmer');
        if (!raw) raw = localStorage.getItem('farmerData');
        if (!raw) raw = localStorage.getItem('farmer');
        if (!raw) raw = localStorage.getItem('user');
        
        if (!raw) {
            console.warn('No farmer data found in localStorage. Keys checked: agrinova_farmer, farmerData, farmer, user');
            return null;
        }
        
        try { 
            const data = JSON.parse(raw);
            console.log('Farmer data loaded:', data);
            return data;
        } catch (e) {
            console.error('Error parsing farmer data:', e);
            return null;
        }
    }

    function getCrops() {
        let raw = localStorage.getItem('agrinova_crops');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getTasks() {
        let raw = localStorage.getItem('agrinova_tasks');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getRecords() {
        let raw = localStorage.getItem('agrinova_records');
        if (!raw) return [];
        try { return JSON.parse(raw); } catch { return []; }
    }

    function getFinance() {
        let raw = localStorage.getItem('agrinova_finance');
        if (!raw) return null;
        try { return JSON.parse(raw); } catch { return null; }
    }

    // ============================================================
    // PROFILE & GREETING - FIXED
    // ============================================================

    function updateGreeting() {
        const farmer = getFarmer();
        const h1 = document.getElementById('greetingText');
        const navName = document.getElementById('navName');
        
        // Debug: Log what we found
        console.log('Farmer data for greeting:', farmer);
        
        if (!farmer) {
            h1.textContent = 'Good morning, Farmer!';
            navName.textContent = 'Farmer';
            return;
        }

        // Try multiple possible field names for first name
        const firstName = farmer.firstName || farmer.firstname || farmer.first_name || farmer.name || farmer.fullName?.split(' ')[0] || 'Farmer';
        
        const hour = new Date().getHours();
        let greet = 'Good morning';
        if (hour >= 12 && hour < 17) greet = 'Good afternoon';
        else if (hour >= 17) greet = 'Good evening';
        
        h1.textContent = `${greet}, ${firstName}!`;
        navName.textContent = firstName;

        // Update dropdown
        const fullName = farmer.fullName || farmer.name || farmer.firstName || 'Farmer';
        document.getElementById('pdName').textContent = fullName;
        document.getElementById('pdEmail').textContent = farmer.email || '—';
        document.getElementById('pdPhone').textContent = farmer.phone || farmer.phoneNumber || '—';
        
        const city = farmer.city || farmer.location || '—';
        const region = farmer.region || farmer.state || '—';
        const loc = `${city}, ${region}, Ethiopia`;
        document.getElementById('pdLocation').textContent = loc;
        
        const farmland = farmer.farmland || farmer.farmArea || farmer.farm_size || farmer.landSize || '—';
        document.getElementById('pdFarmland').textContent = farmland !== '—' ? `${farmland} ha` : '—';
        document.getElementById('farmerLocation').textContent = loc;
    }

    function updateDate() {
        const now = new Date();
        const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', opts);
    }

    // ============================================================
    // PROFILE IMAGE UPLOAD - FIXED
    // ============================================================

    function setupProfileImage() {
        const input = document.getElementById('profileImageInput');
        const trigger = document.getElementById('uploadProfileBtn');
        
        if (trigger) {
            trigger.addEventListener('click', () => input.click());
        }
        
        if (input) {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(ev) {
                    const dataUrl = ev.target.result;
                    localStorage.setItem('agrinova_profileImage', dataUrl);
                    applyProfileImage(dataUrl);
                };
                reader.readAsDataURL(file);
            });
        }

        const saved = localStorage.getItem('agrinova_profileImage');
        if (saved) applyProfileImage(saved);
    }

    function applyProfileImage(dataUrl) {
        const navAvatar = document.getElementById('navAvatar');
        const pdAvatar = document.getElementById('pdAvatar');
        
        [navAvatar, pdAvatar].forEach(el => {
            if (el) {
                el.innerHTML = `<img src="${dataUrl}" alt="profile">`;
            }
        });
    }

    // ============================================================
    // PROFILE DROPDOWN - FIXED
    // ============================================================

    function setupDropdown() {
        const trigger = document.getElementById('profileTrigger');
        const dropdown = document.getElementById('profileDropdown');
        
        if (trigger && dropdown) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });
            document.addEventListener('click', () => dropdown.classList.remove('show'));
        }
    }

    // ============================================================
    // WEATHER (Open-Meteo) - WIDER CARD
    // ============================================================

    const weatherBackgrounds = {
        'Clear': 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&h=400&fit=crop',
        'Partly cloudy': 'https://images.unsplash.com/photo-1581456495146-65a71b2c8e52?w=800&h=400&fit=crop',
        'Overcast': 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&h=400&fit=crop',
        'Rain': 'https://images.unsplash.com/photo-1519692933481-e162a57d6721?w=800&h=400&fit=crop',
        'Drizzle': 'https://images.unsplash.com/photo-1519692933481-e162a57d6721?w=800&h=400&fit=crop',
        'Fog': 'https://images.unsplash.com/photo-1487621167305-5d248087c724?w=800&h=400&fit=crop',
        'Thunderstorm': 'https://images.unsplash.com/photo-1605727216801-e27ce1d0cc28?w=800&h=400&fit=crop',
        'Snow': 'https://images.unsplash.com/photo-1491002052546-bf38f186af56?w=800&h=400&fit=crop',
        'default': 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&h=400&fit=crop'
    };

    function setWeatherBackground(condition) {
        const card = document.getElementById('weatherCard');
        if (!card) return;
        
        let key = 'default';
        const cond = condition.toLowerCase();
        if (cond.includes('clear') || cond.includes('sunny')) key = 'Clear';
        else if (cond.includes('partly') || cond.includes('cloud')) key = 'Partly cloudy';
        else if (cond.includes('overcast') || cond.includes('cloudy')) key = 'Overcast';
        else if (cond.includes('rain') || cond.includes('shower')) key = 'Rain';
        else if (cond.includes('drizzle')) key = 'Drizzle';
        else if (cond.includes('fog') || cond.includes('mist')) key = 'Fog';
        else if (cond.includes('thunder') || cond.includes('storm')) key = 'Thunderstorm';
        else if (cond.includes('snow')) key = 'Snow';
        
        card.style.backgroundImage = `url(${weatherBackgrounds[key] || weatherBackgrounds.default})`;
    }

    function mapWeatherCode(code) {
        const map = {
            0: 'Clear', 1: 'Clear', 2: 'Partly cloudy', 3: 'Overcast',
            45: 'Fog', 48: 'Fog',
            51: 'Drizzle', 53: 'Drizzle', 55: 'Drizzle',
            61: 'Rain', 63: 'Rain', 65: 'Rain',
            71: 'Snow', 73: 'Snow', 75: 'Snow',
            80: 'Rain showers', 81: 'Rain showers', 82: 'Rain showers',
            95: 'Thunderstorm', 96: 'Thunderstorm', 99: 'Thunderstorm'
        };
        return map[code] || '—';
    }

    async function fetchWeather(lat, lon, cityName) {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=relativehumidity_2m,windspeed_10m&timezone=auto`;
        try {
            const resp = await fetch(url);
            if (!resp.ok) throw new Error('API error');
            const data = await resp.json();
            const cw = data.current_weather;
            if (!cw) throw new Error('No current weather');

            let humidity = '--%';
            if (data.hourly && data.hourly.relativehumidity_2m && data.hourly.relativehumidity_2m.length) {
                humidity = data.hourly.relativehumidity_2m[0] + '%';
            }
            const wind = cw.windspeed ? cw.windspeed + ' km/h' : '--';
            const temp = cw.temperature !== undefined ? cw.temperature + '°C' : '--°C';
            const feelsLike = cw.temperature !== undefined ? (cw.temperature - 2) + '°C' : '--°C';
            const condition = cw.weathercode ? mapWeatherCode(cw.weathercode) : '—';

            document.getElementById('weatherTemp').textContent = temp;
            document.getElementById('weatherCondition').textContent = condition;
            document.getElementById('weatherHumidity').textContent = humidity;
            document.getElementById('weatherWind').textContent = wind;
            document.getElementById('weatherFeelsLike').textContent = feelsLike;
            document.getElementById('weatherUpdated').textContent = `Updated: ${new Date().toLocaleTimeString()}`;

            setWeatherBackground(condition);
            return { condition };
        } catch (e) {
            console.warn('Weather error:', e);
            document.getElementById('weatherTemp').textContent = '—';
            document.getElementById('weatherCondition').textContent = 'Weather information unavailable.';
            document.getElementById('weatherHumidity').textContent = '--';
            document.getElementById('weatherWind').textContent = '--';
            document.getElementById('weatherFeelsLike').textContent = '--';
            document.getElementById('weatherUpdated').textContent = '';
            return null;
        }
    }

    async function geocodeCity(city) {
        if (!city) return null;
        try {
            const resp = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},Ethiopia&format=json&limit=1`);
            if (!resp.ok) throw new Error('Geocode error');
            const data = await resp.json();
            if (data && data.length > 0) {
                return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
            }
            return null;
        } catch (e) {
            console.warn('Geocode error:', e);
            return null;
        }
    }

    function getWeather() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                async (pos) => {
                    const { latitude, longitude } = pos.coords;
                    await fetchWeather(latitude, longitude, 'Current Location');
                },
                async () => {
                    await fallbackToCityWeather();
                }
            );
        } else {
            fallbackToCityWeather();
        }
    }

    async function fallbackToCityWeather() {
        const farmer = getFarmer();
        const city = farmer?.city || farmer?.location;
        if (city) {
            const coords = await geocodeCity(city);
            if (coords) {
                await fetchWeather(coords.lat, coords.lon, city);
                return;
            }
        }
        document.getElementById('weatherTemp').textContent = '—';
        document.getElementById('weatherCondition').textContent = 'Weather information unavailable.';
        document.getElementById('weatherHumidity').textContent = '--';
        document.getElementById('weatherWind').textContent = '--';
        document.getElementById('weatherFeelsLike').textContent = '--';
    }

    // ============================================================
    // FARM OVERVIEW
    // ============================================================

    function updateFarmOverview() {
        const farmer = getFarmer();
        const crops = getCrops();
        const tasks = getTasks();

        const area = farmer?.farmland || farmer?.farmArea || farmer?.farm_size || farmer?.landSize;
        document.getElementById('totalArea').textContent = area ? `${area} ha` : '—';
        document.getElementById('activeCrops').textContent = crops.length;
        
        const pending = tasks.filter(t => t.status !== 'completed' && t.status !== 'done').length;
        document.getElementById('pendingTasks').textContent = pending;
        document.getElementById('daysToHarvest').textContent = '—';
    }

    // ============================================================
    // CROP CARDS
    // ============================================================

    const cropImages = {
        'maize': 'https://images.unsplash.com/photo-1551754655-cd27a38e3f9f?w=300&h=200&fit=crop',
        'corn': 'https://images.unsplash.com/photo-1551754655-cd27a38e3f9f?w=300&h=200&fit=crop',
        'teff': 'https://images.unsplash.com/photo-1574943320219-553eb3b3c97b?w=300&h=200&fit=crop',
        'wheat': 'https://images.unsplash.com/photo-1574323347407-f5e1d273aa42?w=300&h=200&fit=crop',
        'potato': 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=300&h=200&fit=crop',
        'coffee': 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=300&h=200&fit=crop',
        'barley': 'https://images.unsplash.com/photo-1574323347407-f5e1d273aa42?w=300&h=200&fit=crop',
        'default': 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=300&h=200&fit=crop'
    };

    function getCropImage(cropName) {
        if (!cropName) return cropImages.default;
        const key = cropName.toLowerCase().trim();
        return cropImages[key] || cropImages.default;
    }

    function renderCrops() {
        const container = document.getElementById('cropContainer');
        const crops = getCrops();

        if (!crops || crops.length === 0) {
            container.innerHTML = `<div class="empty-state"><i class="fas fa-seedling"></i> No crops added yet.<br><span style="font-size:0.8rem;">Add your first crop to start monitoring your farm.</span></div>`;
            return;
        }

        let html = '';
        crops.forEach(crop => {
            const name = crop.name || crop.cropName || 'Unnamed Crop';
            const stage = crop.stage || crop.growthStage || 'Growing';
            const plantingDate = crop.plantingDate || crop.datePlanted || '—';
            const img = getCropImage(name);
            html += `
                <div class="crop-card">
                    <img src="${img}" alt="${name}" onerror="this.src='${cropImages.default}'">
                    <div class="crop-info">
                        <div class="crop-name">${name}</div>
                        <div class="crop-stage">${stage}</div>
                        <div class="crop-meta">Planted: ${plantingDate}</div>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    // ============================================================
    // TASKS, RECORDS, FINANCE
    // ============================================================

    function renderTasks() {
        const container = document.getElementById('taskList');
        const tasks = getTasks();
        const upcoming = tasks.filter(t => t.status !== 'completed' && t.status !== 'done');

        if (upcoming.length === 0) {
            container.innerHTML = `<div class="empty-state">No upcoming tasks.</div>`;
            return;
        }

        let html = '';
        upcoming.slice(0, 5).forEach(task => {
            const name = task.title || task.name || 'Task';
            const date = task.date || task.dueDate || '—';
            html += `
                <div class="task-item">
                    <span class="task-name">${name}</span>
                    <span class="task-date">${date}</span>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function renderRecords() {
        const container = document.getElementById('recordList');
        const records = getRecords();

        if (records.length === 0) {
            container.innerHTML = `<div class="empty-state">No farm activities recorded yet.</div>`;
            return;
        }

        let html = '';
        records.slice(0, 5).forEach(record => {
            const activity = record.activity || record.type || 'Activity';
            const date = record.date || '—';
            html += `
                <div class="record-item">
                    <span class="record-act">${activity}</span>
                    <span class="record-date">${date}</span>
                </div>
            `;
        });
        container.innerHTML = html;
    }

    function renderFinance() {
        const container = document.getElementById('financeSummary');
        const finance = getFinance();

        if (!finance) {
            container.innerHTML = `<div class="empty-state">No financial records available yet.</div>`;
            return;
        }

        const revenue = finance.revenue || 0;
        const expenses = finance.expenses || 0;
        const profit = revenue - expenses;

        container.innerHTML = `
            <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:0.5rem; text-align:center;">
                <div><div style="font-weight:600; color:#0B3D2E;">${revenue} ETB</div><div style="font-size:0.7rem; color:#6B766E;">Revenue</div></div>
                <div><div style="font-weight:600; color:#0B3D2E;">${expenses} ETB</div><div style="font-size:0.7rem; color:#6B766E;">Expenses</div></div>
                <div><div style="font-weight:600; color:${profit >= 0 ? '#4F8A45' : '#b33c3c'};">${profit} ETB</div><div style="font-size:0.7rem; color:#6B766E;">${profit >= 0 ? 'Profit' : 'Loss'}</div></div>
            </div>
        `;
    }

    // ============================================================
    // AI INSIGHT - TALLER CARD
    // ============================================================

    function updateAIInsight() {
        const el = document.getElementById('aiInsight');
        const crops = getCrops();
        const weather = document.getElementById('weatherCondition').textContent;

        if (crops.length === 0) {
            el.innerHTML = `
                <div style="display:flex; align-items:center; gap:1rem; min-height:100px;">
                    <i class="fas fa-robot" style="font-size:2.5rem; color:#4F8A45;"></i>
                    <div>
                        <div style="font-weight:500; margin-bottom:0.3rem;">AgriNova AI Assistant</div>
                        <div style="color:#6B766E;">More farm information is required to provide a personalized recommendation.</div>
                        <div style="color:#6B766E; font-size:0.85rem; margin-top:0.3rem;">Add your first crop to get started.</div>
                    </div>
                </div>
            `;
            return;
        }

        let recommendation = '';
        if (weather && weather !== 'Weather information unavailable.' && weather !== '—') {
            if (weather.toLowerCase().includes('rain')) {
                recommendation = '🌧️ Rain is forecast. Consider reviewing your planned irrigation activities.';
            } else if (weather.toLowerCase().includes('clear') || weather.toLowerCase().includes('sunny')) {
                recommendation = '☀️ Clear weather expected. Good conditions for field work and crop monitoring.';
            } else {
                recommendation = '📊 Based on your crop data and current weather, continue regular monitoring and record keeping.';
            }
        } else {
            recommendation = '📊 Continue monitoring your crops and logging farm activities for better recommendations.';
        }

        el.innerHTML = `
            <div style="display:flex; align-items:flex-start; gap:1rem; min-height:100px;">
                <i class="fas fa-robot" style="font-size:2.5rem; color:#4F8A45;"></i>
                <div>
                    <div style="font-weight:500; margin-bottom:0.5rem;">AgriNova AI Assistant</div>
                    <div style="font-size:1rem; line-height:1.6;">${recommendation}</div>
                    <div style="color:#6B766E; font-size:0.85rem; margin-top:0.5rem;">
                        ${crops.length} crop${crops.length > 1 ? 's' : ''} detected · ${getRecords().length} activities logged
                    </div>
                </div>
            </div>
        `;
    }

    // ============================================================
    // FARM HEALTH & NOTIFICATIONS
    // ============================================================

    function updateFarmHealth() {
        const el = document.getElementById('farmHealth');
        const crops = getCrops();
        const records = getRecords();

        if (crops.length === 0 || records.length === 0) {
            el.innerHTML = `
                <div style="display:flex; align-items:center; gap:1rem; min-height:80px;">
                    <i class="fas fa-heart" style="font-size:2rem; color:#6B766E;"></i>
                    <div>
                        <div style="font-weight:500;">Farm Health</div>
                        <div style="color:#6B766E;">Insufficient farm data to calculate farm health.</div>
                        <div style="color:#6B766E; font-size:0.8rem;">Add crops and log activities to get farm health score.</div>
                    </div>
                </div>
            `;
            return;
        }

        el.innerHTML = `
            <div style="display:flex; align-items:center; gap:1rem; min-height:80px;">
                <i class="fas fa-heartbeat" style="font-size:2rem; color:#4F8A45;"></i>
                <div>
                    <div style="font-weight:500;">Farm Health Assessment</div>
                    <div style="color:#6B766E;">More data needed for accurate farm health calculation.</div>
                    <div style="color:#6B766E; font-size:0.8rem;">${crops.length} crops · ${records.length} activities logged</div>
                </div>
            </div>
        `;
    }

    function updateNotifications() {
        const el = document.getElementById('notificationList');
        const tasks = getTasks();
        const upcoming = tasks.filter(t => t.status !== 'completed' && t.status !== 'done');

        if (upcoming.length === 0) {
            el.innerHTML = `<div class="empty-state">No notifications.</div>`;
            return;
        }

        let html = '';
        upcoming.slice(0, 3).forEach(task => {
            const name = task.title || task.name || 'Task';
            const date = task.date || task.dueDate || '—';
            html += `<div class="task-item"><span class="task-name">⏰ "${name}" due</span><span class="task-date">${date}</span></div>`;
        });
        el.innerHTML = html;

        const notifIcon = document.getElementById('notifIcon');
        if (upcoming.length > 0) {
            notifIcon.innerHTML = `<span style="position:relative;">🔔<span style="position:absolute; top:-8px; right:-10px; background:#b33c3c; color:#fff; border-radius:50%; font-size:0.6rem; padding:1px 5px;">${upcoming.length}</span></span>`;
        } else {
            notifIcon.innerHTML = '🔔';
        }
    }

    // ============================================================
    // MARKET PRICES
    // ============================================================

    function renderMarketPrices() {
        const el = document.getElementById('marketList');
        el.innerHTML = `<div class="empty-state">No verified market price data available.</div>`;
    }

    // ============================================================
    // SEARCH
    // ============================================================

    function setupSearch() {
        const input = document.getElementById('globalSearch');
        if (input) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const query = input.value.trim();
                    if (query) {
                        alert(`🔍 Search for "${query}" - This feature will search connected AgriNova resources.`);
                    }
                }
            });
        }
    }

    // ============================================================
    // INIT
    // ============================================================

    function init() {
        console.log('AgriNova Dashboard Initializing...');
        updateDate();
        updateGreeting();
        setupProfileImage();
        setupDropdown();
        setupSearch();
        getWeather();
        updateFarmOverview();
        renderCrops();
        renderTasks();
        renderRecords();
        renderFinance();
        renderMarketPrices();
        updateAIInsight();
        updateFarmHealth();
        updateNotifications();
        console.log('AgriNova Dashboard Ready.');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();